using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Exercises : MonoBehaviour
{
    public Transform obj;

    private int scaleFactor = 1;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Keyboard.current.numpadPlusKey.wasPressedThisFrame ||
            Keyboard.current.equalsKey.wasPressedThisFrame)
        {
            scaleFactor += 1;
            obj.localScale = Vector3.one * scaleFactor;
        }

        if(Keyboard.current.numpadMinusKey.wasPressedThisFrame ||
            Keyboard.current.minusKey.wasPressedThisFrame)
        {
            scaleFactor -= 1;
            if (scaleFactor < 1)
                scaleFactor = 1;
            obj.localScale = Vector3.one * scaleFactor;
        }
    }
}
