package com.bravo.advanced.fluent.test;

import com.bravo.advanced.fluent.stream2.SimpleStream;
import com.bravo.advanced.fluent.stream2.SimpleStream0;
import com.bravo.advanced.fluent.stream2.SimpleStream1;
import com.bravo.advanced.fluent.stream2.SimpleStream2;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

public class SimpleStreamTest {

    /**
     * 支持延迟操作，filter不会立即执行，需要调用forEach终端操作
     */
    @Test
    public void testSimpleStream0() {
        List<String> names = Arrays.asList("李健", "陈奕迅", "王力宏");
        SimpleStream0<String> stream = SimpleStream0.of(names)
                .filter(item -> item.length() > 2);

        System.out.println("---开始执行forEach---");

        stream.forEach(System.out::println);
    }

    /**
     * 用 Stage 将 filter、map 等中间操作统一起来
     */
    @Test
    public void testSimpleStream1() {
        List<String> names = Arrays.asList("李健", "陈奕迅", "王力宏");
        SimpleStream1<String> filterStream = SimpleStream1.of(names)
                .filter(item -> item.length() > 2);

        SimpleStream1<String> mapStream = filterStream.map(v -> v);

        System.out.println("---开始执行forEach---");

        mapStream.forEach(item -> {
            System.out.println(item);
            System.out.println("----- finish -----");
        });
    }

    /**
     * 引入Sink，把操作串成链式结构，元素只遍历一次，上一个操作结束后，交给下一个downstream处理，直到forEach
     */
    @Test
    public void testSimpleStream2() {
        List<String> names = Arrays.asList("李健", "陈奕迅", "王力宏");
        SimpleStream2<String> filterStream = SimpleStream2.of(names)
                .filter(item -> item.length() > 2);

        SimpleStream2<String> mapStream = filterStream.map(v -> v);

        System.out.println("---开始执行forEach---");

        mapStream.forEach(item -> {
            System.out.println(item);
            System.out.println("----- finish -----");
        });
    }

    /**
     * 相对完整的demo
     */
    @Test
    public void testSimpleStream3() {
        List<String> names = Arrays.asList("李健", "陈奕迅", "王力宏");
        List<String> list = SimpleStream.of(names)
                .peek(item -> System.out.println(item + "_filter"))
                .filter(item -> item.length() > 2)
                .peek(item -> System.out.println(item + "_map"))
                .map(v -> v + "～!!")
                .toList();
        System.out.println("finalResult: " + list);
    }

    // ------ SimpleStream VS Java 8 StreamAPI -------

    @Test
    public void testStreamAPI() {
        List<String> names = Arrays.asList("李健", "陈奕迅", "王力宏");
        names.stream()
                .peek(item -> System.out.println(item + "_filter"))
                .filter(item -> item.length() > 2)
                .peek(item -> System.out.println(item + "_map"))
                .map(v -> v + "～!!")
                .forEach(item -> {
                    System.out.println(item);
                    System.out.println("----- finish -----");
                });
    }

    @Test
    public void testSimpleStream() {
        List<String> names = Arrays.asList("李健", "陈奕迅", "王力宏");
        SimpleStream.of(names)
                .peek(item -> System.out.println(item + "_filter"))
                .filter(item -> item.length() > 2)
                .peek(item -> System.out.println(item + "_map"))
                .map(v -> v + "～!!")
                .forEach(item -> {
                    System.out.println(item);
                    System.out.println("----- finish -----");
                });
    }
}
