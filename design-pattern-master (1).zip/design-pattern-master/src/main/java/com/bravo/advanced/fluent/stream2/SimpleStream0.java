package com.bravo.advanced.fluent.stream2;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class SimpleStream0<T> {
    private final List<T> source;
    // 用一个变量，把【操作】保存起来
    private Predicate<? super T> predicate;

    private SimpleStream0(List<T> source) {
        this.source = source;
    }

    public static <T> SimpleStream0<T> of(List<T> source) {
        return new SimpleStream0<>(source);
    }

    public SimpleStream0<T> filter(Predicate<? super T> predicate) {
        this.predicate = predicate;
        return this;
    }

    public void forEach(Consumer<? super T> action) {
        for (T element : source) {
            System.out.println(element + "_filter");
            if (predicate == null || predicate.test(element)) {
                action.accept(element);
            }
        }
    }
}