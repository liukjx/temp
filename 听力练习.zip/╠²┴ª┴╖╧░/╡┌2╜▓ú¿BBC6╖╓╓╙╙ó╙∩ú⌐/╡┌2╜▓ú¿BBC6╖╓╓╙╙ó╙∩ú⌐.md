# BBC LEARNING ENGLISH 6 Minute English Food Waste  

NB: This is not a word-for-word transcript  

Rob Hello and welcome to 6 Minute English. I'm Rob…  

Finn … and I'm Finn. Hello.  

Rob Hello, Finn. Now, you like food don't you?  

Finn Yes, I do.  

Rob But how much of it do you actually throw away?  

Finn Probably too much although I'm trying to get better at that, Rob.  

# Rob  

I'm asking you this because many people around the world throw away food that's still good enough to eat – this food waste could feed millions of other people. That's what we're talking about today as well as looking as some related vocabulary.  

# Finn  

Yes, food waste is a big problem. We stock up on food that we don't really need, and we're often tempted by supermarkets to consume – or to eat – more.  

# Rob  

Before we talk more about this, let's find out what you know about food waste. So, do you know, according to the United Nations Food and Agricultural Organisation, what percentage of food is actually wasted?  

a) $25\%$  

b) $33\%$ c) $50\%$  

# Finn  

$50\%$ , I seem to remember that. I might be wrong.  

# Rob  

We'll find out if you're right or wrong later on. But now, here's another figure for you: In Europe, people throw away 100 million tonnes of food every year.  

# Finn  

Wow, such a waste. Most of this food just ends up rotting in landfill sites and that adds to another problem – it creates greenhouse gases.  

# Rob  

It does. But the problem isn't just us throwing away leftovers in the fridge or cupboard, as we can hear now from BBC reporter Caroline Hepker. What are the other reasons that lead to food being wasted?  

# INSERT  

# Caroline Hepker, BBC Reporter  

Typically, supermarkets demand that onions are about two to two-and-a-quarter inches in diameter. This one will get pretty close to it but this one is too small, although it is perfectly edible. The question is, what happens to it then? Food waste is a huge issue in America – $40\%$ of all food goes uneaten and it's a problem that starts long before you get to the dining-room table.  

# Finn  

Another staggering figure there Rob – $40\%$ of all food in America goes uneaten – it doesn't get eaten.And she explained that supermarkets are partly to blame.  

# Rob  

Yes. We all love the convenience, the price and the choice of food that supermarkets offer – but a lot of food is binned – thrown out – long before it reaches the shelves.  

# Finn  

The reporter gave the example of onions: if they're the wrong size, they can't be sold;   
they're thrown away even though they’re good enough to eat – or edible.  

# Rob  

There are many other types of fruit and vegetables that are discarded – or thrown away –  

because of their shape and size. And that's our fault really, because we often think food that looks good is better quality.  

# Finn  

Another issue is the 'sell by' and 'use by' dates printed on food packaging. They confuse customers. Anything older than the 'sell by' date makes us think it’s old and the food has gone off, but in fact this is just the date supermarket wants to sell it by.  

This is a test line in veerdana, this is attest line in verdana, this is a test line in verdana  

# Rob  

And there is another reason why some of us are encouraged to buy too much food. Have a listen to working mum, Tara Sherbrooke, about her shopping habits and see if you can hear what the problem is.  

# Finn  

Also, see if you can hear what she does to try and minimise food waste.  

# INSERT  

# Tara Sherbrooke  

I try very hard to meal-plan because as a working mum and having a busy family, I really try to make sure that there’s enough food at the beginning of the week. I find it very difficult to walk pass two-for-one offers especially on things that we use. I even find it hard to walk past them when they're items I’ve never purchased before – I stop and look!  

# Finn  

So she is a busy working mum and she tries to meal-plan – she plans the family's meals for the week and works out what to buy.  

# Rob  

But she still gets tempted by the two-for-one offers. That's when you buy one item and you get another one of the same item for free.  

# Finn  

Buy-one-get-one-free – or as it's sometimes known, BOGOF! You can get a bargain but it also means we sometimes buy too much of something. If it's fresh produce, it might go off before you get to use it all.  

# Rob  

But in other parts of the world people struggle to buy even the most basic food. A report by the UN's Food and Agricultural Organisation found that there is enough food for everyone, just a lot of inefficiency. So what can be done?  

# Finn  

Well things are being done. Apps and websites that distribute excess food are becoming more popular.  

# Rob  

And food banks are being set up too. These are charitable organisations people donate food to. It's then distributed to those who have difficulty buying their own food. And one trial project in New York requires the city's restaurants to stop sending food waste to landfills by 2015. But at the moment, globally, there's still a lot of food being thrown away. And Finn, I asked you how much? Is it $25\%$ , $33\%$ or $50\%$ of all food produced?  

Finn I said half – $50\%$ .  

# Rob  

According to the United Nations Food and Agricultural Organisation, the answer is $33\%$ . Still not good. It also found the amount of land needed to grow all the food wasted in the world each year would be the size of Mexico. Well, that brings us to the end of today's 6 Minute English. We hope you enjoyed today’s programme. Please join us again soon.  

Both Bye.  

# Vocabulary  

stock up on buy a large quantity of  

consume (here) to eat  

landfill sites large holes in the ground where people's waste or rubbish is buried  

leftovers food that is not eaten  

convenience ease of doing something  

edible safe or good enough to eat  

discarded thrown away  

gone off no longer fresh  

BOGOF (acronym) buy one, get one free  

distribute to give something out to several people  