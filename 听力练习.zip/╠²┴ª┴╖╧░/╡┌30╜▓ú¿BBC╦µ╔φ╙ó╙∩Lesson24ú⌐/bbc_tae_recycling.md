# BBC LEARNING ENGLISH Take Away English 随身英语 A matter of waste 废物回收一两事  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

Vocabulary: recycling 词汇: 回收  

Should you recycle the box from your takeaway pizza or throw it away? Can you recycle aerosol cans? Is all plastic recyclable? How clued up about recycling are you?  

We probably all know that recycling is good for the environment. It saves energy and limits the drain on Earth's resources. But do you know which items you should or shouldn't recycle?  

These days we are recycling more and more items  

In the UK, we have a well-established system of kerbside recycling. Most people expect to separate recyclable material from general refuse. A typical household recycles paper, cardboard, plastic and glass bottles, foil and drinks cans. Food and garden waste is now also collected. But in the last four years, the number of items rejected for recycling in England has gone up by $84\%$ , mainly as a result of contamination. Many items end up in landfill or being incinerated when, with more care, they could be recycled. The problem often stems from confusion over what and how to recycle.  

Across the UK the system of recycling differs between local authorities, and multiple containers are used for different types of recyclables. In one area there may be one large wheelie bin for recycling all household items, another for garden waste, and yet another for general waste. There are also composting food caddies – a small one for the kitchen and a larger one for the kerbside. These use compostable bags for food waste, including tea bags, coffee grindings and egg shells. A few streets away, another council may use a separate container just for glass bottles. Waste collection times vary – either weekly or fortnightly. Each week, you have to remember which bin has to go out. It's all highly confusing.  

One of the biggest problems recycling firms face is food contamination. If your plastic milk bottle is empty, it's ok to recycle it, but if it contains a small amount of milk, it could result in contamination of the plastic recycling process. Likewise, paper fibres cannot be recycled if they are contaminated with food, so a cheesy pizza box shouldn't be recycled.  

Conscientious consumers are constantly faced with recycling conundrums. You've just finished a carton of juice. Should you remove the plastic cap before recycling the carton? You feel the fate of the planet lies in your hands. My advice: stop worrying and crack open a bottle of beer! …Hang on!…. what should you do with the bottle top?!  

词汇表  


<html><body><table><tr><td>aerosol</td><td>喷雾器</td></tr><tr><td>clued up</td><td>对某事了解很多，熟知的</td></tr><tr><td>kerbside</td><td>马路边</td></tr><tr><td>refuse</td><td>废物，垃圾</td></tr><tr><td>foil</td><td>锡，箔(纸)</td></tr><tr><td>contamination</td><td>污染</td></tr><tr><td>landfill</td><td>垃圾填埋，垃圾填埋场</td></tr><tr><td>to incinerate</td><td>焚烧</td></tr><tr><td>local authority</td><td>地方政府</td></tr><tr><td>recyclable</td><td>可回收的</td></tr><tr><td>wheelie bin</td><td>带轮子的垃圾箱</td></tr><tr><td>composting</td><td>制作堆肥的</td></tr><tr><td>caddy</td><td>小罐</td></tr><tr><td>coffee grindings</td><td>咖啡渣</td></tr><tr><td>council</td><td>市政</td></tr><tr><td>paper fibres</td><td>纸纤维</td></tr><tr><td>conscientious</td><td>认真的，用心的</td></tr><tr><td>conundrum</td><td>难题，复杂的问题</td></tr><tr><td>carton</td><td>塑料盒</td></tr><tr><td>cap</td><td>瓶盖</td></tr><tr><td>bottle top</td><td>瓶盖</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. True or false? Recycling in the UK is a relatively recent phenomenon.  

3. Why does the author of the article think people are confused by recycling? Give one reason.  

4. How often are rubbish and recycling bins collected in the UK?  

5.  What expression does the author use to indicate a sense of responsibility?  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. Don't throw ! I'll take it to the charity shop.  

2. That talk about recycling was a real of time. They didn't tell me anything I didn't already know!  

loss drain waste lack  

3. Today's solar energy industry has its in the 1970s during the oil embargos.  

vary roots stems branches  

4. The reason many recyclable items are rejected is because they are with food.  

contained contaminated composted consumed  

5. Global warming is possibly the biggest problem future generations will have to with.  

<html><body><table><tr><td>confront</td><td>face</td><td>deal</td><td>meet</td></tr></table></body></html>  

# 答案  

1. 阅读课文并回答问题。  

1. True or false? Recycling in the UK is a relatively recent phenomenon.   
False. In the UK recycling is well established.  

2. What happens to items that have been rejected for recycling? They end up in landfill or being incinerated.  

3. Why does the author of the article think people are confused by recycling? Give one reason. (Any one from) There are different kinds of containers for different items. The recycling system can differ from one local authority to another. Collection times vary. People have to remember which bin to put out each week.  

4. How often are rubbish and recycling bins collected in the UK? Every week or every two weeks  

5.  What expression does the author use to indicate a sense of responsibility? The fate of the planet lies in your hands.  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. Don't throw it out! I'll take it to the charity shop.  

2. That talk about recycling was a real  waste of time. They didn't tell me anything I didn't already know!  

solar energy industry has its roots in the 1970s during th  

4. The reason many recyclable items are rejected is because they are contaminated with food.  