# BBC LEARNING ENGLISH  

# Take Away E nglish 随身英语 Evolution before Darwin  

在达尔文提出进化论之前的人  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

You’ve heard of Charles Darwin, right? The celebrated scientist who proposed a theory of evolution. You might have just about heard of Alfred Russel Wallace, who co-authored, with  

Darwin, the revolutionary work On the Origin of Species, published in 1859. But what about Patrick Matthew? ‘Patrick who?’ you might ask. Well, Darwin and Wallace got the fame but Matthew did the legwork too.  

This British horticulturalist actually thought about evolution first, as Dr Mike Weale, geneticist at King’s College London, explains. He says: "Matthew published a brief outline of the idea of species being able to change into other species through natural selection. And he did that 27  

A statue of Darwin in his home town of Shrewsbury, UK  

years before Darwin and Alfred Russel Wallace. And they recognized that he did so but other people since have simplified the story and tended to concentrate just on Darwin."  

So Patrick Matthew's relative obscurity may simply be down to us – the general public – wanting to simplify things. But Dr Patricia Fara, senior tutor at Clare College Cambridge, points out that Darwin's work might have received more attention because he had powerful friends.  

"He brought his allies on board", she says. The academic explains that "although he was publishing from his stronghold down in Kent he had the most famous, most prominent members of the scientific society in Victorian times, who were pushing on his behalf. Having a scientific theory being accepted is not just a matter of whether the theory’s right."  

Maybe it is time for us to remember Patrick Matthew, a pioneer of the story of survival through adaptation that is at the heart of evolution.  

# 词汇表  

<html><body><table><tr><td>celebrated</td><td>著名的，受人敬仰的</td></tr><tr><td>theory of evolution</td><td>进化论</td></tr><tr><td>species</td><td>物种</td></tr><tr><td>to do the legwork</td><td>做跑腿的活儿</td></tr><tr><td>horticulturalist</td><td>园艺学家</td></tr><tr><td>outline</td><td>概论，概述</td></tr><tr><td>natural selection</td><td>物竞天择</td></tr><tr><td>obscurity</td><td>无名，默默无闻</td></tr><tr><td>allies</td><td>支持者，盟友</td></tr><tr><td>stronghold</td><td>大本营，居住地</td></tr><tr><td>prominent</td><td>著名的，重要的</td></tr><tr><td>on one's behalf</td><td>代表某人，为某人的利益</td></tr><tr><td>survival</td><td>生存</td></tr><tr><td>adaptation</td><td>改编</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. What changed the way people thought about the development of living things in the $19^{t h}$ century?   
2. What did Matthew work with?   
3. True or false? Darwin claimed that he was the only person who had come up with a theory of natural selection.   
4. What helped Darwin to become more famous than Matthew?   
5. What’s the central idea of the theory of evolution?  

# 2. 请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. The professor published the book but it was his assistant who . He collected the evidence which finally proved the theories.  

pushed on his behalf was down to us did the legwork recognised  

2. On the Origin of Species is too complicated for my students to read. I’ve decided to it and gave them a summary of this book on evolution.  

3. It’s through that some animals evolve while others just die out.  

evolution survival adaptation Darwin  

4. Ann is such a good student of English that her teachers decided to ask the principal to allow her to jump one semester.  

to do her legwork on her behalf to do her work to behalf  

5. When I have an exam to do, I to do the easy questions first and leave the difficult ones for later.  

<html><body><table><tr><td>tend</td><td>think</td><td>recognise</td><td>point out</td></tr></table></body></html>  

# 答案  

1. 阅读课文并回答问题。  

1. What changed the way people thought about the development of living things in the $19^{\mathrm{th}}$ century? The publication of On the Origin of Species by Darwin and Wallace in 1859.   
2. What did Matthew work with? Plants and trees – he was a horticulturalist.   
3. True or false? Darwin claimed that he was the only person who had come up with a theory of natural selection. False.  Dr Mike Weale, geneticist at King’s College London, says that Darwin recognised that Matthew thought of it first.   
4. What helped Darwin to become more famous than Matthew? Dr Patricia Fara, senior tutor at Clare College Cambridge, says he had influential people in the scientific society defending his ideas.   
5. What’s the central idea of the theory of evolution? The central idea of the theory of evolution is that species adapted to their environment to survive – the ones which didn’t adapt, disappeared.  

2. 请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. The professor published the book but it was his assistant who did the legwork. He collected the evidence which finally proved the theories.   
1. On the Origin of Species is too complicated for my students to read. I’ve decided to simplify it and gave them a summary of this book on evolution.   
2. It’s through adaptation that some animals evolve while others just die out. Ann is such a good student of English that her teachers decided to ask the principal on her behalf to allow her to jump one semester.   
3. When I have an exam to do, I tend to do the easy questions first and leave the difficult ones for later.  