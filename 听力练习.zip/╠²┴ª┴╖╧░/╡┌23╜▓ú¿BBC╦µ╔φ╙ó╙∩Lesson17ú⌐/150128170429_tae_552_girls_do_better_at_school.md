# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Girls do better at school  

女生在校学习成绩更好  

 关于台词的备注:请注意这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: education: 词汇：教育  

Around the world, girls do better than boys at school. These are the findings of a recent study that looked at the test results of 1.5 million 15-year-olds in 74 regions across the globe.  

The level of gender equality in those regions made no difference to the results. Other factors, such as the income level of the region also had little impact on the  

Girls get higher grades in UK exams  

findings. In only three regions – Colombia, Costa Rica and the Indian state Himachal Pradesh – was the trend reversed with boys doing better.  

So what are the causes of girls’ stronger performance? In the UK, girls outperform boys in exams that are taken at the age of 15 or 16, called GCSEs. According to education expert Ian Toone, this is down to the way girls and boys are brought up. “Boys are encouraged to be more active from an early age, whereas the restless movements of baby girls are pacified… Hence, girls develop the skill of sitting still for longer periods of time, which is useful for academic pursuits like studying for GCSEs."  

He goes on to say that boys often cluster together in larger groups than girls. Because of this they are more likely to be influenced by peer pressure and develop a gang mentality.  He says that GCSEs require a lot of solo work and are not viewed as 'cool' in a laddish culture.  

This is backed up by research in the UK that says girls are out-performing boys at the age of five. So what is the answer? Should girls and boys be educated separately? Or do exams and school curricula need to be changed to better reflect boys’ skills? These are the questions facing educators in many countries.  

# 词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. How many young people were included in the study?   
2. What are two things that made little or no difference to the results?   
3. According to Ian Toone, what skill do young girls develop that boys do not?   
4. What does he say can influence boys?   
5. What could be changed to include the skills boys have?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. Don’t join the university football team unless you like drinking beer and other behaviour.  

peer pressure cool laddish academic  

2. She’s been learning to fly, and today she had her first flight.  

cool pacified laddish solo  

3. The school is adding more science classes to its  

gang mentality gender equality factor curriculum  

4. According to this report, the of a country doesn't affect how happy the people are.  

income level academic pursuit influence gang mentality  

5. My paintings the world as I see it.  

reverse the trend of cluster reflect pacify  

# Answers and Glossary 答案与词汇  

# Quiz 小测验  

1. How many young people were included in the study? 1.5 million.   
2. What are two things that made little or no difference to the results? Gender equality and income level.   
3. According to Ian Toone, what skill do young girls develop that boys do not? Sitting still for longer periods of time.   
4. What does he say can influence boys? Peer pressure.   
5. What could be changed to include the skills boys have? Exams and school curricula.  

# Exercise 练习  

1. Don’t join the university football team unless you like drinking beer and other laddish behaviour.  

2. She’s been learning to fly, and today she had her first solo flight.  

3. The school is adding more science classes to its curriculum.  

4. According to this report, the income level of a country doesn't affect how happy the people are.  

5. My paintings reflect the world as I see it.  

# Glossary 词汇表  

<html><body><table><tr><td>gender equality</td><td>男女平等</td></tr><tr><td>factor</td><td>因素</td></tr><tr><td>income level</td><td>收入水平</td></tr><tr><td>to reverse a trend</td><td>逆转一种趋势</td></tr><tr><td>to pacify</td><td>使安静、平定</td></tr><tr><td>academic pursuit</td><td>学术追求</td></tr><tr><td>to cluster</td><td>（人）聚集</td></tr><tr><td>to influence</td><td>影响</td></tr><tr><td>peer pressure</td><td>同龄人压力</td></tr><tr><td>gang mentality</td><td>帮派心态</td></tr><tr><td>olos</td><td>单独的，独自地</td></tr><tr><td>cool</td><td>酷</td></tr><tr><td>laddish</td><td>幼稚的，孩子气的</td></tr><tr><td>school curricula</td><td>学校课程</td></tr><tr><td>to reflect</td><td>反映</td></tr></table></body></html>  