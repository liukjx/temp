# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Jogging to an early grave?  

慢跑会导致英年早逝？  

 关于台词的备注:请注意这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: health: 词汇：健康  

If you think that running marathons will help you live a long and healthy life, new research may come as a shock. According to a recent scientific study, people who do very strenuous activities are as likely to die as people who do no exercise at all.  

Scientists in Denmark have been studying over 1,000 joggers and non-joggers for 12 years. The death rates from the sample group indicate that people who jog at a  


Running faster doesn't meaning healthier  

moderate pace two or three times a week for less than two and a half hours in total are least likely to die. The best speed to jog at was found to be about 5 miles per hour (8km/h).  

The research suggests that people who jog more than three times a week or at higher speeds of over 7mph (11km/h) die at the same rate as non-joggers. The scientists think that this is because strenuous exercise causes structural changes to the heart and arteries. Over time, this can cause serious injuries.  

Peter Schnohr, a researcher in Copenhagen, said, "If your goal is to decrease risk of death and improve life expectancy, jogging a few times a week at a moderate pace is a good strategy. Anything more is not just unnecessary, it may be harmful."  

The implications of this are that moderate forms of exercise such as tai chi, yoga and brisk walking may be better for us than 'iron man' events, triathlons and long-distance running and cycling. According to Jacob Louis Marott, another researcher involved in the study, "You don't actually have to do that much to have a good impact on your health. And perhaps you shouldn't actually do too much".  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. Which long distance running event may actually be bad for us?   
2. How many people took part in the research?   
3. How often did the group that was least likely to die go jogging?   
4. What can cause changes to the heart?   
5. Which three forms of exercise may be better than strenuous activities?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. I went for a climb up the mountain yesterday, so today my legs are really stiff.  

marathon strenuous triathlon moderate  

2. Your carry blood away from your heart.  

3. Our house suffered some damage during the earthquake.  

structural brisk impact likely  

4. Closing the school will have for everyone in the community.  

pace impact strategies implications  

5. At 87 years, women in Japan have the world's longest  

sample group life expectancy strategy rate  

# Answers and Glossary 答案与词汇  

# Quiz 小测验  

1. Which long distance running event may actually be bad for us? The marathon.   
2. How many people took part in the research? 1,000.   
3. How often did the group that was least likely to die go jogging? Two or three times a week.   
4. What can cause changes to the heart? Strenuous exercise.   
5. Which three forms of exercise may be better than strenuous activities? Tai chi, yoga and brisk walking.  

# Exercise 练习  

2. Your arteries carry blood away from your heart.  

3. Our house suffered some structural damage during the earthquake.  

4. Closing the school will have implications for everyone in the community.  

5. At 87 years, women in Japan have the world's longest life expectancy.  

# Glossary 词汇表  

<html><body><table><tr><td>marathon</td><td>马拉松</td></tr><tr><td>strenuous</td><td>剧烈的</td></tr><tr><td>likely</td><td>很可能的</td></tr><tr><td>sample group</td><td>抽样组</td></tr><tr><td>moderate</td><td>中等的，适度的</td></tr><tr><td>pace</td><td>步速，节奏</td></tr><tr><td>rate</td><td>比率</td></tr><tr><td>structural</td><td>结构性的</td></tr><tr><td>artery</td><td>动脉</td></tr><tr><td>life expectancy</td><td>预期寿命</td></tr><tr><td>strategy</td><td>策略</td></tr><tr><td>implication</td><td>暗示</td></tr><tr><td>brisk</td><td>轻快的</td></tr><tr><td>triathlon</td><td>三项全能运动</td></tr><tr><td>impact</td><td>效果，影响</td></tr></table></body></html>  