# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Saving Mr Chimp  

拯救大猩猩先生  

 关于台词的备注:请注意这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: judicial case 庭审案例  

Should animals be entitled to the same rights as people? The question is not so outlandish. A judge in the US once suggested that chimpanzees had the right to habeas corpus. Judge Barbara Jaffe was ruling on the case of Leo and Hercules. These two primates have their own lawyers arguing that they should be moved from a university lab to an animal sanctuary. She did change her mind after a while.  


Does friendship mean anything to him (or it)?  

Animals have always intrigued us. Some people find them very intelligent and capable of friendship, jealousy and longing. That's enough to give them rights, isn't it? Not for people like Professor Carl Cohen of the University of Michigan. He says that rights are a concept special to the human moral code. And animals don't know anything about right and wrong. The academic points out: "Animals do not commit crimes; animals are not attacked for their moral views."  

In any case, humans have become more sensitive to animal suffering throughout the years. In 1999, New Zealand granted basic rights to five great ape species. Their use in research, testing or teaching was banned in a move seen as the greatest legal success in animal rights history.  

In 2002, in an unprecedented move in the European Union, Germany granted some rights to animals in its constitution.  

The ambiguous relationship between people and animals can be perceived in language. In English the pronoun used for an animal is 'it'. But many people refer to their pets as 'he' or 'she'. It makes them more of an equal to us.  

What do you think? Should animals have rights similar to h 词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. Who might be moving from a lab to a sanctuary?   
2. What do animals lack, according to Professor Carl Cohen?   
3. What can't apes be used for in New Zealand?   
4. Which pronouns can you use for animals in English?   
5. Which noun means feeling pain or distress?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. When Joanne got divorced the judge said she was to half of her husband assets.  

granted entitled given taken  

2. Men and women are before the law.  

sensitive relative equal similar  

3. I must point that not everything you say is true.  

at to on out  

4. The judge told Mr. Ross: "If you the crime, you have to accept the punishment."  

make commit act take  

5. Lady Gaga wears clothes. She has even worn an outfit made of meat!  

<html><body><table><tr><td>outside</td><td>out of bounds outlandish</td><td></td><td>out of order</td></tr></table></body></html>  

# Answers and Glossary 答案与词汇  

# Quiz 小测验  

1. Who might be moving from a lab to a sanctuary? Primates Leo and Hercules.   
2. What do animals lack, according to Professor Carl Cohen? A moral code, which includes the concept of right and wrong.   
3. What can't apes be used for in New Zealand? Research, testing or teaching.   
4. Which pronouns can you use for animals in English? It, she, he, them.   
5. Which noun means feeling pain or distress? Suffering.  

# Exercise 练习  

1. When Joanne got divorced the judge said she was entitled to half of her husband assets.   
2. Men and women are equal before the law.   
3. I must point out that not everything you say is true.   
4. The judge told Mr. Ross: "If you commit the crime, you have to accept the punishment."   
5. Lady Gaga wears outlandish clothes. She has even worn an outfit made of meat!  

# Glossary 词汇表  

<html><body><table><tr><td>to be entitled</td><td>有资格的，有资格享受的</td></tr><tr><td>outlandish</td><td>奇异古怪的</td></tr><tr><td>a judge</td><td>一位法官</td></tr><tr><td>habeas corpus</td><td>人身保护权</td></tr><tr><td>to rule</td><td>（动词）裁决</td></tr><tr><td>to argue</td><td>争辩</td></tr><tr><td>an animal sanctuary</td><td>一个动物庇护所、动物保护区</td></tr><tr><td>a moral code</td><td>一项道德规范</td></tr><tr><td>to commit crimes</td><td>犯罪</td></tr><tr><td>to grant basic rights</td><td>授予基本权力</td></tr><tr><td>legal</td><td>法律（上）的</td></tr><tr><td>unprecedented</td><td>前所未有的，没有先例的</td></tr><tr><td>constitution</td><td>宪法，大法</td></tr><tr><td>ambiguous</td><td>模糊的，不明确的</td></tr></table></body></html>  