# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Can a lie-in make you healthier?  

睡懒觉能让你更健康？  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

Vocabulary: sleep 词汇：睡眠  

Every morning, my alarm goes off, I wake from my slumber and hit the snooze button. Then I crawl back under the duvet to grab a few more minutes of shut-eye. “Tonight I’ll go to bed early,” I tell myself. But, evening comes and I get a second wind, completely forgetting about my early night.  


Why am I finding it so difficult to get a good night’s sleep?  And is it a problem? The amount we sleep has declined over the years and insomnia is on the rise. Modern technology is often blamed. The light from our smartphone affects levels of melatonin – the sleep-inducing hormone - keeping us wide awake into the early hours.  

Lack of sleep can badly affect our health and memory. We need deep sleep to move our memories from short-term storage into long-term storage. If we don’t get enough sleep, we could lose these memories. This is especially disastrous for people studying for exams.  

So, how can we learn to sleep better? For Professor Till Roenneberg, it's important people recognise they have an internal body clock. This determines whether you are a night owl, an early bird or somewhere in the middle. We don’t have any choice. “It’s like feet,” he said “Some people are born with big feet and some with small feet, but most people are somewhere in the middle.”  Our work schedules are out of sync with our natural sleep patterns. He says this leads to “social jetlag” where people feel like they are constantly in the wrong time zone.  

Paul Kelley – a sleep expert from the University of Oxford – says that most people are getting up too early. He believes work and school should start a few hours later. Many companies are starting to realise more sleep can mean a more productive workforce and are changing work schedules. While in South Korea, office workers are heading to relaxation parlours at lunchtime to take power naps in hammocks or massage chairs. This is much healthier than catching forty winks while sitting on the toilet or dropping off at their desks.  

So, if like me you find yourself hitting your snooze button every morning – don't feel bad. It’s just our body clocks!  

词汇表  


<html><body><table><tr><td>slumber 睡眠</td><td></td></tr><tr><td>snooze button</td><td>（催醒闹钟的）延时按钮</td></tr><tr><td>shut-eye</td><td>睡眠</td></tr><tr><td>get a second wind</td><td>恢复的精力或力量</td></tr><tr><td>early night</td><td>早睡</td></tr><tr><td>insomnia</td><td>失眠</td></tr><tr><td>melatonin</td><td>褪黑素</td></tr><tr><td>wide awake</td><td>完全清醒</td></tr><tr><td>the early hours</td><td>凌晨</td></tr><tr><td>body clock</td><td>生物钟</td></tr><tr><td>night owl</td><td>夜猫子</td></tr><tr><td>early bird</td><td>早起者</td></tr><tr><td>sleep patterns</td><td>睡眠规律</td></tr><tr><td>jetlag</td><td>时差反应</td></tr><tr><td>power nap</td><td>打盹，小睡</td></tr><tr><td>hammock</td><td>吊床</td></tr><tr><td>catch forty winks</td><td>（白天的）打盹、小睡</td></tr><tr><td>drop off 睡着了</td><td></td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. Is the writer an early bird or a night owl? How do you know?  

2. How do smartphones disrupt our sleep?  

3. True or false? Our short-term memory improves when we don’t get enough sleep?  

4. What is “social jetlag”?  

5. What do office workers in Korea do to help them concentrate better at work?  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  
1. I am an - I’m at my best in the mornings.  

night owl night bird early bird early owl  

had really bad last night – I couldn’t get to sleep for  

Power nap melatonin insomnia sleep  

3. The film was so boring that I while I was watching it.  

drop off dropped  off droped off dropped of  

4. I suffer from really bad whenever I travel back from the USA.  

jetlag lagjet jets lag jetlags  

5. I need a quick before I go out tonight – if I don’t I’ll never stay awake.  

slumber power nap hammock second wind  

# 答案  

1. 阅读课文并回答问题。   
1. Is the writer an early bird or a night owl? How do you know?  He's a night owl, because he's often wide awake at night but finds it difficult to wake up in the morning.   
2. How do smartphones disrupt our sleep?  They affect the amount of melatonin we produce. This is a chemical which helps us sleep well.   
3. True or false? Our short-term memory improves when we don’t get enough sleep?  False. It gets worse.   
4. What is “social jetlag”?  “Social jetlag” is a phenomenon where your sleep pattern and work schedule don't match, meaning you feel constantly tired - as if you are in the wrong time zone.   
5. What do office workers in Korea do to help them concentrate better at work?  They have short power naps to restore energy and alertness.   
2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。   
1. I am an early bird - I’m at my best in the mornings.   
2. I had really bad insomnia last night – I couldn’t get to sleep for hours.   
3. The film was so boring that I dropped off while I was watching it.   
4. I suffer from really bad jetlag whenever I travel back from the USA.   
5. I need a quick power nap before I go out tonight – if I don’t I’ll never stay awake.  