# Take Away English 随身英语 11 August 2014  

# Reaching for the sky 城市摩天大楼 直冲云端  

Vocabulary: buildings 楼房  

When you're walking around a city, how often do you look up and admire the view? Many of us are in too much of a rush to appreciate the architecture all around us.  

Cities are always growing, and when space is at a premium, they expand upwards – reaching for the sky. The skylines of many modern cities are full of skyscrapers: landmarks that can be seen for miles around.  

What will the London skyline look like in ten years?  

These iconic buildings are often must-see  

sights for tourists and locals alike. New York has its Empire State Building and the glitzy skyscrapers of Manhattan. Dubai has the world's tallest tower, the Burj Khalifa, which stands at 828 metres; and Shanghai has the world's number two with the completion of the Shanghai Tower. London hasn't always been associated with the race for vertical expansion, but since the opening of Canary Wharf tower in the city's Docklands area, the development of high-rise buildings has been unstoppable.  

Now London boasts new skyscrapers with quirky nicknames that reflect the shapes of the buildings - like the Gherkin, the Cheese Grater and the Walkie Talkie. Standing tall amongst them is the Shard – and at 309 metres it's Europe's tallest building.  

But they are not loved by everyone. While some prefer them to uninspiring rows of office blocks, others say they obstruct the sightlines of old-fashioned landmarks and that they threaten London's cultural identity. Some say they're just plain ugly!  

A group of high-profile Londoners, politicians, artisans and academics are now campaigning to halt certain high-rise developments. Jonathan Glancey, an architecture and design critic and writer, says: "The sad thing is that the quality of the 200 buildings proposed is remarkably low, like weeds in a garden, like Japanese knotweed spreading across the city, and it's something that needs to be stopped."  

Of course change and development is inevitable in any growing city. Demand for living, office and retail space is increasing, but why is the only way up? Could London become a city that pioneers building downwards, for example?  

think? Should we be building bigger and taller skysc  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. Which New York skyscraper is mentioned in the article?   
2. Why do some of the new skyscrapers in London have names like the Cheese Grater and the Gherkin?   
3. Which word used in the article means 'stop'?   
4. Give one reason why some people don't want any more skyscrapers to be built in London.   
5. Why do more buildings need to be built in cities?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. I really my grandfather.  He's very old but still managed to walk to the top of the mountain without complaining!  

admire admiral adverb admirable  

2. The Eiffel Tower is a really landmark in Paris. If you're visiting the city you've got to see it!  

ironic iphonic iconic eyesore  

3. The new exhibition at the art gallery was I've seen that type of artwork so many times before.  

unintentional underhand uninspiring unusual  

4. The people of Scotland are very proud of their nation's history and culture. They have a strong cultural  

5. My brother wants to manage a department store so he's going to study for a qualification in management.  

<html><body><table><tr><td>environmental</td><td>media</td><td>project</td><td>retail</td></tr></table></body></html>  

# Quiz 小测验  

1. Which New York skyscraper is mentioned in the article? The Empire State Building.   
2. Why do some of the new skyscrapers in London have names like the Cheese Grater and the Gherkin? They are nicknames that reflect the shapes of the buildings.   
3. Which word used in the article means 'stop'? Halt.   
4. Give one reason why some people don't want any more skyscrapers to be built in London. People say skyscrapers obstruct the sightlines of old-fashioned landmarks, they threaten London's cultural identity, and they're just plain ugly.   
5. Why do more buildings need to be built in cities? Because there is an increasing demand for living, office and retail space.  

# Exercise 练习  

1. I really admire my grandfather. He's very old but still managed to walk to the top of the mountain without complaining!  

2. The Eiffel Tower is a really iconic landmark in Paris. If you're visiting the city you've got to see it!  

3. The new exhibition at the art gallery was uninspiring. I've seen that type of artwork so many times before.  

4. The people of Scotland are very proud of their nation's history and culture. They have a strong cultural identity.  

5. My brother wants to manage a department store so he's going to study for a qualification in retail management.  

# Glossary 词汇表  

<html><body><table><tr><td>to admire 欣赏</td><td></td></tr><tr><td>architecture</td><td>建筑物</td></tr><tr><td>at a premium</td><td>（空间因稀少或难得）昂贵，寸土寸金</td></tr><tr><td>skyline</td><td>（以天空为背景映出的）轮廓</td></tr><tr><td>skyscraper</td><td>摩天大楼</td></tr><tr><td>landmark</td><td>地标 (建筑)</td></tr><tr><td>iconic</td><td>标志性的</td></tr><tr><td>must-see</td><td>必看的</td></tr><tr><td>vertical expansion</td><td>（城市）垂直纵向扩展</td></tr><tr><td>quirky</td><td>奇特的</td></tr><tr><td>gherkin</td><td>酸黄瓜 (伦敦一栋摩天大厦的昵称)</td></tr><tr><td>cheese grater</td><td>奶酪刨 (伦敦一栋摩天大厦的昵称)</td></tr><tr><td>walkie talkie</td><td>对讲机 (伦敦一栋摩天大厦的昵称)</td></tr><tr><td>uninspiring</td><td>不吸引人的，引不起兴趣的</td></tr><tr><td>sightline</td><td>（从眼睛到所见物之间的）视线</td></tr><tr><td>cultural identity</td><td>文化特征、认同</td></tr><tr><td>retail</td><td>零售</td></tr></table></body></html>  