# BBC LEARNING ENGLISH  

# Take Away English 随身英语 The daily commute  

每天上下班  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: commuting 上下班  

The daily journey to and from home and work is one of those things that many of us have to endure. Whether by train, bus, bike or on foot, it's a routine that some people could rather do without but if we have to work, the daily grind is all part of the job!  

We all have stories of commuting nightmares – a tube train stuck in a tunnel or a bus journey where people are packed in like sardines. In London, where there is an extensive transport network, complaining about delays, cancellations and the price of their season ticket, has become a commuter's favourite past time but their problems are relatively minor compared to ones that travellers in other parts of the world face. In Nairobi, for example, commuters have to keep windows shut to avoid someone stealing their belongings.  

Same train, same time – same newspaper?  

It's no surprise that the daily commute is stressful and according to research, women are more likely to experience stress during their journey than men. This is because they're more likely to do something which is being called 'trip chaining' – where they make one or more stops on the way to work or when going home – for example to drop off or pick up the kids from school – and this makes it more likely that something will go wrong with their journey.  

The stress of commuting can be bad for your health too especially if you travel longer distances. According to Christine Hoehner, researcher at Washington University School of Medicine "adults who commuted longer distances from home to work were less physically active, less physically fit, weighed more and had higher blood pressure than those people who had shorter commutes."  

But the American researcher must be talking about commuters who aren't engaged in active travel, because if you cycle a longer distance then you're likely to be more physically active. However there is a risk of being knocked off you bike and there's the embarrassment of wearing clothing made of Lycra! What's your journey to work, college or school like?  

词汇表  


<html><body><table><tr><td>endure</td><td>忍受，忍耐</td></tr><tr><td>the daily grind</td><td>每天必须经历的苦差</td></tr><tr><td>tube train</td><td>一辆地铁</td></tr><tr><td>packed in like sardines</td><td>挤得像罐头里的沙丁鱼 (拥挤不堪)</td></tr><tr><td>cancellations</td><td>取消</td></tr><tr><td>season ticket</td><td>季票，定期票(比如月票，年票)</td></tr><tr><td>network</td><td>（交通）网络</td></tr><tr><td>past time</td><td>消遣方式</td></tr><tr><td>belongings</td><td>行李，个人财产</td></tr><tr><td>stressful</td><td>有压力的</td></tr><tr><td>'trip chaining'</td><td>分段出行 （一个旅程被分成好几小段)</td></tr><tr><td>physically active</td><td>身体活跃</td></tr><tr><td>Lycra</td><td>莱卡 (制衣材料)</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. True or false? Officially, commuting is only happens when you travel by train.  

2.  Name something that commuters in London get angry about.  

3.  Why do women tend to find commuting more stressful?  

4.  What type of blood pressure do commuters who travel longer distances have?  

5. Which word used in the articles means 'feeling ashamed because of what people think or know about you'?  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. Now my holiday is over it's back to the of washing and ironing the family's clothes!  

day grint daily grind daily grinding daily ground  

2. The dentist had a so he was able to see me and get my filling done.  

3. My doctor says I need to be more if I want to reduce the chances of having a heart attack.  

physically active actively physical physically activated physical activation  

4.  We had to all the speeches at the wedding before we had anything to eat. I was starving!  

encourage enhance endure enact  

5. Our car broke down on the way to the airport which made the journey very  

stressless stressing stressful stressed  

# 答案  

1. 阅读课文并回答问题。  

1. True or false? Commuting only refers to train trave.l False. Commuting means to travel regularly to and from work by any form of transport.   
2.  Name something that commuters in London get angry about. Complaining about delays, cancellations or the price of their season ticket.   
3.  Why do women tend to find commuting more stressful? They often they make one or more stops on the way to work or going home.   
4.  What type of blood pressure do commuters who travel longer distances have? They have higher blood pressure compared to those people who had shorter commutes.   
5. Which word used in the articles means 'feeling ashamed because of what people think or know about you'? The word is 'embarrassment'.   
2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格   
处。   
1. Now my holiday is over it's back to the daily grind of washing and ironing the family's clothes!   
2. The dentist had a cancellation so he was able to see me and get my filling done.   
3. My doctor says I need to be more physically active if I want to reduce the chances of having a heart attack.   
4. We had to endure all the speeches at the wedding before we had anything to eat. I was starving!   
5. Our car broke down on the way to the airport which made the journey very stressful.  