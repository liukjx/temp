# Take Away English 随身英语 3 May 2012  

# Be brainy, be bilingual 双语能增强大脑能力  

英语学习点: 有关科学实验的词语 Vocabulary: scientific experiment  

Learning a second language can boost brain power, scientists believe.  

US researchers from Northwestern University say bilingualism is a form of brain training - a mental "work out" that fine-tunes the mind.  

Speaking two languages affects the brain and changes how the nervous system reacts to sound, lab tests revealed.  

Experts say the work, put forward for peer  

review in Proceedings of the National Academy of Sciences, provides "biological" evidence of this.  


In an attempt to prove the hypothesis that speaking two languages is good for one's mind, the team monitored how the brains of 48 healthy student volunteers reacted to different sounds. Twenty-three of these volunteers were bilingual.  

The scientists used scalp electrodes to trace the pattern of brainwaves.  

Under quiet, laboratory conditions, the bilingual students responded in a similar way to the English-only-speaking students, who formed the control group.  

But the bilingual group was far superior at processing sounds even when there were a lot of people talking in the room. They were better able to tune in to the important information - the speaker's voice - and block out other distracting noises.  

Prof Nina Kraus, who led the research, said: "The bilingual's enhanced experience with sound results in an auditory system that is highly efficient, flexible and focused in its automatic sound processing, especially in challenging or novel listening conditions."  

Co-author Viorica Marian said: "People do crossword puzzles and other activities to keep their minds sharp. But the advantages we've discovered in dual language speakers come automatically, simply from knowing and using two languages.''  

Musicians appear to gain a similar benefit when rehearsing, say the researchers.   
According to some theories, being bilingual might help ward off dementia.  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. If you are bilingual, how many languages can you speak fluently?   
2. What two groups of volunteers took part in the experiment?   
3. How were the volunteers in the bilingual group better at processing sounds?   
4. True, false or not given: Bilingual students are better at solving crossword puzzles.   
5. Look at the article. Can you find the expression used when referring to preventing something from   
happening?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. Peter is a highly-skilled surgeon. He has to block ____ all emotions and concentrate hard whilst on a job.  

in out away off  

2. Many buildings collapsed during last month's earthquake. Engineers have been the ones still standing to make sure they won't have the same fate.  

mentoring processing distracting monitoring  

3. Researchers looked at how pupils on the Active Literacy programme performed in reading tests and compared it with children in a group.  

control controlling processing peer-reviewed  

4. My grandmother is very fit, active and reads a lot. Even at a good old age, she keeps her mind  

5. It's said that the best way to live long is to eat healthily and work often.  

in away off out  

# Quiz 小测验  

1. If you are bilingual, how many languages can you speak fluently? Two.   
2. What two groups of volunteers took part in the experiment? Students who speak only English and students who speak two languages.   
3. How were the volunteers in the bilingual group better at processing sounds? They were better able to concentrate on the important information and ignore noises that caused distraction.   
4. True, false or not given: Bilingual students are better at solving crossword puzzles. Not given. All the article says is that they are better at processing sounds.   
5. Look at the article. Can you find the expression used when referring to preventing something from happening? To ward off.  

# Exercise 练习  

1. Peter is a highly-skilled surgeon. He has to block out all emotions and concentrate hard whilst on a job.   
2. Many buildings collapsed during last month's earthquake. Engineers have been monitoring the ones still standing to make sure they won't have the same fate.   
3. Researchers looked at how pupils on the Active Literacy programme performed in reading tests and compared it with children in a control group.   
4. My grandmother is very fit, active and reads a lot. Even at a good old age, she keeps her mind sharp.   
5. It's said that the best way to live long is to eat healthily and work out often.  

Glossary 词汇表  


<html><body><table><tr><td>to work out</td><td>锻炼</td></tr><tr><td>to fine-tune</td><td>微调</td></tr><tr><td>the nervous system</td><td>神经系统</td></tr><tr><td>a lab test</td><td>试验室测验</td></tr><tr><td>peer-review</td><td>同级评估</td></tr><tr><td>evidence</td><td>证据</td></tr><tr><td>a hypothesis</td><td>假想</td></tr><tr><td>to monitor something</td><td>监视 (什么)</td></tr><tr><td>an electrode</td><td>电极</td></tr><tr><td>laboratory conditions</td><td>（在）试验室条件（下)</td></tr><tr><td>a control group</td><td>控制组</td></tr><tr><td>to tune in to (something)</td><td>收听（什么东西）／入耳</td></tr><tr><td>to block (something) out</td><td>排斥 (什么)</td></tr><tr><td>the auditory system</td><td>听觉系统</td></tr><tr><td>to process (something)</td><td>处理 (什么)</td></tr><tr><td>to keep (one's) mind sharp</td><td>让（他们的）大脑敏捷</td></tr><tr><td>a theory</td><td>理论</td></tr><tr><td>to ward (something) off</td><td>挡避 (什么)</td></tr></table></body></html>  