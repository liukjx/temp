# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Brain training  

如何训练大脑？  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# 词汇: Neuroscience 神经科学  

Our brain is probably the most important organ in our body. It's an incredibly complex thing that helps us think, speak, feel and move. It's no wonder we need to look after it and just like the rest of our body, we need to keep it exercised to keep it healthy.  

Our brain is made up of 86 billion neurons – or nerve cells – but as we get older some of these slowly die off. In extreme cases, nerve cells in different areas of the brain become  

There's a lot going on inside our head  

damaged and eventually die causing a condition called dementia where a person is unable to perform certain mental functions.  

It's a good idea to train our brain by learning ways to increase our memory or intelligence.  I like to stretch my brain by doing a crossword or a Sudoku puzzle. There's also evidence that learning a second language can boost your brainpower. Dr Catherine Loveday, who's a neuropsychologist, thinks being bilingual is a protective factor for the brain because it "involves a lot of switchings and that seems to exercise the sort of executive parts of our brain. Those parts of the brain are kind of stronger and fitter when it comes to resisting some kind of damage from a stroke."  

But if you're not bilingual there are other ways to stretch your brain: If you're right handed, doing tasks like brushing your teeth with your left hand will improve your brain – or something I find very challenging, memorising a list of words, such as a shopping list.  

The main aim of trying these skills is to stimulate the brain. This is something Dr. Loveday describes as building up our cognitive reserve – that's building up extra abilities to help protect the brain against declining memory or thinking.  She says "even if people take up languages or take up other things later in life it will give them a degree of protection."  As I get older, that has put my mind at rest!  

The best bit of research I have read is that eating chocolate may enhance our ability to acquire and utilise knowledge – that's our cognitive performance. It may not be healthy for the rest of my body but at least it might make me a brain box! What do you think?  

词汇表  


<html><body><table><tr><td>organ 器官</td></tr><tr><td>neurons 神经元</td></tr><tr><td>nerve cells 神经细胞</td></tr><tr><td>dementia 痴呆症、失智症</td></tr><tr><td>mental functions 精神机能</td></tr><tr><td>intelligence 智力</td></tr><tr><td>crossword 填字游戏</td></tr><tr><td>brainpower</td></tr><tr><td>脑力，智力 neuropsychologist</td></tr><tr><td>神经心理学家 ensu!lq</td></tr><tr><td>（能使用）两种语言的，双语的 executive</td></tr><tr><td>执行指令的 resisting</td></tr><tr><td>抵抗，抵御 stroke</td></tr><tr><td>中风 stimulate</td></tr><tr><td>促进（身体某部位）的功能 challenging</td></tr><tr><td>有挑战性的 cognitive reserve</td></tr><tr><td>认知储备 abilities</td></tr><tr><td>能力 put my mind at rest</td></tr><tr><td>让我放心了 enhance</td></tr><tr><td>提高，增强</td></tr><tr><td>utilise 利用，使用</td></tr><tr><td>cognitive performance 认知表现，认知能力</td></tr><tr><td>a brain box 非常聪明的人</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. In the article, what was the brain described as?   
2. Name something you can do to help train your brain.   
3. True or false: Being bilingual helps you brush your teeth with your left hand.   
4. What word used in connection with using your brain means 'using all your intelligence or   
ability.'?   
5. What do some people believe can make you more intelligent but might also make you fat?  

# 2. 请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. The entrance exam was designed to test the student's  

intelligent intelligance intelligence insignificance  

2. John was unable to the temptation of having another slice of chocolate cake.  

stimulate enhance utilise resist  

3. Please let me know when you arrive home, it will put my at rest.  

brain mind neurons body  

4. The newly refurbished carriages will certainly people's experience of travelling by train.  

enhance stimulate challenge utilise  

5. Martin is a bit of a so we're glad to have him on our team for the pub quiz.  

boxed brain brain drain brain box brained box  

# 答案  

1. 阅读课文并回答问题。  

1. In the article, what was the brain described as? An organ.  

2. Name something you can do to help train your brain.   
Doing a crossword or Sudoku puzzle,  learning another language.  

3. True or false: Being bilingual helps you brush your teeth with your left hand. False. The article said if you're right handed, doing tasks like brushing your teeth with your left hand will improve your brain.  

4. What word used in connection with using your brain means 'using all your intelligence or ability.'?   
The word is 'stretch' ['stretch your brain'].  

5. What do some people believe can make you more intelligent but might also make you fat? Eating chocolate.  

2. 请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. The entrance exam was designed to test the student's intelligence.  

2. John was unable to resist the temptation of having another slice of chocolate cake.  

se let me know when you arrive home, it will be my min  

4. The newly refurbished carriages will certainly enhance people's experience of travelling by train.  