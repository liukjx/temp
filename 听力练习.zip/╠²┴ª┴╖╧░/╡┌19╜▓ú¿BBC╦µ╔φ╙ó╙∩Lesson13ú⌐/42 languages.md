# Take Away English 随身英语 9 June 2014  

# 42 languages 操场上的 42 种不同语言  

Vocabulary: School 词汇: 学校  

Byron Court, a school in north-west London, gets high marks for integration. No fewer than 42 languages are spoken in the playground. The 600 pupils from places as far apart as Iraq, the Philippines, Somalia, India, Romania and Slovakia mingle and play together.  

Many of these children spoke no English at all when they arrived in the UK aged five to eight years old. But they learn quickly. Martine Clark, the school's executive head teacher, believes that unity is very important. She says: "It's vital there's no differentiation between any languages or any culture. We do that by celebrating the diversity of the culture in our school."  

Children adapt quickly to new environments  

According to Clark, the children that come to Byron Court are adaptable and resilient. Having such a variety of backgrounds makes them better learners. Some have struggled, not always understanding instructions in the classroom. But after a few years, many have turned the disadvantage of not speaking English into the advantage of being bilingual.  

Nonetheless, educational standards can suffer when not everyone speaks the same language, at least to begin with. Though according to Martyn Pendergast, an education officer at Brent Council, this doesn't last for long: "It takes time to learn English and in Brent our children perform just below the national average when they are assessed at seven years old. But by the time they're 11 they've caught up with national standards and at 16 they're flying".  

Those who don't speak English but are used to discipline often progress rapidly. But some are concerned about children who are native speakers of English. Christopher McGovern, the chairman of the Campaign for Real Education, which aims to promote a greater emphasis on traditional values, says: "The problem is not the migrant children. The problem is the white working class children who are doing very badly at school."  

McGovern believes many parents think a lot of attention is given to migrant children, while their own children are being neglected.  

White British families and second-generation immigrants have been moving out of schools near urban centres to more distant suburbs, or to the countryside. That's a process which raises its own questions about the future of education in British cities.  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. How is unity maintained in a school with children from so many different backgrounds?   
2. True or False: Many immigrant children find it difficult to understand classroom instructions?   
3. When do pupils catch up with the national average in terms of assessments?   
4. True or False: Some working class parents aren't happy because their children can't understand immigrant students?   
5. Which expression means 'people who were born in a country their parents moved to'?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. Betty is very confident and successful. Nobody would believe that she really at the beginning of her career.  

<html><body><table><tr><td>celebrated</td><td>struggled</td><td>progressed</td><td>was assessed</td></tr></table></body></html>  

2. My mother told me to get married and have children. She's a supporter of  

traditional values working class educational standards integration  

3. I spend about an hour in traffic every day. I'd like to move to the and live on a farm.  

4. Mario was born into a family but became the CEO of a big company.  

immigrant suburbs working class adaptable  

5. You should buy a good quality fridge. It's expensive but the is that it will last you a long time.  

advantage disadvantage background emphasis  

# Quiz 小测验  

1. How is unity maintained in a school with children from so many different backgrounds? By not differentiating between different languages or cultures and celebrating diversity.   
2. True or False: Many immigrant children find it difficult to understand classroom instructions? True.   
3. When do pupils catch up with the national average in terms of assessments? By 11 years old.   
4. True or False: Some working class parents aren't happy because their children can't understand immigrant students? False. They aren't happy because they believe too much attention is given to migrant children and their own are forgotten.   
5. Which expression means 'people who were born in a country their parents moved to'? Second-generation immigrants.  

# Exercise 练习  

1. Betty is very confident and successful. Nobody would believe that she really struggled at the beginning of her career.   
2. My mother told me to get married and have children. She's a supporter of traditional values.   
3. I spend about an hour in traffic every day. I'd like to move to the countryside and live on a farm.   
4. Mario was born into a working class family but became the CEO of a big company.   
5. You should buy a good quality fridge. It's expensive but the advantage is that it will last you a long time.  

<html><body><table><tr><td>to get high marks for (something)</td><td>在（某方面）获得高分</td></tr><tr><td>integration</td><td>(种族之间的)融合</td></tr><tr><td>playground</td><td>操场</td></tr><tr><td>to mingle</td><td>交际，交往</td></tr><tr><td>head teacher</td><td>校长/教务长</td></tr><tr><td>differentiation</td><td>区别</td></tr><tr><td>to celebrate</td><td>庆祝，赞扬</td></tr><tr><td>adaptable</td><td>适应能力强的</td></tr><tr><td>resilient</td><td>有弹性的，坚忍不拔的</td></tr><tr><td>educational standards</td><td>教育水平</td></tr><tr><td>to assess</td><td>评估，考查</td></tr><tr><td>traditional values</td><td>传统价值</td></tr><tr><td>working class</td><td>工薪阶层</td></tr><tr><td>to neglect</td><td>疏忽，不予重视</td></tr><tr><td>second generation</td><td>第二代</td></tr><tr><td>suburb</td><td>市郊</td></tr></table></body></html>  