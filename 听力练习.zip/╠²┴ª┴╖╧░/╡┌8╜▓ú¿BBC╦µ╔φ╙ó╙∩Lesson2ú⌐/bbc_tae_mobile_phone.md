# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Are you addicted to your phone?  

你是不是玩手机上瘾了？  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: mobile phone 词汇: 手机  

How often do you check your phone? According to a study led by Nottingham Trent University in Britain, the average person looks at their device 85 times a day, browsing the internet or using apps.  Updating their status on social media platforms also made people reach for their electronic companion frequently.  

Mobile phone: Could you live without it?  

Even the study's participants thought that was a   
lot: this figure is twice as often as they thought they did. Our phones might be shaping our behaviour more than we realise, and changing the way we interact with people right next to us. Do you actually look at your surroundings more than at your phone? Is it rude to check your phone when someone is talking to you?  

Sherry Turkle interviewed hundreds of college students about this. She's a clinical psychologist and a professor of social studies at the Massachusetts Institute of Technology. They talked about something they called 'the rule of three'.  

The rule has to do with being considerate to others in spite of the allure of the little flat box. Turkle explains: "If you go to dinner with friends, you don't want to look down at your phone until you see that three people are looking up in the conversation. So there's a new etiquette where you don't look down unless three people are looking up in order to keep a little conversation alive."  

Actually, if you are clever enough you might use your phone as a tool to connect with people next to you. How about showing them pictures stored in its memory? Sharing a bit of your life with them can bring you closer together. And you can also invite everyone to take a selfie with you.  

But the best thing to deal with mobile phone addiction is to go cold turkey and leave the machine behind occasionally or just switch it off and keep it firmly in your pocket for a while. Who knows… 'life' might be what happens when you are too busy staring at a small screen.  

# 词汇表  

<html><body><table><tr><td>device 设备</td><td></td></tr><tr><td>to browse</td><td>（通过网络）浏览</td></tr><tr><td>app (application)</td><td>手机应用程序</td></tr><tr><td>to update (their) status</td><td>更新（个人网站上的）状态</td></tr><tr><td>social media platform</td><td>社交媒体平台</td></tr><tr><td>to shape</td><td>塑造，形成</td></tr><tr><td>to interact</td><td>互动，交流</td></tr><tr><td>surroundings</td><td>周围的事物，环境</td></tr><tr><td>clinical psychologist</td><td>临床心理学家</td></tr><tr><td>social studies</td><td>社会科学课程</td></tr><tr><td>technology</td><td>工业技术</td></tr><tr><td>considerate</td><td>体贴的</td></tr><tr><td>allure</td><td>诱惑力，吸引力</td></tr><tr><td>etiquette</td><td>规矩；礼节</td></tr><tr><td>to connect</td><td>（融洽地）沟通</td></tr><tr><td>memory (phone's)</td><td>（手机）内存</td></tr><tr><td>selfie</td><td>自拍照</td></tr><tr><td>to go cold turkey</td><td>快速、彻底地戒掉 (坏习惯)</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. How often do people check their phone, according to the survey?  

2.  True or false? Those who took part in the study were aware of their own phone habits.  

3.  What's the so called 'rule of three' for?  

4.  How does the author suggest you use your phone in a way that doesn't alienate people next to you?  

Which word in the text is used to indicate unpleasant be  

# 2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. My mobile phone is running out of . I've been storing too many videos on it.  

internet electronic companion memory etiquette  

2. I'm too busy to do my homework now. I have to go online and update on Weibo.  

a cold turkey the internet the rule of three my status  

3. If you want people to be nice to you, you should be when dealing with them.  

4. If you want to understand how people interact in a group you should take a course in  

social studies clinical psychology etiquette technology  

5. These new portable devices are the world we live in.  

# 答案  

1. 阅读课文并回答问题。  

1. How often do people check their phone, according to the survey? According to the study led by Nottingham Trent University in Britain, the average person checks their phone 85 times a day.  

2.  True or false? Those who took part in the study were aware of their own phone habits. False. They were surprised as they thought the number of times they checked their phones was half of what the study revealed.  

3.  What's the so called 'rule of three' for? To keep a conversation going.  

4.  How does the author suggest you use your phone in a way that doesn't alienate people next to you? The author suggests people to show others pictures stores in their phone and invite them to take a selfie.  

5.  Which word in the text is used to indicate unpleasant behaviour? Rude.  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. My mobile phone is running out of memory. I've been storing too many videos in it.  

2. I'm too busy to do my homework now. I have to go online and update my status on Weibo.  

3. If you want people to be nice to you, you should be considerate when dealing with them.  

4. If you want to understand how people interact in a group you should take a course in social studies.  

. These new portable devices are shaping the world we  