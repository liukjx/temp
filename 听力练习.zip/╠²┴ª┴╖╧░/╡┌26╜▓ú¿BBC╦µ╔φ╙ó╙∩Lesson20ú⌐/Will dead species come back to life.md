# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Will dead species come back to life?  

长毛象死而复生？  

 关于台词的备注:请注意这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: Genetics 遗传学，基因学  

A team of international scientists has published the complete genome of the woolly mammoth – a creature which became extinct thousands of years ago.  

The study, published in the Journal Current Biology, will probably cheer up a team of Harvard University researchers who've been planning to add mammoth genes to the stem cells of elephants. Their aim is to find out how the mammoth's adaptations helped them survive the ice ages.  

Will this be a future sight in North America?  

The Long Now Foundation, based in San Francisco, is financing the Harvard team and has daring plans for the future if the species is resurrected. It says on its website that its goal is "to produce new mammoths that are capable of repopulating the vast tracts of tundra and boreal forest in Eurasia and North America."  

They say: "The goal is not to make perfect copies of extinct woolly mammoths, but to focus on the mammoth adaptations needed for Asian elephants to live in the cold climate of the tundra."  

But how close are we from a Jurassic-Park-like scenario in which extinct animals are brought back to life? Very far, according to some experts. Professor Beth Shapiro, of the University of California, Santa Cruz, wrote a book called How to Clone a Mammoth. She is sceptical and believes there is an enormous difference between an embryo in a lab dish and a living animal with some of the characteristics of a mammoth. And we can't even be sure if the elephant's surrogate pregnancy would be successful.  

Woolly mammoths died out some 4,000 years ago. It might take a long time before the fantasy of the Steven Spielberg movies is turned into reality. And that's fine for those of us who can remember that the resurrected dinosaurs on the screen gave the humans a pretty hard time. If mammoths come back, maybe it would be a good idea to start running…  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. In what way do the Harvard University team plan to revive the mammoth?   
2. Which organisation wants to see mammoths back in the wild?   
3. True or false? It's easy to clone a mammoth because elephants are their 'relatives'.   
4. Which movie by US director Steven Spielberg shows resurrected dinosaurs?   
5. Which noun in the article means something which is not real?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. Twins develop from two different  

embryos genes pregnancies clones  

2. Getting men to walk on the Moon was a very feat.  

<html><body><table><tr><td>fantasy</td><td>daring</td><td>sceptical</td><td>pretty</td></tr></table></body></html>  

3. The farmers are fighting for a huge of land west of the river Nile. The case will end up in the high court!  

tundra forest tract ice age  

4. My neighbour agreed to act as a mother for her aunt and uncle.  

pregnancy relative stem cell surrogate  

5. I've missed so many classes I'm having a time preparing for tomorrow's exam.  

pretty cheer up hard daring  

# Answers and Glossary 答案与词汇  

# Quiz 小测验  

1. In what way do the Harvard University team plan to revive the mammoth? They plan to add mammoth genes to the stem cells of elephants.   
2. Which organisation wants to see mammoths back in the wild? The Long Now Foundation, which is based in San Francisco.   
3. True or false? It's easy to clone a mammoth because elephants are their 'relatives'. False. Professor Beth Shapiro says we can't be sure the elephant's pregnancy would be successful.   
4. Which movie by US director Steven Spielberg shows resurrected dinosaurs? Jurassic Park.   
5. Which noun in the article means something which is not real? Fantasy.  

# Exercise 练习  

1. Twins develop from two different embryos.   
2. Getting men to walk on the Moon was a very daring feat.   
3. The farmers are fighting for a huge tract of land west of the river Nile. The case will end up   
in the high court!   
4. My neighbour agreed to act as a surrogate mother for her aunt and uncle.   
5. I've missed so many classes so I'm having a hard time preparing for tomorrow's exam.  

# Glossary 词汇表  

<html><body><table><tr><td>genome</td><td>染色体组，基因组</td></tr><tr><td>woolly mammoth</td><td>长毛象</td></tr><tr><td>extinct</td><td>灭绝的，绝种的</td></tr><tr><td>gene</td><td>基因</td></tr><tr><td>stem cell</td><td>干细胞</td></tr><tr><td>adaptation</td><td>为适应环境而做出的改变</td></tr><tr><td>daring</td><td>大胆创新的</td></tr><tr><td>to resurrect</td><td>使复活，使重新出现</td></tr><tr><td>tract</td><td>大片土地</td></tr><tr><td>Eurasia</td><td>欧亚大陆</td></tr><tr><td>to clone</td><td>克隆</td></tr><tr><td>embryo</td><td>胎儿</td></tr><tr><td>lab dish</td><td>实验室用的细菌培养皿</td></tr><tr><td>surrogate</td><td>代孕</td></tr></table></body></html>  