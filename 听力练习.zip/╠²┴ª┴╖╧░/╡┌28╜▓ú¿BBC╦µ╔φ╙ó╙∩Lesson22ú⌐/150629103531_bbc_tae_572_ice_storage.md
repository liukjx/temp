# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Storing ice in the Antarctic  

在南极储存冰  

 关于台词的备注:请注意这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: climate change 气候变化  

Where do you keep ice? In the freezer, of course. That's what scientists might have thought when they were looking for a safe place to store ice from mountain glaciers from around the world. They've decided to store ice in Antarctica because global warming is causing some of the glaciers in places like the Alps to melt.  

Antarctica: the world’s freezer  

Centre for Scientific Research is involved in creating an ice vault there. He says: "We are probably the only scientific community whose archive is in danger of disappearing from the face of the planet. If you work on corals, on marine sediments, on tree rings, the raw material is still here and will be for many centuries".  

And why do scientists need to study ice from the Alps, for example? Ice formed on the summit of a mountain is made of layers of snow accumulated over thousands of years. Trapped air bubbles contain samples of the atmosphere that existed when that ice was formed. Ice is a record of climate, according to polar oceanographer Mark Brandon from the Open University in Britain. He says: "We know carbon dioxide in the atmosphere is higher now than in the last three million years".  

Researchers use this kind of data to build computer models and try to predict what might happen in the future.  

The ice vault will be housed in a snow cave at the Concordia Research Station, which is operated by scientists from France and Italy. The ice samples will be sealed in bags and placed $10\mathsf{m}$ below the surface, at a constant temperature of -50C. This will put the scientists' minds at rest. Commercial freezers break down, power failures happen and losing the ice samples would be a disaster. Nobody wants to see a mine of scientific knowledge lost for ever in a giant puddle.  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. What do scientists fear might not last long?   
2. Why are the scientists interested in the bubbles trapped in the ice?   
3. What might help the researchers predict the future, according to the article?   
4. True or false? The ice from the glaciers could be safely stored in commercial freezers.   
5. Which noun in the article means 'an abundant supply of something of great value'?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. Joan is very lucky. She was rescued just in time after she was in a snow cave.  

<html><body><table><tr><td>safe</td><td>trapped</td><td>contained</td><td>sealed</td></tr></table></body></html>  

2. An oceanographer studies  

<html><body><table><tr><td>glaciers</td><td>tree rings</td><td>puddles</td><td>corals</td></tr></table></body></html>  

3. The bank is keeping all its clients' gold coins in its  

<html><body><table><tr><td>cave</td><td>knowledge</td><td>vault</td><td>store</td></tr></table></body></html>  

4. Iron and coal are some of the that are needed to produce steel.  

carbon dioxide data samples raw materials  

5. The rain kept us indoors all weekend.  

trapped constant layers of global warming  

# Answers and Glossary 答案与词汇  

# Quiz 小测验  

1. What do scientist fear might not last long? Mountain glaciers.   
2. Why are the scientists interested in the bubbles trapped in the ice? Because trapped air bubbles contain samples of the atmosphere that existed when the ice was formed.   
3. What might help the researchers predict the future, according to the article? Computer models which are built using the data researchers collect from the ice.   
4. True or false? The ice from the glaciers could be safely stored in commercial freezers. False. Commercial freezers might break down or be affected by power cuts.   
5. Which noun in the article means 'an abundant supply of something of great value'? Mine.  

# Exercise 练习  

1. Joan is very lucky. She was rescued just in time after she was trapped in a snow cave.  

2. An oceanographer studies corals.  

3. The bank is keeping all its clients' gold coins in its vault.  

4. Iron and coal are some of the raw materials that are needed to produce steel.  

5. The constant rain kept us indoors all weekend.  

# Glossary 词汇表  

<html><body><table><tr><td>glaciers</td><td>（复数）冰河，冰川</td></tr><tr><td>global warming</td><td>全球变暖</td></tr><tr><td>melt</td><td>融化</td></tr><tr><td>vault</td><td>穹窿，拱顶，地下储藏室</td></tr><tr><td>coral</td><td>珊瑚</td></tr><tr><td>raw material</td><td>原材料</td></tr><tr><td>trapped</td><td>被困住的</td></tr><tr><td>sample</td><td>样品，标本</td></tr><tr><td>atmosphere</td><td>大气</td></tr><tr><td>record</td><td>记录，证明</td></tr><tr><td>polar</td><td>极地的</td></tr><tr><td>oceanographer</td><td>海洋学家</td></tr><tr><td>carbon dioxide</td><td>二氧化碳</td></tr><tr><td>data</td><td>数据</td></tr><tr><td>computer model</td><td>计算机模型</td></tr><tr><td>to seal</td><td>封住，密封</td></tr><tr><td>put (their) minds at rest</td><td>使（他们）安心、放心</td></tr><tr><td>puddle</td><td>水坑</td></tr></table></body></html>  