# Warming to hit species hard 气候变暖将导致大量物 种消失  

Vocabulary: climate change 词汇: 气候变化  

Can you imagine a world where more than half of our common plant species and a third of our known animals disappear from sight? That's the scenario suggested by new research on the impact of climate change.  

An international team of researchers looked at the impact of rising temperatures on nearly 50,000 species of plants and animals. They came to the conclusion that these are to decline due to changes in their habitat.  


They looked at temperature and rainfall records for the habitats in which these species now live and mapped the areas that would remain suitable for them under different weather conditions.  

The scientists projected that if no significant efforts were made to limit greenhouse gas emissions, by the year 2100 global temperatures would be 4C above pre-industrial levels. In this scenario, some $34\%$ of animal species and $57\%$ of plants would lose more than half of their current habitat ranges.  

The impact on species will be felt more heavily in some parts of the world such as subSaharan Africa, Central America, the Amazon region and Australia.  

Our society would be affected too, according to Dr Rachel Warren, from the University of East Anglia in Britain. She says: "There'll be a knock-on effect for humans because these species are important for things like water and air purification, flood control and nutrient cycling, and eco-tourism."  

In spite of the conclusions to this paper, published in the journal Nature Climate Change, it is not all doom and gloom. Dr Warren says: "Swift action to reduce CO2 and other greenhouse gases can prevent the biodiversity loss by reducing the amount of global warming to 2C rather than 4 degrees."  

The researcher believes that this would buy time for plants and animals to adapt to the change.  

If nothing is changed and the predictions of this study are confirmed, the world might look very different in a few generations.  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. Why are animals and plant species under threat?   
2. According to this new research, how much warmer might it get by the end of the   
century?   
3. What difference would a lower rise in temperature make to animal and plant species?   
4. Which word means 'appropriate'?   
5. Which expression means 'a situation that is bad and won't get better'?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. The decline in the world's is causing great concern among animal lovers.  

greenhouse gases global warming biodiversity scenarios  

2. If you are moving from the countryside to the big city, you've got to to a busier lifestyle.  

map adapt predict prevent  

3. John was keen to buy a sports car but he to the conclusion that it would be too expensive to maintain.  

thought went believed came  

4. It's been raining heavily for the past few days. The emergency services had to rescue a group of children caught in a in the school by the river.  

decline knock-on effect flood water purification  

5. Temperatures across much of the country last week - and ice cream sales went through the roof!  

raised risen rose raising  

# Quiz 小测验  

1. Why are animals and plant species under threat? Because of the changes global warming might cause to their habitats.   
2. According to this new research, how much warmer might it get by the end of the century? In 2100 temperatures could be 4C above pre-industrial levels.   
3. What difference would a lower rise in temperature make to animal and plant species? It would give them more time to adapt.   
4. Which word means 'appropriate'? Suitable.   
5. Which expression means 'a situation that is bad and won't get better'? Doom and gloom.  

# Exercise 练习  

1. The decline in the world's biodiversity is causing great concern among animal lovers.   
2. If you are moving from the countryside to the big city, you've got to adapt to a busier lifestyle.   
3. John was keen to buy a sports car but he came to the conclusion that it would be too expensive to maintain.   
4. It's been raining heavily for the past few days. The emergency services had to rescue a group of children caught in a flood in the school by the river.   
5. Temperatures rose across much of the country last week - and ice cream sales went through the roof!  

# Glossary 词汇表  

<html><body><table><tr><td>scenario</td><td>设想，可能发生的局面</td></tr><tr><td>to come to a conclusion</td><td>得出一个结论</td></tr><tr><td>rainfall records</td><td>降雨量纪录</td></tr><tr><td>to map</td><td>标划出</td></tr><tr><td>suitable</td><td>适宜的</td></tr><tr><td>weather conditions</td><td>天气状况</td></tr><tr><td>greenhouse gas emissions</td><td>温室气体排放</td></tr><tr><td>pre-industrial</td><td>工业化前的</td></tr><tr><td>knock-on effect</td><td>连锁反应</td></tr><tr><td>air purification</td><td>空气净化</td></tr><tr><td>nutrient cycling</td><td>营养物循环</td></tr><tr><td>eco-tourism</td><td>生态旅游</td></tr><tr><td>paper (scientific study)</td><td>科研文献</td></tr><tr><td>doom and gloom</td><td>悲观沮丧的</td></tr><tr><td>greenhouse gas</td><td>温室气体</td></tr><tr><td>biodiversity</td><td>生物多样性</td></tr><tr><td>global warming</td><td>全球变暖</td></tr><tr><td>to buy time</td><td>赢得时间</td></tr><tr><td>to adapt</td><td>去适应</td></tr></table></body></html>  