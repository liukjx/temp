# BBC LEARNING ENGLISH  

# Take Away English 随身英语 The good of gardening  

园艺疗法益心养神  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
請注意：中文文字内容只提供簡體版  

# Vocabulary: therapy 疗法  

Do you have a hobby that helps you relax and unwind? For some people, there is no better way to switch off than spending time in the garden. This small private area of green space can be their oasis of calm.  


It's no wonder some of us turn to gardening as a form Soil has some surprising benefits for us of therapy. A survey conducted by the Royal   
Horticultural Society, found that $82\%$ of people in the UK said that gardening makes them happier. It also found that $70\%$ of them, given the choice, would prefer to spend their working day in the garden with just $9\%$ opting for an office.  

For those with green fingers, the pleasure of gardening comes from getting out in the fresh air, in all weathers and communing with nature – even if there are a few too many creepycrawlies! It can also be seen as a sort of digital-detox – time away from technology. Some experts actually believe that getting outside to dig and plant things acts as a 'natural high'.  

Dr Christopher Lowry, a neuroscientist at the University of Colorado, injected a bacterium commonly found in soil into mice to see what affect this would have on them. He found the bacterium had a similar effect on the mice as an antidepressant drug might.  When we dig in soil we ingest this bacterium through our lungs or cuts in our skin so Dr Lowry concluded that since the mice seemed happier when treated with soil bacteria, it's likely we would be too.  

Gardening can also be used as a way of treating addiction. There's evidence that recovering alcoholics who have been given the opportunity to plant, grow, and even sell their produce, have managed to stop their addictive habits. Scot Stephenson, for example, got expelled from school and started a vocational qualification in gardening. He says "I got my NVQ level 2 which is my first qualification and enjoyed it ever since."  

Whatever the reason, there are many therapeutic benefits to getting your hands dirty, doing some physical hard work and then watching your garden grow. Does this sound like your idea of fun?  

词汇表  


<html><body><table><tr><td>unwind</td><td>放松，减压</td></tr><tr><td>switch off</td><td>不在关注 (工作或另人精神紧张的事情)</td></tr><tr><td>oasis of calm</td><td>宁静的一刻</td></tr><tr><td>therapy</td><td>（非药物）疗法</td></tr><tr><td>green fingers</td><td>园艺能手</td></tr><tr><td>communing</td><td>与（大自然）交流、融为一体</td></tr><tr><td>creepy-crawlies</td><td>爬虫，蠕虫</td></tr><tr><td>digital-detox</td><td>数码排毒</td></tr><tr><td>natural high</td><td>（不靠药物）自然的兴奋、高兴</td></tr><tr><td>bacterium</td><td>细菌（复数为bacteria)</td></tr><tr><td>antidepressant drug</td><td>抗抑郁药物</td></tr><tr><td>addiction</td><td>嗜好，瘾</td></tr><tr><td>recovering alcoholics</td><td>目前滴酒不沾的酗酒者</td></tr><tr><td>expelled</td><td>被开除</td></tr><tr><td>vocational</td><td>职业技术的</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. What phrase used in the article, describes someone who likes gardening?  

2. True or false? In a survey, a majority of people found gardening made them less happy.  

3. What word used in the article means 'absorb' or 'take into the body'?  

4. How have some recovering alcoholics been able to control or stop their addiction?  

5. What is the adjective form of therapy?  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. The garden in the middle of the city provided an for those who wanted somewhere quiet to eat their lunch.  

oasis of noise oasis of calm osias of calm clammy oasis  

2.  Extra oxygen was pumped into the shop to give customers a when they were shopping.  

nature high green fingers natural high digital-detox  

3. I've had to cut up my credit cards to help me quit my to buying shoes!  

therapy communing addiction natural high  

4. To help me , I usually have a bath and listen to some relaxing music.  

5. David was after starting a fight in the school dining room.  

expelled banned executed expelling  

# 答案  

1. 阅读课文并回答问题。   
1. What phrase used in the article, describes someone who likes gardening? (having) green fingers   
2.  True or false? In a survey, a majority of people found gardening made them less happy. False. The survey  found $\pmb{82\%}$ of people (a majority) in the UK said that gardening makes them happier.   
3.  What word used in the article means 'absorb' or 'take into the body'? ingest   
4.  How have some recovering alcoholics been able to control or stop their addiction? Having the opportunity to plant, grow, and even sell their produce,   
5. What is the adjective form of 'therapy'? therapeutic   
2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格   
处。   
1. The garden in the middle of the city provided an oasis of calm for those who wanted somewhere quiet to eat their lunch.   
2. Extra oxygen was pumped into the shop to give customers a natural high when they were shopping.   
3. I've had to cut up my credit cards to help me quit my addiction to buying shoes!   
4. To help me unwind, I usually have a bath and listen to some relaxing music.   
5. David was expelled after starting a fight in the school dining room.  