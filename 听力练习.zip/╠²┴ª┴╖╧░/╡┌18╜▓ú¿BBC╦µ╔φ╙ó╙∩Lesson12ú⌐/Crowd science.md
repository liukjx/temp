# BBC LEARNING ENGLISH  

# Take Away English 随身英语'Crowd science' 大众科学  

 关于台词的备注:请注意这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: science 词汇: 科学  

Are you patient? Do you have attention to detail, free time and access to a computer? Well, then a scientist might welcome your help. Researchers in the UK say it's becoming crucial to count on Joe Public to help them with their projects. They need people to examine data and submit their observations online.  

British teenagers Sasha and Matthew are taking part in a study of penguins from the comfort of their homes. The pair look at pictures and tag photos identifying adults, chicks and eggs. Every click of their mouse is helping to build up a detailed picture of penguin colonies. They, and thousands of others, are helping scientists to understand why some colonies are growing and others are decreasing. Within the first four hours of Penguin Watch going live, 'citizen scientists' labelled more images than the research team had in five years.  

Penguins are being observed by people keen to help the scientists  

Dr Tom Hart, Penguin Watch Coordinator at Oxford University, says: "When you go beyond what a scientist can analyse to what a mass audience can do, then you scale it up beyond what any other project could do."  

The British Science Association says families are helping out with rigorous research. It made a difference to the Planet Hunters Project, which ran for five years. Volunteers looked at dots which showed how the brightness of a star changed at different points in its solar system.  

According to Dr Robert Simpson from Oxford University, who took part in the project, the volunteers discovered planets and these are now in published papers. He says with pride: "We can go and look at these planets with other telescopes and we know they exist because of those helpers."  

But how do scientists guard their research against accidental or deliberate mistakes in observation? Dr Simpson isn't worried. "We get lots of people looking at the same things," he says. The researcher warns that people who are maliciously clicking on the site are very obvious and can be identified very quickly. So, there's no fooling the scientists.  

And to make sure things go well, the Penguin Watch paper will go through a peer review before being published. After that, every 'citizen scientist' will be credited.  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. What do the scientists need the public for?   
2. What does Matthew do?   
3. Who found planets in Dr Simpson's project?   
4. How will scientists make sure the observations carried out by volunteers in the Penguin   
Watch project are accurate?   
5. Which word means 'deceiving'?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. The researcher already had all the data he needed. It was time now to it.  

observe identify build up analyse  

2. The teacher gave Jerry another chance to do the test. He knew the student's absence on the day it was done was not . Jerry was ill.  

accidental deliberate obvious rigorous  

3. The university lacked funds, so the researchers had to do their study on a scale than they had initially planned.  

larger smaller quicker mass  

4. Mary is well known in academic circles. There are several with her name on them.  

data observations published papers peer review  

5. Of course I came here on Sunday to help set up the school's art exhibition in the hall. I'm always a very willing  

Joe Public citizen scientist researcher volunteer  

# Answers and Glossary 答案与词汇  

# Quiz 小测验  

1. What do the scientists need the public for? To examine data and submit their observations online.   
2. What does Matthew do? He tags photos of penguins identifying adults, chicks and eggs.   
3. Who found planets in Dr Simpson's project? Volunteers working online.   
4. How will scientists make sure the observations carried out by volunteers in the Penguin Watch project are accurate? The research will go through a peer review before being published.   
5.  Which word means 'deceiving'? Fooling.  

# Exercise 练习  

1. The researcher already had all the data he needed. Now was time to analyse it.  

2. The teacher gave Jerry another chance to do the test. He knew the student's absence on the day it was done was not deliberate. Jerry was ill.   
3. The university lacked funds, so the researchers had to do their study on a smaller scale than they had initially planned.   
4. Mary is well known in academic circles. There are several published papers with her name on them.   
5. Of course I came here on Sunday to help set up the school's art exhibition in the hall. I'm always a very willing volunteer.  

# Glossary 词汇表  

<html><body><table><tr><td>attention to detail</td><td>注意细节</td></tr><tr><td>Joe Public</td><td>公众</td></tr><tr><td>erep</td><td>数据</td></tr><tr><td>observations</td><td>观察结果</td></tr><tr><td>to tag</td><td>加上标签，标注</td></tr><tr><td>to identify</td><td>识别</td></tr><tr><td>dn pinq o2</td><td>建立，积累</td></tr><tr><td>citizen scientist</td><td>公众科学家 (非职业科学家)</td></tr><tr><td>to label</td><td>标注</td></tr><tr><td>rigorous</td><td>非常全面的</td></tr><tr><td>volunteer</td><td>志愿者</td></tr><tr><td>published papers</td><td>发表的论文、文章</td></tr><tr><td>deliberate</td><td>故意的</td></tr><tr><td>maliciously</td><td>心怀恶意的</td></tr><tr><td>peer review</td><td>同行评审</td></tr><tr><td>to credit</td><td>归功于</td></tr></table></body></html>  