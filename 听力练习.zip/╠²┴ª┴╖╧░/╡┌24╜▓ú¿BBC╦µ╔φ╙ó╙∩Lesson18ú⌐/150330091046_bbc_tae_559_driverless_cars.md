# BBC LEARNING ENGLISH  

# Take Away English 随身英语Driverless cars 无人驾驶汽车  

 关于台词的备注:请注意这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: technology 词汇: 科技  

I passed my driving test at the fourth attempt. You might think that means I'm not as safe as someone who passed first time. But would you feel safer with no driver at all? Maybe not, and it's for this reason that automotive firms have included driverassist functions in their prototype driverless cars. This allows the human driver to take over if there is a problem.  

Google is one manufacturer that has prototype driverless cars. These have been  

Where's the driver?!  

retrofitted with steering wheels and conventional controls to allow normal driving. But this is just a stage – the vision is to have fully automated cars very soon. The director of Google's self-drive project, Chris Urmson, hopes his 11-year-old son will never have to take a driving test. To achieve that, the cars need to be on the roads in five years. He says driverless cars will drastically reduce accidents and traffic jams.  

According to Chris "Some 1.2 million people are killed on the roads around the world each year. That number is equivalent to a jet falling out of the sky every day."  

He thinks gradual changes to existing car designs are not enough to deal with the problem. "If we are really going to make changes to our cities, get rid of parking lots, we need self-drive cars," he says.  

Google's prototypes have racked up over a million kilometres on the road. They have also had to deal with unexpected situations, such as a child driving a toy car in the road, and a woman in an electric wheelchair chasing a duck. In each case, the car reacted safely.  

Some are not convinced. Sven Beiker of Stanford University thinks driverless cars will still need human input in extreme circumstances. He also worries that people may forget how to operate their vehicles if they do not do it regularly. I guess I shouldn't throw away my driver's licence just yet.  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. How many times did the writer take a driving test?   
2. What allows a human driver to take over in a driverless car?   
3. What does Chris Urmson hope his son will never have to do?   
4. How many people die in road accidents every year?   
5. Who thinks people may forget how to drive if they don't do it regularly?  

# Exercise 练习  

请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. Ten miles is roughly to 16 kilometres.  

equivalent driver-assist automotive conventional  

2. I will only lend people money in  

prototype extreme circumstances equivalent vision  

3. We £200,000 in sales last year.  

operated racked up retrofitted assisted  

4. We are building a for a new type of bicycle.  

prototype equivalent vision automobile  

5. The new cars will really boost the American industry.  

automotive driver-assist manufacturer conventional  

# Answers and Glossary 答案与词汇  

# Quiz 小测验  

1. How many times did the writer take a driving test? Four.   
2. What allows a human driver to take over in a driverless car? Driver-assist functions.   
3. What does Chris Urmson hope his son will never have to do? Take a driving test.   
4. How many people die in road accidents every year? 1.2 million.   
5. Who thinks people may forget how to drive if they don't do it regularly? Sven Beiker.  

# Exercise 练习  

1. Ten miles is roughly equivalent to 16 kilometres.   
2. I will only lend people money in extreme circumstances.   
3. We racked up £200,000 in sales last year.   
4. We are building a prototype for a new type of bicycle.   
5. The new cars will really boost the American automotive industry.  

# Glossary 词汇表  

<html><body><table><tr><td>automotive 汽车</td><td></td></tr><tr><td>driver-assist</td><td>司机助手</td></tr><tr><td>prototype</td><td>全真模型</td></tr><tr><td>manufacturer</td><td>生厂商</td></tr><tr><td>retrofitted</td><td>重装</td></tr><tr><td>conventional</td><td>传统的</td></tr><tr><td>vision</td><td>愿景，目标</td></tr><tr><td>drastically</td><td>彻底地，大大地</td></tr><tr><td>equivalent</td><td>相当，等同</td></tr><tr><td>racked up</td><td>积累起来</td></tr><tr><td>extreme circumstances</td><td>极端条件 (环境)</td></tr><tr><td>operate</td><td>运作，操作</td></tr></table></body></html>  