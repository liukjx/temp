# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Social media sadness  

社交媒体引发的悲哀  

• 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
• 請注意：中文文字内容只提供簡體版  

# Vocabulary: depression 忧郁，抑郁  

Are you a social media addict? Are you always checking your smartphone to see how many 'likes you've received for your latest post? Maybe you feel comforted by the notification sound that someone has sent you a message?  

Don't worry, you're not alone. We check our phones an average of 150 times a day, and around $30\%$ of the total time spent online is dedicated to social media. Some experts now fear this habit could be damaging our mental health.  


This is something particularly afflicting young adults, according to a study from the University of Pittsburgh. It found the more they used social media, the more likely they are to be depressed. In tests, those people who checked social media frequently were 2.7 times more likely to be depressed compared to those who spent most of their time generally surfing the internet, who had just 1.7 times the risk. The study found that exposure to “highly idealised representations of peers on social media elicits feelings of envy and the distorted belief that others lead happier, more successful lives.”  

Some of us certainly feel sad when we're ignored on social media sites, or when we see someone else having a better time than us. But depression is a more serious condition and clinical psychologist, Abigael San, recently told the BBC that, "It’s a real issue, and it’s been getting significantly worse over the last 5-6 years. You can get so hooked that it takes you away from your real relationships." However, Abigael does admit that social media is more likely to exacerbate pre-existing issues than directly cause them.  

Other research by Glasgow University found that teenagers are affected by the 24-hour demands of their social media accounts. It found that those with higher levels of emotional investment in social media, and who use it at night, were more likely to feel depressed and anxious.  

Despite these warning signs, why do some of us continue to keep clicking? Well, I suppose we all want to be liked and we don't want to miss out on a conversation that's taking place online. But we need to know when to switch off our virtual online world and connect with the real world instead.  

词汇表  


<html><body><table><tr><td>addict</td><td>有瘾的人</td></tr><tr><td>comforted</td><td>得到安慰的</td></tr><tr><td>dedicated</td><td>专用 (于)</td></tr><tr><td>mental health</td><td>心理健康</td></tr><tr><td>afflicting</td><td>使...受苦的、苦恼的</td></tr><tr><td>exposure</td><td>接触</td></tr><tr><td>idealised</td><td>理想化的</td></tr><tr><td>elicit</td><td>诱出，引出</td></tr><tr><td>envy</td><td>羡慕，嫉妒</td></tr><tr><td>condition</td><td>疾病</td></tr><tr><td>hooked</td><td>上的，入迷的</td></tr><tr><td>exacerbate</td><td>使恶化</td></tr><tr><td>pre-existing</td><td>先已存在的，既往 (病史)</td></tr><tr><td>emotional investment</td><td>情感投入</td></tr><tr><td>snoixue</td><td>焦虑的</td></tr><tr><td>virtual online world</td><td>虚拟的网络世界</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. Is this true or false? Young people spend on average 150 days a year looking at social media. 2. What phrase did the study use to mean that we think other people are leading happier lives when in reality, they are not?   
3. According to research by Glasgow University, using social media at what time of day makes teenagers even more depressed?   
4. How often do teenagers feel the need to be look at social media?   
5. What word used in the article means 'people of the same age as you or same social position'?  

2. 请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. I'm a bit of a coffee ; I have to have three cups every morning!  

adder addicted addict addiction  

2. I her piano playing skills. I have had three years of lessons and still can't play a tune.  

afflict envy idealise elicit  

3. The closure of the factory just the problem of youth unemployment in the area.  

exposed comforted elicited exacerbated  

4. She looked a bit as she entered the room to take her English exam.  

anxious anxiously anxioused anxiosh  

5. He has an view of the perfect woman, but to be honest, he's not going to ever meet her!  

<html><body><table><tr><td>afflicted</td><td>idealised</td><td>anxious</td><td>virtual</td></tr></table></body></html>  

# 答案  

1. 阅读课文并回答问题。  

1. Is this true or false? Young people spend on average 150 days a year looking at social media. False. The report said "we check our phones an average of 150 times a day."  

2. What phrase did the study use to mean that we think other people are leading happier lives when in reality, they are not?   
The distorted belief. 3. According to research by Glasgow University, using social media at what time of day makes teenagers even more depressed?   
Using it at night.  

4. How often do teenagers feel the need to look at social media?   
24 hours a day.  

5. What word used in the article means 'people of the same age as you or same social position'? Peers.  

2. 请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. I'm a bit of a coffee addict, I have to have three cups every morning!  

2. I envy her piano playing skills. I have had three years of lessons and still can't play a tune.  

3. The closure of the factory just exacerbated the problem of youth unemployment in the area.  

4. She looked a bit anxious as she entered the room to take her English exam.  

5. He has an idealised view of the perfect woman, but to be honest, he's not going to ever meet her!  