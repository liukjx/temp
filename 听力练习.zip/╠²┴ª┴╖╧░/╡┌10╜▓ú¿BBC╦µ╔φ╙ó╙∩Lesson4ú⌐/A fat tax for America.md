# Take Away English随身英语  

# A Fat Tax for America?  

英语学习点: Fines Vocabulary and Conditionals 有关罚款的词汇和条件句  

If a new idea in America becomes a law, people who suffer from obesity could suffer financially too.  

The US state of Arizona wants to charge overweight citizens $\Phi50$ (325 Yuan) annually if they fail to follow their doctors' advice. People with children or who are overweight because they suffer from a medical condition would be exempt.  


If the idea is approved by Congress, smokers and diabetics who fail to stick to a healthy lifestyle will also have to pay.  

Medicaid, the organisation which provides healthcare to the poor in the USA, costs the government $\Phi3396\boldsymbol{\mathrm{n}}$ (2.2 trillion Yuan) a year. Monica Coury, assistant director at Arizona's Medicaid programme, said that this proposal would ask people to give something back.  

She said that Arizona would take a carrot and stick approach to the problem. As well as penalising people who go against their doctor's wishes, incentives would be offered for following advice, possibly a keep-fit video.  

Arizona's senator Kyrsten Sinema has not backed the plans, saying that there isn't a system to decide whether someone is or isn't following medical advice. Other critics claim that people don't need the government to look after them; if they want to be fat and smoke, the 'nanny state' shouldn't try to stop them. Wes Benedict of the Libertarian Party said:  

"If you want to save the state money... cut Medicaid across the board, but don't single out overweight people and smokers."  

词汇表请参看答案与词汇部分  

# Quiz 测验  

阅读短文并回答问题。  

1. If the proposal gets approved, will all obese people have to pay the fine?   
2. Who receives money from Medicaid?   
3. Is this statement true, false or not given? Medicaid costs a lot, so the proposal is likely to be approved.   
4. Is this statement true, false or not given? The proposed scheme is a mixture of rewards and punishments.   
5. Look at the article. Can you find a noun which means 'a reason for doing something'?  

# Exercise 练习  

测试一下你对条件句的掌握。选择方框内正确的表达完成句子。  

1. If the proposal some obese people will have to pay a fifty dollar fine. was approved is approved approved will be approved  

2. If the new law were passed, smokers who ignore their doctors pay a fine too.  

should will have to would have to wouldn't  

3. If obesity wasn't so costly, this scheme proposed. might have been might never have been might be might not be  

4. Some people think: "If I want to smoke, the government me." should let should have let will let shall let  

5. Some say that if the government to cut Medicaid it should do so differently.  

has wanted will want wanted wants  

# Answers and Glossary 答案与词汇  

# Quiz 小测验  

1. If the proposal gets approved, will all obese people have to pay the fine? No, some people will be exempt, so they won't have to pay.   
2. Who receives money from Medicaid? Poor people.   
3. Is this statement true, false or not given? Medicaid costs a lot, so the proposal is likely to be approved. Not given. There is no indication in the text of whether the proposal is likely to be approved.   
4. Is this statement true, false or not given? The proposed scheme is a mixture of rewards and punishments. True. This is the meaning of the phrase 'carrot and stick'.   
5. Look at the article. Can you find a noun which means 'a reason for doing something'? Incentive.  

# Exercise 练习  

1. If the proposal is approved some obese people will have to pay a fifty dollar fine.  

2. If the new law were passed, smokers who ignore their doctors would have to pay a fine too.  

3. If obesity wasn't so costly, this scheme might never have been proposed.  

4. Some people think: "If I want to smoke, the government should let me."  

5. Some say that if the government wants to cut Medicaid it should do so differently.  

# Glossary 词汇表  

<html><body><table><tr><td>obesity肥胖、肥胖症</td><td>to charge someone 向某人收费</td></tr><tr><td>exempt被豁免的</td><td>to stick to something坚持、遵守做某事</td></tr><tr><td>proposal提议</td><td>to give something back偿还某物</td></tr><tr><td>a carrot and stick approach “胡萝卜加大棒”
政策（奖赏与惩罚的政策）</td><td>to penalise someone对某人予以惩罚</td></tr><tr><td>incentive奖励</td><td>the 'nanny state''“"保姆国家""</td></tr><tr><td>across the board全盘地、所有人员都包括在内 地</td><td>to single out挑选、单独选出</td></tr></table></body></html>  