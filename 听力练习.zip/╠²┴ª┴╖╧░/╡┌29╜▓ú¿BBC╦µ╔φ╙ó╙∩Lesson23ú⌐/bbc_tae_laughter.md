# BBC LEARNING ENGLISH  

# Take Away English 随身英语Why do we laugh?为什么我们会笑？  

• 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
• 請注意：中文文字内容只提供簡體版  

Vocabulary: laughter 词汇: 笑声  

What makes you laugh the most?  

While rib-tickling jokes and hilarious videos certainly do make us giggle, most of the time we laugh because of something much simpler: being with other people.  

So much so that we are 30 times more likely to laugh when we're with others, according to a study by neuroscientist Robert Provine from the University of Maryland. "When you're alone, laughter basically disappears," he told Smithsonian Magazine.  

So, what is it about other people that makes us split our sides? The answer lies deep within our brains, and in how we form communities.  

Laughter is a social emotion that we use to "make and maintain social bonds," says Professor Sophie Smith from University College London in an article for the BBC. It reassures people that situations are non-threatening. Those who laugh frequently are also often more popular. Even in a normal conversation we laugh seven times every 10 minutes, she says.  

Professor Smith also explains that laughter is very different to speech. It is non-verbal: the wheezing and snorting sounds are produced by air being pushed out quickly at high pressure, without involving the teeth or lips. These sounds are the kind we make when in a state of heightened emotion.  

In this respect, laughter sounds more like an animal call than human language. This theory is backed up by tests which show the part of the brain responsible for laughter is not the neocortex used in language, but an 'older' area we share with mammals.  

Indeed, chimpanzees, gorillas and even rats all enjoy a good chortle, especially when being tickled. Just be careful when you tickle a gorilla, or you might end up laughing on the other side of your face… (Did you laugh at that gag? Or did it just make you groan?)  

词汇表  


<html><body><table><tr><td>rib-tickling</td><td>令人捧腹大笑的</td></tr><tr><td>hilarious</td><td>滑稽的</td></tr><tr><td>giggle</td><td>咯咯地笑</td></tr><tr><td>neuroscientist</td><td>神经科学家</td></tr><tr><td>split your sides</td><td>笑裂腰身，笑破肚皮</td></tr><tr><td>social bond</td><td>社会关系</td></tr><tr><td>non-threatening</td><td>不具威胁性的</td></tr><tr><td>non-verbal</td><td>非语言的</td></tr><tr><td>wheeze</td><td>发出喘息声</td></tr><tr><td>snort</td><td>用鼻子哼</td></tr><tr><td>heightened emotion</td><td>高度激动的情绪</td></tr><tr><td>back up</td><td>证实，有证据支持</td></tr><tr><td>neocortex</td><td>大脑新皮层</td></tr><tr><td>chortle</td><td>哈哈大笑</td></tr><tr><td>laugh on the other side of your face</td><td>（口语比喻）转喜为忧、乐极生悲</td></tr><tr><td>gag</td><td>玩笑、俏皮话</td></tr><tr><td>groan</td><td>哼了一声</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. Why do we laugh so much when we're with others?  

2. How is laughing unlike speaking?  

3. If I tell a bad joke does it make you split your sides or groan?  

4. How do you make a rat laugh?  

5. True or false? The part of the brain responsible for speaking is newer than the part used for laughing.  

# 2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. I can't stop whenever Tim talks. He's just so funny.  

rib-tickling splitting giggling groaning  

2. He his claim with photographic evidence.  

back upped back up heightened backed up  

3. After running for 10 miles I was heavily.  

wheezing snorting chortling tickling  

4. Don't you dare say that again or you'll be laughing on the other side  

of my face of your face of our face of the face  

5. Police were sent in to deal with a situation.  

threatened non-verbal non-threatening threatening  

# 答案  

1. 阅读课文并回答问题。  

1. Why do we laugh so much when we're with others? We laugh because it helps us make and maintain social connections, it helps us understand situations are non-threatening, and because it can make us more popular.  

3. If I tell a bad joke does it make you split your sides or groan? If you hear a bad joke you groan, which means to laugh awkwardly or in a forced way.  

4. How do you make a rat laugh? You tickle a rat to make it laugh.  

5. True or false? The part of the brain responsible for speaking is newer than the part used for laughing. True. The part of the brain used for laughing is an older part we share with other mammals.  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. I can't stop giggling whenever Tim talks. He's just so funny.  

2. He backed up his claim with photographic evidence.  

3. After running for 10 miles I was wheezing heavily.  

4. Don't you dare say that again or you'll be laughing on the other side of your face.  

5. Police were sent in to deal with a threatening situation.  