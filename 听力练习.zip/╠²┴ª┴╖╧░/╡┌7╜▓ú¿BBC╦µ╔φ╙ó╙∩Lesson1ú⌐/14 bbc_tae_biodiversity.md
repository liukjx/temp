# BBC LEARNING ENGLISH  

# Take Away English 随身英语 Loss of biodiversity affects human society  

生物多样性减少给人类社会带来影响  

• 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
• 請注意：中文文字内容只提供簡體版  

Vocabulary: environment 词汇：环境  

If a species of bee disappears forever or a particular plant is extinct, what does it have to do with us humans? Well, according to a team of international scientists, biodiversity is dropping below levels considered safe for the wellbeing of human societies.  

The issue is that everything is interconnected and ecosystems support our societies because they provide us with, for example,  food, fibres and fuels.  

If species go on disappearing, this can interfere with vital processes such as crop pollination and the decomposition of waste.  

![](images/6169bd5a7103bdddf9fd961d9a7f60cb736ba40c897fcbd8a45deb8cd85c03ca.jpg)  

If left unchecked, loss of biodiversity could have serious consequences, say scientists  

A framework which defines the environmental limits within which humans can operate – called planetary boundaries - says that losing more than $10\%$ of the biodiversity in an area places the local ecosystem at risk. Ecosystems are all different but this percentage is considered a good measure of safety.  

A study published in the magazine Science suggests that $58\%$ of the world's land surface already falls below this level. These areas house $71\%$ of the global population.  

Professor Andy Purvis, from Imperial College London and the Natural History Museum, is one of the authors of the study. He says: "Once we're the wrong side of the boundary it doesn't mean everything goes wrong immediately, but there is a markedly higher risk that things will go badly wrong."  

The researchers found that grasslands, savannas and shrub lands were most affected by biodiversity loss on average.  

Purvis hopes this report can be a wake-up call to those who design policies. Here's his warning: "Decision-makers worry a lot about economic recessions, but an ecological recession could have even worse consequences – and the biodiversity damage we've had means we're at risk of that happening. Until and unless we can bring biodiversity back up, we're playing ecological roulette."  

词汇表  


<html><body><table><tr><td>species</td><td>（动植物的）种，物种</td></tr><tr><td>extinct</td><td>消失的，灭绝的</td></tr><tr><td>biodiversity</td><td>生物多样性</td></tr><tr><td>interconnected</td><td>（两个或多个事物）互相联系的</td></tr><tr><td>ecosystem</td><td>生态系统</td></tr><tr><td>interfere 影响</td><td></td></tr><tr><td>pollination</td><td>植物授粉</td></tr><tr><td>decomposition</td><td>分解</td></tr><tr><td>framework</td><td>框架，体系</td></tr><tr><td>planetary boundaries</td><td>地球界限 (概念)</td></tr><tr><td>land surface</td><td>大地表面</td></tr><tr><td>Natural History Museum</td><td>自然历史博物馆</td></tr><tr><td>grassland</td><td>草原，草场</td></tr><tr><td>savanna</td><td>稀树草原</td></tr><tr><td>shrub land</td><td>灌木丛林</td></tr><tr><td>decision-maker</td><td>决策者</td></tr><tr><td>ecological recession</td><td>生物衰退</td></tr><tr><td>ecological roulette</td><td>生态轮盘赌</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. Why is the existence of many species of animals and plants important for humans?  

2.  True or false? If $I O\%$ of the species in any ecosystem disappear, everything will go badly wrong there.  

3.  How much of the Earth's land cover houses almost three-quarters of the world's population?  

4.  What idea does Professor Purvis want to convey when using the expression 'ecological roulette'?  

5.  Which noun is often used to refer to a period in which trade and industrial activity are reduced?  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. The more species you have in a particular area, the greater is its  

pollination biodiversity framework savannas  

2. Birds and starfish live in different  

biodiversity boundaries ecosystems societies  

3. If tropical forests are not preserved, many species of animals might end up  

interconnected safe playing ecological roulette extinct  

4. An ecosystem is everything that exists in a particular  

society environment biodiversity ecology  

5. It's necessary to avoid further loss of biodiversity or the will be devastating.  

# 答案  

1. 阅读课文并回答问题。  

1. Why is the existence of many species of animals and plants important for humans? Because many species take part in natural processes which guarantee that ecosystems work well and keep giving us food, fibres and fuel.  

2.  True or false? If $I O\%$ of the species in any ecosystem disappear, everything will go badly wrong there. False. Ecosystems are different and this percentage is just a reference set up by scientists. And things don't go wrong immediately, according to Professor Andy Purvis.  

3.  How much of the Earth's land cover houses almost three-quarters of the world's population? About $\mathbf{71\%}$ of the global population live in $\mathbf{58\%}$ of the world's land cover.  

4.  What idea does Professor Purvis want to convey when using the expression 'ecological roulette'? Professor Purvis wants to convey the idea that human societies take a great risk in a deadly game.  

5.  Which noun is often used to refer to a period in which trade and industrial activity are reduced? Recession.  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. The more species you have in a particular area, the greater is its biodiversity.  

2. Birds and starfish live in different ecosystems.  

4. An ecosystem is everything that exists in a particular environment.  

5. It's necessary to avoid further loss of biodiversity or the consequences will be devastating.  