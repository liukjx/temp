# BBC LEARNING ENGLISH  

# Take Away English 随身英语  

Having the time of your life at uni?大学是人生中最美好的时光吗？  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
請注意：中文文字内容只提供簡體版  

# Vocabulary: University 词汇: 大学  

University - the best days of my life! I made lots of friends in my student dorm, went to great parties, joined the debating society… and, well, I did some work too - but I must confess my lecturers were very patient with my tardiness.  

It's easy to look back at our university days through rose-tinted spectacles but the truth is that when we first arrived on campus, most of us were out of our comfort zone.  


Studying and partying might be too much…  

In fact, a survey of students at Imperial College London has revealed that 3 out of 4 students experience high levels of stress, or a mental health condition, during their time at college. The survey, completed by over a thousand students, also found that $70\%$ of those that experience stress do so at least once a week, and $9\%$ of students feel stressed constantly.  

Kirsty, a student at Exeter University, didn't enjoy her first days in college. She says: "When I first got to university I don't think I'd realized that I'd forgotten how to make friends. I'd been with the same school friends for seven years, and so I was trying to balance social success with academic success whilst learning how to look after myself at quite a young age."  

Dr Ruth Caleb of the counselling service at Brunel University in London has some tips that should make life easier for students before they set off for university. She says: "Certain things that I think it would be very helpful for students to have put in place are an ability to do the practical things of life – to do the washing, to do the cleaning and so on – being able to cook. Budgeting is extremely important in university life." And Caleb adds: "You should learn how to spend time on your own comfortably."  

I graduated and learnt how to take care of myself the hard way. I hope that new students these days remember to acquire some life skills before they make the big jump.  

词汇表  


<html><body><table><tr><td>student dorm</td><td>学生宿舍</td></tr><tr><td>debating society</td><td>辩论社团</td></tr><tr><td>lecturer</td><td>讲师</td></tr><tr><td>tardiness</td><td>拖拉，延迟</td></tr><tr><td>through rose-tinted spectacles</td><td>透过玫瑰色的眼镜看某物（只看到事物美好的一 面)</td></tr><tr><td>campus</td><td>（大专院校的）校园</td></tr><tr><td>out of one's comfort zone</td><td>走出舒适区</td></tr><tr><td>college</td><td>大学</td></tr><tr><td>to balance</td><td>使保持凭衡</td></tr><tr><td>academic success</td><td>学术成就</td></tr><tr><td>to look after oneself</td><td>照顾自己</td></tr><tr><td>counselling service</td><td>咨询、辅导服务</td></tr><tr><td>budgeting</td><td>预算</td></tr><tr><td>to graduate</td><td>毕业</td></tr><tr><td>life skills</td><td>生活技能</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. What did the author do that made her professors ang  

2. True or false? Three out of four students look back at university days through rose-tinted spectacles.  

3. What did Kirsty have the most difficulty with?  

4. What skill does Dr Ruth Caleb consider to be very, very important for university students to have?  

. What does the author mean by the expression 'the hard  

# 2. 请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. The party was great but now I need to sleep for a few hours before class. I'm going to  

the student dorm college the debating society the comfort zone  

2. At university it's not all about study, you know. You need to studying and partying.  

look after balance graduate acquire  

3. When at university it would be good for you to learn how to comfortably.  

be lonely be alone suffer from loneliness be single  

4. I'm not good at sports. If you want to play tennis with me you have to when I make mistakes.  

leave your comfort zone    wear rose-tinted spectacles    be patient feel stressed  

5. My daughter graduated with honours. She's achieved and I'm proud of her.  

academic success social success the counselling service life skills  

# 答案  

1. 阅读课文并回答问题。  

1. What did the author do that made her professors angry? She used to arrive late for their lectures.  

2. True or false? Three out of four students look back at university days through rose-tinted spectacles. False. According to the Imperial College London survey, three out of four students experienced high levels of stress or a mental health condition.  

3. What did Kirsty have the most difficulty with? She didn't know how to make friends and was trying to balance social success with academic success while learning how to look after herself.  

4. What skill does Dr Ruth Caleb consider to be very, very important for university students to have? Dr Ruth Caleb says budgeting is extremely important in university life.  

5. What does the author mean by the expression 'the hard way'? She means 'with difficulty'. She probably didn't know how to take care of herself and do her own washing and cleaning.  

2. 请你在不参考课文的情况下完成下列练习。从每个表格中选择一个意思合适的单词填入句子的空格处。  

1. The party was great but now I need to sleep for a few hours before class. I'm going to the student dorm.  

2. At university it's not all about study, you know. You need to balance studying and partying.  

3. When at university it would be good for you to learn how to be alone comfortably.  

4. I'm not good at sports. If you want to play tennis with me you have to be patient when I make mistakes.  

5. My daughter graduated with honours. She's achieved academic success and I'm proud of her.  