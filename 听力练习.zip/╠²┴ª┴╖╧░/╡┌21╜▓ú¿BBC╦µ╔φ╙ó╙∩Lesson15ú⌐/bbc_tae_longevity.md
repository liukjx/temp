# BBC LEARNING ENGLISH  

# Take Away English 随身英语 How to live longer  

怎么才能长寿  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

# Vocabulary: aging 词汇: 老龄化  

When is it time to slow down? Is it when you reach middle age, when you can draw your pension or even later? Queen Elizabeth II turned 90 this year and there are not many signs that she's taking it easy. Last year alone the monarch carried out over 300 engagements.  

Longevity has long been a topic of discussion in Britain. What's likely to make us live longer?  


According to Professor Sarah Harper, from the Oxford Institute of Population Ageing, just over half your chances of living a long life come down to luck. She says: "If you have parents and grandparents who made it into their eighties and nineties there's a chance you have inherited good genes. You are more likely to have a strong immune system and are less likely to develop chronic diseases."  

Lucky you, then. But don't rely on that because bad habits can spoil everything. Half of long-term smokers die prematurely. Smoking causes heart disease, lung cancer and other illnesses. A poor diet and lack of exercise can lead to obesity, which reduces your life expectancy by between three and 10 years, says the National Health Service in Britain.  

But it's not worth stressing out about how long you're going to stick around. Stress can take years off someone's life. A study published in the British Medical Journal found even low-level stress raises the risk of heart attacks and strokes by $20\%$ and you don't want that, do you?  

After you've ticked all the boxes – genes, healthy living, keeping cool – you might have almost guaranteed a long life. But for what? That's the final piece of the jigsaw. Having a purpose in life can also make you live longer. Some people engage in charity work to keep active, others get involved in initiatives in their community. It gives them a reason to wake up in the morning – even if the joints creak a little. Professor Harper says that caring for others can make you feel valued.  

It must feel good to be appreciated – by people around you, by a nation. Happy $90^{\mathrm{th}}$ birthday, Your Majesty!  

词汇表  


<html><body><table><tr><td>middle age 中年</td><td></td></tr><tr><td>draw your pension</td><td>领取退休金</td></tr><tr><td>take it easy</td><td>放松，不拼命工作</td></tr><tr><td>longevity</td><td>长寿</td></tr><tr><td>ageing</td><td>年老的，衰老的</td></tr><tr><td>chances</td><td>可能性，机会</td></tr><tr><td>inherit</td><td>继承</td></tr><tr><td>immune system</td><td>免疫系统</td></tr><tr><td>chronic disease</td><td>慢性疾病</td></tr><tr><td>bad habit</td><td>坏习惯</td></tr><tr><td>prematurely</td><td>过早的</td></tr><tr><td>life expectancy</td><td>（人的）预期寿命</td></tr><tr><td>to stick around</td><td>停留，（ （此处指）活着</td></tr><tr><td>stroke</td><td>中风</td></tr><tr><td>tick all the boxes</td><td>符合所有条件，满足所有的标准</td></tr><tr><td>keep cool</td><td>保持冷静</td></tr><tr><td>jigsaw</td><td>拼图玩具</td></tr><tr><td>charity work</td><td>公益劳动，慈善工作</td></tr></table></body></html>  

# 测验与练习  

1. 阅读课文并回答问题。  

1. What's the evidence that the British monarch is not slowing down her activities?  

2.  What can be an indication that you have good genes?  

3.  What are the four examples of things you shouldn't do if you want to live longer?  

4.  True or false? Having some anxiety is not likely to affect your health at all. It's part of life.  

5.  What benefits are there to doing charity work when you are old?  

# 2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. My sister is always busy and she worries a lot about everything. I told her to or she'll have a heart attack!  

2. I hardly ever catch a cold. My is very strong.  

stroke chronic disease life expectancy immune system  

A good diet and exercise promotes good health and  

longevity life expectancy bad habits aging  

4. This anti-aging lotion is very effective. It takes years your face!  

of out away off  

5. I on my parents to pay for my food and accommodation while I am at university.  

relay rely really rally  

# 答案  

1. 阅读课文并回答问题。   
1. What's the evidence that the British monarch is not slowing down her activities? She carried out over 300 engagements last year alone.   
2.  What can be an indication that you have good genes? If your parents and grandparents lived into their eighties or nineties.   
3.  What are the four examples of things you shouldn't do if you want to live longer? Smoke, have a poor diet, avoid exercise and get stressed about things.   
4.  True or false? Having some anxiety is not likely to affect your health at all. It's part of life. False. According to a study published in the British Medical Journal, even lowlevel stress raises the risk of heart attacks and strokes by $\mathbf{20\%}$ .   
5.  What benefits are there to doing charity work when you are old? It gives you a purpose in life, a reason to wake up in the morning.  

2. 请你在不参考课文的情况下完成下列练习。选择一个意思合适的单词填入句子的空格处。  

1. My sister is always busy and she worries a lot about everything. I told her to take it easy or she'll have a heart attack!  

2. I hardly ever catch a cold. My immune system is very strong.  

3. A good diet and exercise promotes good health and longevity.  

4. This anti-aging lotion is very effective. It takes years off your face!  

my parents to pay for my food and accommodation while  