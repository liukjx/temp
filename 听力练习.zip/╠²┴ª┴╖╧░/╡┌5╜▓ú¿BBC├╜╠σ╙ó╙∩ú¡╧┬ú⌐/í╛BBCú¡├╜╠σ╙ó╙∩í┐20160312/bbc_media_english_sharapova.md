# BBC LEARNING ENGLISH Media English 媒体英语 Sharapova's failed drug test 网球运动员莎拉波娃未通过药检  

 关于台词的备注:这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
 請注意：中文文字内容只提供簡體版  

运动时装品牌耐克宣布暂停与俄罗斯网球运动员莎拉波娃的合作。莎拉波娃在新闻发布会上宣布她没有通过今年初在澳大利亚网球公开赛期间的兴奋剂检测。请听BBC 记者Richard Conway 发回的报道。  

Winning Wimbledon aged just 17 made Maria Sharapova a global star. And for the last 11 years the five-times Grand Slam winner has been the highest-paid woman in sport. That, however, is about to change.  

Her admission that she took a banned substance, a heart drug called meldonium, has prompted several of her blue-chip corporate backers, such as Nike and Porsche, to distance themselves.  

Meldonium was placed on the list of banned drugs by WADA, the World Anti-Doping Agency, in January. It's usually prescribed for conditions such as angina, but in healthy people it boosts athletic endurance and recovery rates.  

Maria Sharapova claims a family doctor legally prescribed it to her for over ten years and she was unaware it was prohibited. But the former head of WADA, Dick Pound, believes there can be no excuses.  

词汇表  


<html><body><table><tr><td>banned substance</td><td>违禁药品</td></tr><tr><td>blue-chip</td><td>蓝筹股</td></tr><tr><td>backers</td><td>支持者，赞助者</td></tr><tr><td>angina</td><td>心绞痛</td></tr><tr><td>athleticendurance</td><td>运动时的耐力</td></tr><tr><td>legally prescribed</td><td>合法开的药</td></tr></table></body></html>  

# 测验  

请听报道并回答下列问题。  

1. True or false: Maria Sharapova has been the highest-paid person in sport for the last 11 years.  

2. Has meldonium always been a banned drug?  

3. What effect does meldonium have on people with healthy bodies?  

4. Does Maria Sharapova say she knew that meldonium was a banned drug?  

1. True or false: Maria Sharapova has been the highest-paid person in sport for the last 11 years.  

False. Maria Sharapova has been the highest-paid woman in sport for the last 11 years.  

2. Has meldonium always been a banned drug? No. Meldonium was placed on the banned substance list in January.  

3. What effect does meldonium have on people with healthy bodies? It boosts athletic endurance and recovery rates.  

4. Does Maria Sharapova say she knew melodonium was a banned drug? No, she says she was unaware it had become a banned drug.  