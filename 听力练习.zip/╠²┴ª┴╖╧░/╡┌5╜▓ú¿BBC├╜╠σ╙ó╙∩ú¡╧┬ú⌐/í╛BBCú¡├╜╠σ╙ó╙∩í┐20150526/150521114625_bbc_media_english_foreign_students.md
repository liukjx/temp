# BBC LEARNING ENGLISH Media English 媒体英语 Foreign students boost UK economy 海外留学生刺激英国经济增长  

• 关于台词的备注:请注意这不是广播节目的逐字稿件。本文稿可能没有体现录制、编辑过程中对节目做出的改变。  
• 請注意：中文文字内容只提供簡體版  

在一项由伦敦商界领袖授权进行的研究报告中显示，在伦敦学习的海外留学生对英国经济作出了23 亿英镑的贡献，因此商界领袖呼吁政府应把留学生排除在净移民统计数据之外。 请听 BBC 记者 Mark Easton 的报道：  

London is the most popular city in the world for international students, with 100,000 in the capital at any one time. Two thirds come from outside the EU – temporary foreign visitors who, according to a study by the business organisation London First and the accountants PwC, contribute £2.3bn net to the UK economy each year and support nearly 70,000 jobs.  

The business leaders are urging the government not to include students in their net migration target. It argues ministers should also reinstate the right for foreign students to work in the UK for a few years after graduation.  

The Home Office said it was right to include students in net migration figures because all immigrants had an impact on communities, housing and public services.  

# Questions  

1. Where do most of the foreign students come from?   
2. What should students be allowed to do after their studies, according to the study?   
3. True or false? Students might have an impact on accommodation but not on transport.   
4. What word used in the report describes 'something many people like and seek'?  

# Vocabulary and definitions  

<html><body><table><tr><td>accountants</td><td>会计事务所</td></tr><tr><td>net</td><td>净 (收入)</td></tr><tr><td>urging</td><td>呼吁</td></tr><tr><td>argues</td><td>辩论</td></tr><tr><td>reinstate</td><td>使复原，使恢复</td></tr><tr><td>graduation</td><td>毕业</td></tr><tr><td>impact</td><td>影响</td></tr><tr><td>public services</td><td>公共服务</td></tr></table></body></html>  

1. Where do most of the foreign students come from? Answer: Outside the EU (European Union).   
2. What should students be allowed to do after their studies, according to the study? Answer: To work in the UK for a few years after graduation.   
3. True or false? Students might have an impact on accommodation but not on transport. Answer: False. According to the Home Office, they have an impact on public services and transport in London is a public service.   
4. What word used in the report describes 'something many people like and seek'? Answer: Popular.  