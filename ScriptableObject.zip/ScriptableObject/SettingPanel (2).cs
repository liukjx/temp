using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SettingPanel : MonoBehaviour
{
    public Toggle musicTog;
    public Toggle soundTog;
    public Slider musicSlider;
    public Slider soundSlider;

    public SettingInfo info;

    // Start is called before the first frame update
    void Start()
    {
        info = ScriptableObject.CreateInstance<SettingInfo>();

        musicTog.isOn = info.musicIsOpen;
        soundTog.isOn = info.soundIsOpen;
        musicSlider.value = info.musicValue;
        soundSlider.value = info.soundValue;

        //��UI����� �ؼ��仯ʱ ��¼����
        musicTog.onValueChanged.AddListener((value) =>
        {
            info.musicIsOpen = value;
        });

        soundTog.onValueChanged.AddListener((value) =>
        {
            info.soundIsOpen = value;
        });

        musicSlider.onValueChanged.AddListener((value) =>
        {
            info.musicValue = value;
        });

        soundSlider.onValueChanged.AddListener((value) =>
        {
            info.soundValue = value;
        });
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            info.Save();
    }
}
