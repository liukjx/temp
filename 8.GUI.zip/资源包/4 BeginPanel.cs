﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BeginPanel : MonoBehaviour
{
    public Rect labPos;
    public GUIContent labContent;
    public GUIStyle labStyle;

    public Rect btn1Pos;
    public Rect btn2Pos;
    public Rect btn3Pos;

    public GUIStyle btnStyle;

    private void OnGUI()
    {

        //游戏标题
        GUI.Label(labPos, labContent, labStyle);

        //3个游戏按钮
        if(GUI.Button(btn1Pos, "开始游戏", btnStyle))
        {
           
        }
        if(GUI.Button(btn2Pos, "设置游戏", btnStyle))
        {
            
        }
        if(GUI.Button(btn3Pos, "退出游戏", btnStyle))
        {

        }
    }
}
