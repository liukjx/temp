# Reme雅思必修语法规则课 - 系统总结

## 课程概述

本课程基于SAT语法体系，系统梳理雅思写作中必须掌握的核心语法规则，强调**逻辑优先**而非死记硬背。课程采用同心圆模型，将语法现象按考试频率和重要性分层讲解。

## 核心语法体系图

```mermaid
graph TD
    A[雅思语法体系] --> B[高频核心]
    A --> C[次高频]
    A --> D[外围工具]
    
    B --> B1[Logical Prediction - 逻辑预测]
    B --> B2[Fragment - 句子完整性]
    B --> B3[Subject-Verb Agreement - 主谓一致]
    B --> B4[Run-on - 粘连句]
    
    C --> C1[Parallelism - 平行结构]
    C --> C2[Pronouns - 代词指代]
    C --> C3[Tenses - 时态]
    C --> C4[Modifiers - 修饰语]
    
    D --> D1[Subjunctive Mood - 虚拟语气]
    D --> D2[Absolute Construction - 独立结构]
    D --> D3[Inversion - 倒装]
```

## 1. 高频核心语法

### 1.1 Logical Prediction (LP) - 逻辑预测
**核心概念**：判断非谓语动词(V-ing/V-ed)的主动/被动关系

**判断标准**：
- V-ing: 表示主动关系，主语是动作的发出者
- V-ed: 表示被动关系，主语是动作的承受者

**常见错误**：
```markdown
❌ Raised in rural NC, a banjo technique...
✅ Raised in rural NC, Earl Scruggs invented...

❌ Writing about visions, the book reveals...
✅ Writing about visions, Julian of Norwich reveals...
```

### 1.2 Fragment - 句子不完整
**识别特征**：缺少主语(S)或谓语(V)

**修正方法**：
1. 添加缺失的主谓结构
2. 将短语改为完整句子

**示例**：
```markdown
❌ Realizing the potential, to make significant changes.
✅ Realizing the potential, researchers made significant changes.

❌ A technique that revolutionized the industry.
✅ A technique that revolutionized the industry was widely adopted.
```

### 1.3 Subject-Verb Agreement - 主谓一致
**关键规则**：
- 单数主语 + 单数动词
- 复数主语 + 复数动词
- 注意插入语和修饰语的干扰

**陷阱识别**：
```markdown
❌ The team of researchers are presenting...
✅ The team of researchers is presenting...

❌ One of the students have completed...
✅ One of the students has completed...
```

### 1.4 Run-on - 粘连句
**类型**：
1. 逗号拼接 (Comma splice)
2. 融合句 (Fused sentence)

**修正方法**：
- 使用并列连词(FANBOYS)
- 改为分号
- 拆分为独立句子

**示例**：
```markdown
❌ The experiment was successful, the results were published.
✅ The experiment was successful, and the results were published.
✅ The experiment was successful; the results were published.
```

## 2. 次高频语法现象

### 2.1 Parallelism - 平行结构
**原则**：并列成分必须在语法形式上保持一致

**应用表格**：

| 结构类型 | 正确示例 | 错误示例 |
|---------|----------|----------|
| 名词并列 | apples, oranges, and bananas | apples, oranges, and eat bananas |
| 动词并列 | to read, to write, and to think | to read, writing, and think |
| 形容词并列 | tall, dark, and handsome | tall, dark, and runs fast |

### 2.2 Pronouns - 代词指代
**核心原则**：代词必须清晰指代特定名词，避免歧义

**检查清单**：
- [ ] 指代对象明确
- [ ] 单复数一致
- [ ] 避免模糊指代

**示例**：
```markdown
❌ When the car hit the tree, it was damaged. (谁损坏？)
✅ When the car hit the tree, the car was severely damaged.

❌ The professor told the student that he needed to study harder. (谁需要？)
✅ The professor told the student, "You need to study harder."
```

### 2.3 Tenses - 时态
**雅思写作重点时态**：
- 一般现在时：陈述事实、普遍真理
- 现在完成时：强调过去动作对现在的影响
- 一般过去时：描述具体历史事件

**时态一致性规则**：
- 主从句时态可以不一致（与中式思维不同）
- 时态选择基于逻辑而非机械对应

### 2.4 Modifiers - 修饰语
**类型与位置**：

```mermaid
graph LR
    M[修饰语] --> A[前置修饰]
    M --> B[后置修饰]
    M --> C[插入语]
    
    A --> A1[形容词]
    A --> A2[分词短语]
    
    B --> B1[定语从句]
    B --> B2[介词短语]
    
    C --> C1[同位语]
    C --> C2[破折号内容]
```

## 3. 外围语法工具

### 3.1 Subjunctive Mood - 虚拟语气
**使用场景**：
- 与事实相反的假设
- 建议、命令、要求的宾语从句

**结构表格**：

| 时间 | 条件从句 | 主句 |
|------|----------|------|
| 现在 | If + 过去式 | would/could + 动词原形 |
| 过去 | If + 过去完成式 | would/could + have + 过去分词 |
| 将来 | If + should/were to | would/could + 动词原形 |

### 3.2 Absolute Construction - 独立结构
**定义**：独立于主句的状语结构，提供额外信息

**常见形式**：
```markdown
✅ The weather being fine, we decided to go hiking.
✅ His homework finished, Tom went out to play.
✅ With the exam approaching, students studied harder.
```

### 3.3 Inversion - 倒装
**使用条件**：
- 否定副词开头（never, hardly, scarcely）
- so/such...that结构
- 虚拟条件句省略if

**示例**：
```markdown
✅ Never have I seen such beautiful scenery.
✅ So difficult was the problem that few could solve it.
✅ Were I to win the lottery, I would travel the world.
```

## 4. 逻辑连接词系统

### 4.1 逻辑关系分类

| 关系类型 | 连接词 | 示例 |
|---------|--------|------|
| 因果 | because, since, as | The delay occurred because traffic was heavy. |
| 转折 | however, nevertheless | She was tired; however, she continued working. |
| 递进 | furthermore, moreover | The plan is practical; moreover, it's cost-effective. |
| 举例 | for example, for instance | Many fruits are rich in vitamins, for example, oranges. |
| 对比 | whereas, while | City life is fast-paced, while rural life is relaxed. |

### 4.2 Conjunction vs. Conjunctive Adverb

```mermaid
graph TD
    A[连接词类型] --> B[Coordinating Conjunction]
    A --> C[Subordinating Conjunction]
    A --> D[Conjunctive Adverb]
    
    B --> B1[FANBOYS: for, and, nor, but, or, yet, so]
    C --> C1[Because, although, if, when]
    D --> D1[However, therefore, moreover]
    
    style B1 fill:#f9f,stroke:#333
    style C1 fill:#bbf,stroke:#333
    style D1 fill:#bfb,stroke:#333
```

**关键区别**：
- Coordinating: 连接两个独立分句
- Subordinating: 引导从属分句
- Conjunctive Adverb: 连接两个独立句子，需用分号或句号

## 5. 雅思写作应用指南

### 5.1 句子构建策略
1. **主次分明**：主要信息用主句，次要信息用从句或修饰语
2. **逻辑清晰**：使用适当的连接词表明逻辑关系
3. **简洁有力**：避免冗余表达

### 5.2 常见错误预防

**检查清单**：
- [ ] 每个句子都有完整的主谓结构
- [ ] 代词指代清晰明确
- [ ] 时态使用符合逻辑
- [ ] 平行结构保持一致
- [ ] 修饰语位置正确

### 5.3 高分句式模板

**复合句模板**：
```markdown
Although [次要信息], [主要信息], which [补充说明].

Despite [让步状语], [主句], resulting in [结果].

Not only [第一并列成分], but also [第二并列成分].
```

## 6. 实战练习建议

### 6.1 自我检测问题
1. 这个句子是否有完整的主谓结构？
2. 代词指代是否明确？
3. 时态使用是否符合逻辑？
4. 平行结构是否一致？
5. 修饰语是否靠近被修饰词？

### 6.2 进步路径
```mermaid
journey
    title 语法能力提升路径
    section 基础阶段
      识别句子成分: 5: 新手
      理解主谓一致: 4: 新手
    section 进阶阶段
      掌握平行结构: 7: 学习者
      运用逻辑连接: 6: 学习者
    section 高级阶段
      灵活使用时态: 8: 熟练者
      精准表达逻辑: 9: 专家
```

## 结语

掌握雅思语法的关键在于理解**逻辑优先**原则，而非机械记忆规则。通过系统学习高频语法现象，并在写作中刻意练习主次分明的表达方式，可以显著提升雅思写作成绩。记住：好的语法是为了清晰表达思想，而不是展示复杂结构。

---

*本总结基于SAT语法体系，适用于雅思写作7分以上目标学员。建议配合实际写作练习，每周重点攻克1-2个语法难点。*