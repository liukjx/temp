以下是根据课程语音转文字稿，系统梳理的 **Run-on 句子** 及相关语法知识点，采用表格 + 例子 + Mermaid 流程图的方式呈现，方便理解与记忆。

---

### ✅ 一、Run-on 句子定义与识别

| 项目 | 说明 | 例子 |
|------|------|------|
| **定义** | 两个或多个完整主谓宾（SVO）结构被错误连接，未使用适当的“墙”隔开 | ❌ `She loves reading, she reads every day.` |
| **中文类比** | 像两个家庭住在一个屋檐下 → 打架 | “你不给我钱，我死给你看。”（中文无连词也可，英文不行） |
| **常见错误** | 逗号连接两个完整句子（Comma Splice） | ❌ `Anna is tired, she went to bed.` |

---

### ✅ 二、三种“墙”：合法连接句子的方式

| 墙类型 | 作用 | 例子 | 备注 |
|--------|------|------|------|
| **句号（.）** | 完全分隔，B 是 A 的解释或延伸 | `I’m hungry. I didn’t eat all day.` | 最干净利落的断开 |
| **分号（;）** | 表示并列（paraphrase）或轻微转折 | `I’m home all alone; no one is here.` | 英国/美国通用 |
| **连词（Conjunction）** | 明确逻辑关系 | `I was tired, so I went to bed.` | 需用逗号隔开两个完整句子 |

---

### ✅ 三、连词分类与使用规则

#### 1️⃣ Coordinating Conjunction（大哥连词）FANBOYS

| 连词 | 含义 | 例子 |
|------|------|------|
| **F**or | 因为 | `I stayed home, for I was sick.` |
| **A**nd | 并列 | `She sings and dances.` |
| **N**or | 也不 | `He doesn’t smoke, nor does he drink.` |
| **B**ut | 但是 | `She’s shy, but she speaks well.` |
| **O**r | 或者 | `You can stay, or you can leave.` |
| **Y**et | 然而 | `It’s raining, yet he went out.` |
| **S**o | 所以 | `It was cold, so I wore a coat.` |

> ✅ **规则**：两个完整句子之间必须用逗号 + FANBOYS。

#### 2️⃣ Subordinating Conjunction（小弟连词）

| 类别 | 连词 | 例子 |
|------|------|------|
| **因果** | because, since, as | `I left because I was tired.` |
| **转折** | although, though, even though | `Although it rained, we went out.` |
| **条件** | if, unless | `If you come, I’ll be happy.` |
| **时间** | when, while, after, before | `After she left, I cried.` |
| **对比** | whereas, while | `Anna is a student, whereas Remy is a teacher.` |

> ✅ **规则**：可放句首或句中，**句首时逗号隔开**，句中不加逗号。

---

### ✅ 四、易混淆项：Conjunctive Adverbs（连接性副词）

| 副词 | 含义 | 正确用法 | 错误用法 |
|------|------|-----------|-----------|
| **however** | 然而 | `She was tired; however, she stayed.` | ❌ `She was tired, however, she stayed.` |
| **therefore** | 所以 | `He lied; therefore, I left.` | ❌ `He lied, therefore I left.` |
| **moreover** | 此外 | `It’s cold; moreover, it’s raining.` | ❌ `It’s cold moreover it’s raining.` |

> ⚠️ 这些词 **不是连词**，不能单独连接两个完整句子，需配合分号或句号。

---

### ✅ 五、Run-on 改法总结（以原稿句子为例）

原句：
> Television weather forecasters sometimes over-dramatize the severity of an approaching snowstorm, this causes unnecessary anxiety.

#### ✅ 正确改法对比：

| 改法 | 类型 | 结果 |
|------|------|------|
| **加连词** | Coordinating | `...snowstorm, and this causes...` |
| **加分号** | Paraphrase | `...snowstorm; this causes...` |
| **加分号+副词** | Conjunctive Adverb | `...snowstorm; therefore, this causes...` |
| **改从句** | Subordinating | `...snowstorm, which causes...`（英式可接受，美式慎用） |
| **改分词结构** | 非谓语 | `...snowstorm, causing unnecessary anxiety.` ✅最推荐 |

---

### ✅ 六、Mermaid 流程图：如何判断 Run-on 并修改

```mermaid
flowchart TD
    A[句子中有两个完整SVO结构？] -->|是| B[中间是否有“墙”？]
    B -->|句号| C✅合法
    B -->|分号| D✅合法
    B -->|逗号+FANBOYS| E✅合法
    B -->|逗号| F❌Run-on
    F --> G[选择修改方式]
    G --> G1[加连词]
    G --> G2[改分号]
    G --> G3[改从句]
    G --> G4[改非谓语]
```

---

### ✅ 七、学习建议

| 目标 | 建议 |
|------|------|
| **识别 Run-on** | 每写完一句，检查是否有两个主谓宾结构 |
| **练习改写** | 用不同“墙”改同一句，体会语义变化 |
| **避免中式直译** | 中文“逗号+句” ≠ 英文“逗号+句” |
| **写作检查清单** | 写作后留5分钟，专查 Run-on、Fragment、时态、平行结构 |

---

如需我帮你批改作文中的 Run-on 句子，欢迎贴出来，我可以逐句帮你改。