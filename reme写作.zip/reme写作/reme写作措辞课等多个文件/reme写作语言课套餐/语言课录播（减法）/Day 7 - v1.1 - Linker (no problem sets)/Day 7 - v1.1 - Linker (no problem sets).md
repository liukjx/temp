以下内容将这份口语转写稿提炼成体系化知识，分三部分：  
1. 核心概念速览（表格）  
2. 逻辑连接词用法流程图（Mermaid）  
3. 学习与应用建议  

---

### 1. 核心概念速览

| 类别     | 关键词                                                 | 定义/作用                            | 常见误区                           | 示例                                                    |
| -------- | ------------------------------------------------------ | ------------------------------------ | ---------------------------------- | ------------------------------------------------------- |
| 主从关系 | subordinating conjunction（小弟）                      | 把次要信息做成从句，依附于主句       | 误以为 complex sentence 必须有从句 | While Emma was walking, she saw her crush.              |
| 并列关系 | coordinating conjunction（大哥）                       | 连接两个对等分句，表达并列/转折/因果 | 一主多从可以，一主多“并列”就裂句   | She was shy, so she ran away.                           |
| 伪连词   | therefore / hence / thus                               | 实为副词，不能单独用逗号连句         | 写成 “SVO, therefore, SVO.” ❌      | SVO. Therefore, SVO.                                    |
| 伪连词   | however / nevertheless / nonetheless                   | 表转折的副词，同样不能单独逗号连句   | 写成 “SVO, however, SVO.” ❌        | SVO; however, SVO.                                      |
| 逻辑插入 | in other words / for instance / likewise / by contrast | 对前文进行解释、举例、并列或对比     | 只看字面，忽略后句必须匹配的功能   | …lower in sugar; in other words, it has fewer calories. |

---

### 2. 逻辑连接词用法流程图

```mermaid
flowchart TD
    A[句子关系判断] --> B{并列 or 从属}
    B -->|并列| C[使用 coordinating conjunction <br>(and, but, so, or)]
    B -->|从属| D[使用 subordinating conjunction <br>(while, because, although)]
    
    E[需要语义衔接] --> F{副词/插入语}
    F --> G[总结 → therefore/thus<br>SVO. Therefore, SVO.]
    F --> H[转折 → however/nevertheless<br>SVO; however, SVO.]
    F --> I[解释 → in other words<br>SVO; in other words, ...]
    F --> J[举例 → for instance<br>SVO. For instance, ...]
    F --> K[并列 → likewise<br>SVO. Likewise, ...]
    F --> L[对比 → by contrast<br>SVO. By contrast, ...]
```

---

### 3. 学习与应用建议

| 阶段     | 任务                                                                                   | 工具与示例                                                                                                               |
| -------- | -------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| 识别     | 判断句内谁是“大哥”（只能1个）谁是小弟（可有N个）                                       | 例：While (小弟) + SVO, SVO (大哥)。                                                                                     |
| 正误     | 把 therefore/however 当连词是高频错误                                                  | 错：She was late, therefore, she missed the bus.<br>对：She was late. Therefore, she missed the bus.                     |
| 语义匹配 | 选对连接词=看后句功能                                                                  | 前句：Greek yogurt has less sugar.<br>后句：It also packs more protein.<br>→ 递进用 also / moreover，而非 for instance。 |
| 写作训练 | 每写一句复合句，自问：<br>1. 修饰成分是否与主题相关？<br>2. 连接词后句是否与功能匹配？ | 错：…her crush, whose jacket was black…（无关）<br>对：…her crush, who didn’t even know she existed…（相关）             |
| 刷题     | SAT 语法题专练“句子插入”与“词义辨析”                                                   | 推荐：College Board Official SAT Practice Test 8, Section 2, Q8/Q9/Q14。                                                 |

---

### 一句话总结  
把连接词当成“逻辑胶水”：  
- 先分清“大哥/小弟”决定从属还是并列；  
- 再确认胶水后句的功能（总结、转折、举例…）；  
- 最后检查修饰是否真正为主题服务。