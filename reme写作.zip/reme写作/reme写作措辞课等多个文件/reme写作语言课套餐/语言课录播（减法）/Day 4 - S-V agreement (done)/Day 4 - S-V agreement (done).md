这份转写稿是一场高强度的“主谓一致”口语教学实录。老师用大量真实语料、倒装句、长修饰语和“骂醒式”提醒，帮学生把“语法直觉”变成“肌肉记忆”。下面用“知识点＋例子＋可视化”做系统梳理，并给出后续学习建议。

---

### 1. 主谓一致核心框架

| 维度             | 判定步骤                                    | 易错点                   | 速记口诀                           | 示例                                                              |
| ---------------- | ------------------------------------------- | ------------------------ | ---------------------------------- | ----------------------------------------------------------------- |
| 1. 找主语        | 先排除there-be / 地点优先 / 倒装            | 把倒装“地点”当主语       | “地点开头先倒装，主语躲在动词后”   | Across the plains **travels** the rover. ⇨ The rover **travels**… |
| 2. 数的一致      | 主语单⇒谓语+s；主语复⇒原形                  | 被长定语从句隔开就看花眼 | “主谓中间隔再远，也要牵手算单复”   | The idea **that he proposed** **was** accepted.                   |
| 3. 意义一致      | 集体名词、不可数名词按“整体”算单数          | 只看靠近名词的“s”        | “整体单数，成员复数”               | The team **is** united. vs The team **are** arguing.              |
| 4. 就近/就远陷阱 | “A as well as B”谓语跟A；“either…or…”跟后者 | 被插入语带跑             | “as well as 不算数，or/nor 看后者” | Tom, as well as his friends, **is** coming.                       |
| 5. 定语从句干扰  | which/that 只是修饰，不影响主语数           | 把which 当成主语         | “which 只是小尾巴，主语在前头”     | The book that sells well **is** mine.                             |

---

### 2. 高频倒装句模板

```mermaid
graph TD
    A[地点/方位短语开头] --> B{介词+地点}
    B --> C[整句倒装]
    C --> D[谓语提前，主语置后]
    D --> E[主谓一致看“后”面真正主语]
```

| 模板                                           | 还原语序                            | 主谓一致检验                               |
| ---------------------------------------------- | ----------------------------------- | ------------------------------------------ |
| There **is/are** piles of debris.              | Piles of debris **are** there.      | debris 为不可数，但 piles 为复数 → **are** |
| To the south of the lot **stands** a building. | A building **stands** to the south… | building 单数 → **stands**                 |
| Just outside the city **lies** a lake.         | A lake **lies** just outside…       | lake 单数 → **lies**                       |

---

### 3. 长修饰语“断句”技巧

当主语与谓语之间被 which/that/-ing/-ed 插入时，用“括号法”快速断句：

原句  
The aquatic weed [which grows far more rapidly than do plants native to the lake (it infests)] **threatens** freshwater ecosystems.

步骤  
1. 把 `[...]` 整体划掉，句子变成：The aquatic weed **threatens**…  
2. 只剩主语 weed（单数）⇒ 谓语必须 **threatens**（加 s）。

---

### 4. 量词 + 名词的数

| 结构                                         | 量词决定单复数   | 例子                                                |
| -------------------------------------------- | ---------------- | --------------------------------------------------- |
| a number of + 名词复数                       | 复数             | A number of books **are** missing.                  |
| the number of + 名词复数                     | 单数（整体数量） | The number of books **is** large.                   |
| one of + 名词复数 + that + 谓语复数          | 复数             | He is one of the students who **are** late.         |
| the only one of + 名词复数 + that + 谓语单数 | 单数             | He is the only one of the students who **is** late. |

---

### 5. that vs which 的“信息量”区别

| 关系词 | 信息性质           | 可否省略 | 例句                                                                                       |
| ------ | ------------------ | -------- | ------------------------------------------------------------------------------------------ |
| that   | 限定性（必须信息） | ❌        | The book **that is on the table** is mine.（哪一本？必须说明）                             |
| which  | 补充性（多余信息） | ✅        | Harry Potter, **which is popular with kids**, is on the table.（已知是哪本，后面只是补充） |

---

### 6. 学习路线 & 后续建议

1. 当天练习  
   - 用“括号法”重刷今天所有例句，每句 10 秒内说出主语和正确谓语。  
   - 把倒装模板手抄 5 遍，录音朗读，培养语感。

2. 一周巩固  
   - 每天 5 句长难句（可选《托福官方指南》或《雅思剑桥》），先划主语再填空。  
   - 用 Anki 制作卡片：正面给倒装句，背面给还原语序 + 主谓一致解释。

3. 两周提升  
   - 写 3 段小短文，刻意使用：  
     ① there-be 倒装 ② 地点开头倒装 ③ 长定语从句。  
   - 用 Grammarly/ChatGPT 检查主谓一致，错误截图→回炉复习对应知识点。

4. 终极自检清单（写作/口语前 30 秒扫一遍）  
   - 句首是介词短语吗？→ 先想“倒装”  
   - 主谓之间有没有 which/that/插入语？→ 用括号法  
   - 量词是 a number of 还是 the number of？→ 决定单复数  
   - 看到 either…or…/not only…but also…→ 看“就近”原则  
   - 集体名词整体还是成员？→ 决定单复数

---

一句话总结  
**“主谓一致”考的不是背规则，而是“看清主语”的速度——把倒装还原、把修饰语括起来，你就能一眼锁定谓语是否加 s。**