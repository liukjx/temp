---

# LP（Logical Predication）课程全梳理  
*“主语能不能发出这个动作？”—— 一句话记住 LP 的核心*

---

## 1. 什么是 LP？
| 名称                      | 定义                                              | 一句话解释               | 易错点                     |
| ------------------------- | ------------------------------------------------- | ------------------------ | -------------------------- |
| Logical Predication（LP） | 检查主语与谓语（或分词）之间的“主动/被动”是否合理 | 主语能不能发出这个动作？ | 忽略主语身份（人/物/事件） |

---

## 2. 判断步骤（万能三步）
```mermaid
flowchart TD
    A[读句子] --> B[找主语]
    B --> C[找动词/分词]
    C --> D{主语能发出这个动作吗？}
    D -->|Yes| E[无 LP 错误]
    D -->|No | F[有 LP 错误，需改写]
```

---

## 3. 高频语法点速查表
| 语法点         | 主动形式            | 被动形式   | 示例                                              | 典型错例                                             |
| -------------- | ------------------- | ---------- | ------------------------------------------------- | ---------------------------------------------------- |
| 现在分词 V-ing | doing               | being done | She entered the room **carrying** a bag.          | The room entered **carrying** a bag. ❌               |
| 过去分词 V-ed  | did                 | done       | The book **was written** by her.                  | The book **wrote** in 1900. ❌                        |
| 倒装           | Only after… did sb… | —          | Only after **reading** it did I understand.       | Only after **reading** it was the book understood. ❌ |
| 独立主格       | N + V-ing/V-ed      | —          | **Blue lights flashing**, the police car stopped. | —                                                    |

---

## 4. 七大经典场景与改错示范
| 场景           | 原句(错)                                                  | 原因                | 改写(对)                                                                  | 备注             |
| -------------- | --------------------------------------------------------- | ------------------- | ------------------------------------------------------------------------- | ---------------- |
| 技巧被发明     | The **technique** was raised in NC.                       | 技巧 ≠ 被抚养       | The **musician** who invented the technique was raised in NC.             | 主语换成人       |
| 书籍被写       | The **book** writing in 1900…                             | 书 ≠ 主动写         | The **book written** in 1900…                                             | V-ed 表被动      |
| 城市变富       | **Lisbon** was enriched by trade.                         | ✅ 城市可被 enrich   | 无需修改                                                                  | 主语可被动作作用 |
| 票被提前买     | **Tickets** knowing the movie was popular…                | 票 ≠ 知道           | **We** bought tickets ahead of time, **knowing**…                         | 主语换成“人”     |
| 诗被读         | After **reading** it, the poem began to make sense.       | 诗 ≠ 主动读         | After **reading** it, **I** began to make sense of the poem.              | 补出真正主语     |
| 华尔兹震惊世人 | With partners whirling, **many people** were shocked.     | 主语应为“舞蹈”      | With partners whirling, **the waltz** shocked many people.                | 动作发出者是舞蹈 |
| 同位语错位     | The first Mexican to win the Nobel, the **prize** earned… | 同位语 ≠ 动作发出者 | The first Mexican to win the Nobel **earned** the prize by demonstrating… | 把同位语变主语   |

---

## 5. 中英思维差异提醒
| 英文思维             | 中文思维       | 例子对比                                                                                           |
| -------------------- | -------------- | -------------------------------------------------------------------------------------------------- |
| 修饰语后置           | 修饰语前置     | A technique **invented by Earl** → Earl **发明的**技巧                                             |
| 被动语态高频         | 被动语态低频   | The book **was written** in 1900. → 这本书写于1900年。                                             |
| 主语必须是动作发出者 | 话题可省略主语 | **Having lived in Paris**, Martha speaks fluent French. → 因为在巴黎住了六年，**Martha**法语流利。 |

---

## 6. 易错陷阱 TOP5
1. **看到 V-ing 就默认主动**  
   ❌ *The mountain climbed carrying a backpack…*  
2. **忽视主语身份（人 vs 物）**  
   ❌ *The technique was raised in North Carolina.*  
3. **倒装句误判主语**  
   ❌ *Only after reading it was the poem understood.*（缺真正主语）  
4. **同位语错当主语**  
   ❌ *The first woman pilot, Amelia Earhart’s achievement inspired…*  
5. **独立主格贴错修饰对象**  
   ❌ *Wang Jia climbed the mountain carrying Betty.*（歧义：山抱 Betty？）

---

## 7. 实战建议
| 任务         | 工具                     | 频次      | 备注                       |
| ------------ | ------------------------ | --------- | -------------------------- |
| 每日一句改错 | 老 SAT / ACT LP 题库     | 5 句/天   | 先三步法，再对照答案       |
| 朗读+录音    | 自己改写后的正确句子     | 2 分钟/天 | 培养“主语—动作”直觉        |
| 中英回译     | 把英文被动句→中文→再英文 | 3 句/周   | 强化差异意识               |
| 错题本       | Notion/Excel 记录错因    | 每周回顾  | 分类：主语误用/倒装/同位语 |

---

### 8. 一页速记卡片（可打印）
```
LP 三步速查
1. Who? → 主语
2. Do?  → 动作
3. OK? → 主语能发出动作吗？

常见符号
✅ 人 → 主动
✅ 物 → 看能否被作用
❌ 物 → 主动发出动作 = 错！

万能改写公式
错：The N1 V-ing… → 对：The N2 who V-ed…
例：The book writing… → The author who wrote the book…
```

---

**最后提醒**：  
做题时先默念“主语能不能干这事”，99% 的 LP 问题迎刃而解。