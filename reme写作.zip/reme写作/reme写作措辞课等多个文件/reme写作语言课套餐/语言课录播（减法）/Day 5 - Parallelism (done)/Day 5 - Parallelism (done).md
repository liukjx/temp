# 📌 **平行结构（Parallelism）系统总结**

---

## 一、什么是平行结构（Parallelism）？

**定义**：  
平行结构是指**在句子或段落中，使用相同语法形式来表达并列或对比的内容**，使语言更清晰、逻辑更严谨。

---

## 二、平行结构的分类

| 类型       | 定义说明               | 关键点                           | 示例                                                          |
| ---------- | ---------------------- | -------------------------------- | ------------------------------------------------------------- |
| **小平行** | 句子内部的并列结构     | 词性一致、褒贬一致、抽象具体一致 | She likes **reading, writing, and swimming**.                 |
| **大平行** | 句子或段落间的对比结构 | 对比物一致、单复数一致、逻辑一致 | **Unlike Anna, the cat is smarter than you.** → ❌（逻辑错误） |

---

## 三、小平行（Micro-Parallelism）

### 1. 结构形式

| 形式                  | 示例                                            |
| --------------------- | ----------------------------------------------- |
| A, B, and C           | She is **smart, kind, and hardworking**.        |
| A and B               | He enjoys **coffee and tea**.                   |
| Not only A but also B | She is **not only smart but also hardworking**. |

### 2. 三大原则

| 原则             | 说明                 | 错误示例                                   | 正确示例                                      |
| ---------------- | -------------------- | ------------------------------------------ | --------------------------------------------- |
| **词性一致**     | 并列成分词性相同     | She likes **reading, to write, and swim**. | She likes **reading, writing, and swimming**. |
| **褒贬一致**     | 并列成分情感色彩一致 | He is **smart but stupid**.                | He is **smart but lazy**.                     |
| **抽象具体一致** | 并列成分层级一致     | I like **apples, bananas, and fruit**.     | I like **apples, bananas, and grapes**.       |

---

## 四、大平行（Macro-Parallelism）

### 1. 核心口诀

> **“有对比，就有大平行。”**

### 2. 逻辑要求

| 要求           | 说明               | 错误示例                                     | 正确示例                                                 |
| -------------- | ------------------ | -------------------------------------------- | -------------------------------------------------------- |
| **对比物一致** | 对比对象性质相同   | The cat is smarter than **you**.             | The cat’s IQ is higher than **yours**.                   |
| **单复数一致** | 单对单，多对多     | The number of boys is higher than **girls**. | The number of boys is higher than **that of girls**.     |
| **逻辑一致**   | 对比内容清晰无歧义 | My parents, Jack and Rose, came to visit.    | My parents, **along with** Jack and Rose, came to visit. |

### 3. 常见对比连词

| 连词         | 正确搭配                  | 错误示例                    |
| ------------ | ------------------------- | --------------------------- |
| **more**     | more **than**             | more **compare to** ❌       |
| **prefer**   | prefer A **to** B         | prefer A **than** B ❌       |
| **between**  | between A **and** B       | between A **or** B ❌        |
| **not only** | not only A **but also** B | not only A **and also** B ❌ |
| **either**   | either A **or** B         | either A **nor** B ❌        |

---

## 五、常见错误与修正

| 错误句子                                     | 问题分析     | 修正建议                                             |
| -------------------------------------------- | ------------ | ---------------------------------------------------- |
| She likes **reading, to write, and swim**.   | 词性不一致   | She likes **reading, writing, and swimming**.        |
| The cat is smarter than **you**.             | 对比物不一致 | The cat’s IQ is higher than **yours**.               |
| He is **smart but stupid**.                  | 褒贬矛盾     | He is **smart but lazy**.                            |
| The number of boys is higher than **girls**. | 单复数不一致 | The number of boys is higher than **that of girls**. |

---

## 六、Mermaid 流程图：大平行判断逻辑

```mermaid
graph TD
A[出现对比结构] --> B{对比物是否一致？}
B -->|是| C[单复数是否一致？]
B -->|否| D[修改对比物]
C -->|是| E[逻辑是否清晰？]
C -->|否| F[调整单复数]
E -->|是| G[正确的大平行]
E -->|否| H[重写句子]
```

---

## 七、学习建议

| 阶段     | 建议                                               |
| -------- | -------------------------------------------------- |
| **初学** | 先掌握小平行的三大原则，做句子改错练习。           |
| **进阶** | 分析大平行的逻辑，尤其是对比物的一致性。           |
| **实战** | 在写作中刻意使用平行结构，写完后自查是否违反原则。 |
| **工具** | 使用语法检查工具（如 Grammarly）辅助识别平行错误。 |

---

## 八、一句话总结

> **“平行结构不是修辞的装饰品，而是逻辑的骨架。”**

---

如需练习题或作文批改模板，可继续向我索取。