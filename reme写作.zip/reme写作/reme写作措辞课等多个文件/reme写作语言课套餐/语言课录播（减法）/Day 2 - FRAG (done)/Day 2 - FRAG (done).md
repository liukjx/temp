【一】课程核心知识点一览  
| 知识点 | 一句话解释 | 经典错误例 | 正确写法 | 备注 |
|---|---|---|---|---|
| 句子碎片 Fragment | 缺少主语或谓语，只是一个“短语”就句点。 | Eating an ice cream. ❌ | Anna is eating an ice cream. ✅ | 至少要有 S+V |
| 主谓一致 | 主语中心词决定谓语单复数。 | The list of items are long. ❌ | The list of items is long. ✅ | 不要被介词短语迷惑 |
| 时态≠时间 | 时态是“时间+状态”；别死记硬背形态。 | The parents are facing the problem. ❌（状态：正在发生） | The parents now face the problem. ✅（状态：常态） | 先定时间，再选状态 |
| 非谓语动词作定语 | -ing/-ed/-to do 放在名词后当形容词。 | The girl singing on stage… | 注意与谓语区分 | 避免“大主语”陷阱 |
| 修饰语要成对逗号 | 非限定性定语、插入语前后逗号成双。 | Tokyo, which is the capital of Japan attracts tourists. ❌ | Tokyo, which is the capital of Japan, attracts tourists. ✅ | 只逗前面不逗后面=错 |
| 就近指代原则 | 关系代词通常指代最近的名词。 | I bought a book from the shop which was very expensive. ❌（指shop?） | I bought a book, which was very expensive, from the shop. ✅ | SAT/ACT 高频考点 |
| 平行结构 | 并列成分词性、形式一致。 | He likes swimming and to run. ❌ | He likes swimming and running. ✅ | A and B 要同类 |
| 主语重心 | 决定整句核心信息，再决定改法。 | A number of authors selling books… ❌ | A number of authors sell books… ✅ | 先问“谁做了什么” |

---

【二】Mermaid 流程图：如何判断并修正 Fragment  
```mermaid
graph TD
A[看到长句] --> B{有无主语+谓语}
B -->|缺主语| C[补主语或改从句]
B -->|缺谓语| D[补谓语，注意时态]
B -->|两者都有| E{修饰语是否过长?}
E -->|是| F[用逗号隔开或改为从句]
E -->|否| G[检查平行结构/指代]
```

---

【三】易错场景快查表  

| 场景 | 学生常见写法 | 问题定位 | 一键修正 |
|---|---|---|---|
| 1. “大主语” | The man wearing a black coat and carrying an umbrella. | 整句只有主语 | The man wearing… entered the room. |
| 2. 逗号滥用 | Tokyo, which is the capital of Japan attracts tourists. | 逗号未成对 | Tokyo, which is the capital of Japan, attracts tourists. |
| 3. 非谓语当谓语 | The novel written in 1950 and exploring racial issues. | 无动词 | The novel… explores racial issues. |
| 4. 时态误用 | The parents are facing the problem. | 常态误用进行 | The parents face the problem. |
| 5. 就近指代 | …the city of Washington which holds a festival. | which应指city | …the city of Washington, which holds a festival,… |

---

【四】课后实战建议  
1. 三步自检  
   1. 划出 **S + V**（主谓）。  
   2. 若找不到，先补全；若太长，用逗号或从句断开修饰语。  
   3. 检查时态：先问“事件发生在过去/现在/将来？”，再问“是一般、进行还是完成？”  

2. 每日 5 句训练  
   找任意英文新闻，挑 5 句：  
   - 用荧光笔标出主谓。  
   - 若遇到“-ing/过去分词”开头，问自己“这是状语还是主语？”  

3. 建立“改错本”  
   把今天文稿中所有错误句抄一遍 → 右边写正确句 → 一周后回炉。  

4. 口语化记忆口诀  
   “主谓齐全是王道，逗号成双别忘掉；  
     -ing 长句要警惕，先 S 后 V 再尾巴。”  

---  
照此清单复习，可系统杜绝 Fragment、Run-on、时态混淆三大顽疾。