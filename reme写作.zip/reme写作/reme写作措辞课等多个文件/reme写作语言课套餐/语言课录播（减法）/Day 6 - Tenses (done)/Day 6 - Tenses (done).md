这份语音转文字稿是一堂关于英语时态的口语课程，主讲人通过大量例子、段子、互动问答，系统讲解了“时间（时）”和“状态（态）”必须分开理解的核心思想。下面用「知识点 + 例子 + 可视化」三种方式，把全稿内容完整梳理出来，并给出学习建议。

---

### 一、课程总纲：时态 = 时间（Tense） + 状态（Aspect）  
| 维度 | 说明                       | 常见误区               | 正确做法                       |
| ---- | -------------------------- | ---------------------- | ------------------------------ |
| 时间 | 过去 / 现在 / 未来         | 死记硬背“16种时态表”   | 先锁定时间点，再选状态         |
| 状态 | 一般、进行、完成、完成进行 | 把“时”和“态”捆在一起背 | 根据“说话人想强调什么”来选状态 |

---

### 二、时间轴 & 状态选择速查表  
用一条时间轴即可解决 90% 的时态问题。  
```mermaid
timeline
    title 时间轴与动词形式
    过去 : 时间点固定 → did / was / had done
    现在 : 事实/习惯 → do / does / have done
    未来 : 预期/条件 → will do / will be doing / be going to
```

---

### 三、高频时间状语 → 对应动词形式  
| 时间状语       | 举例                           | 动词形式                    | 例句                                                          |
| -------------- | ------------------------------ | --------------------------- | ------------------------------------------------------------- |
| 具体过去点     | yesterday, in 1995, 3 days ago | did / was                   | I met her yesterday.                                          |
| by + 过去点    | by 1995, by the time he came   | had done                    | By 1995, sales **had peaked**.                                |
| since + 过去点 | since 2010                     | have done / have been doing | I **have lived** here since 2010.                             |
| for + 时段     | for 3 years                    | 同上                        | She **has studied** French for 3 years.                       |
| ever / never   | —                              | have done                   | Have you **ever** eaten sushi?                                |
| as of / until  | as of 2003                     | had not done                | The rocket **had not yet proven** its reliability as of 2003. |

---

### 四、状态（Aspect）深度解析  
#### 1. 一般（Simple）  
- 用途：陈述事实、习惯、一次性动作  
- 例：Water **boils** at 100 °C.（客观事实）  
- 例：She **left** the building long ago.（一次性动作）

#### 2. 进行（Continuous / Progressive）  
- 用途：强调“正在发生”或“背景动作”  
- 例：As we **were talking**, he **was typing**.  
- 雅思陷阱：大作文主语抽象，很少用进行态（× The graph **is showing**...）

#### 3. 完成（Perfect）  
- 用途：连接“过去动作”与“现在结果/持续”  
- 例：I **have lost** my keys.（结果：现在找不到）  
- 例：I **have lived** here for 10 years.（持续到现在）

#### 4. 完成进行（Perfect Continuous）  
- 用途：强调“从过去到现在一直持续”  
- 例：He **has been working** here since graduation.

---

### 五、易混淆对比例  
| 对比句                                       | 含义差异         | 场景举例                                             |
| -------------------------------------------- | ---------------- | ---------------------------------------------------- |
| I **have left** the building.                | 刚走，还能回去   | A: Can you grab my phone? B: Sure, I’ve just left.   |
| I **left** the building.                     | 走了很久，回不去 | A: Can you grab my phone? B: Sorry, I left long ago. |
| I **will do** my homework after class.       | 一次性动作       | 下课后马上去做                                       |
| I **will be doing** my homework every night. | 长期习惯         | 从今往后每晚都做                                     |

---

### 六、主被动 vs 时态  
| 维度     | 关键标记           | 示例                              |
| -------- | ------------------ | --------------------------------- |
| 被动语态 | be + Vpp           | The window **was broken** by Tom. |
| 完成时   | have/has/had + Vpp | Tom **has broken** the window.    |
- 课程段子：  
  - Ball **rapes** a gorilla.（主动）  
  - Ball **is raped by** a gorilla.（被动）  
  - Ball **has been raped by** a gorilla for three years.（完成被动）

---

### 七、雅思写作中的时态策略  
| 题型             | 默认时间     | 常见时态                | 注意点                 |
| ---------------- | ------------ | ----------------------- | ---------------------- |
| 大作文（议论文） | 现在         | 一般现在时              | 少用现在进行           |
| 小作文（图表）   | 图表给定时间 | 一般过去时 / 现在完成时 | 动态图用完成时突出趋势 |
| 举例段           | 过去事件     | 一般过去时              | 不要混到现在           |

---

### 八、学习建议  
1. 建立「时间轴」思维：先问“动作发生在哪个时间点？”  
2. 用“时间状语→动词形式”速查表做题，见上表。  
3. 刻意练习易混句型：  
   - 把 have/had done, did, was doing, will do, will be doing 各写 5 句。  
4. 推荐材料：  
   - 《Understanding and Using English Grammar》by Betty Azar（课程提到的 Betty 书）  
   - 剑桥雅思真题小作文范文（观察图表描述中的时态变化）  
5. 每日 5 分钟口头操练：  
   - 自问自答：What did I do yesterday? What have I done today? What will I be doing tomorrow?

---

### 九、一句话总结  
“时态”不是 16 张表，而是“时间”+“状态”两条独立维度——先锁定时间，再按“情景需要”选状态。