以下内容按照“知识点 → 解释 → 例子/口诀/可视化”三位一体的结构，把 2 万余字的 raw transcript 整理成一份可检索、可复习、可教学的系统笔记。  
建议：先通读，再按需要跳转；考前 10 分钟可直接看“口袋版”。

---

## 1. 从句总览（Noun / Adjective / Adverbial Clause）

| 名称（中）   | 名称（英）                  | 功能                        | 在句中位置             | 例子                                       | 判断口诀                                 |
| ------------ | --------------------------- | --------------------------- | ---------------------- | ------------------------------------------ | ---------------------------------------- |
| 名词性从句   | Noun Clause                 | 当名词用（主/宾/表/同位语） | 名词能待的位置它都能待 | I think **that you are right**.            | 问“这坨东西能不能换成 it / this？”       |
| 形容词性从句 | Adjective Clause (定语从句) | 当形容词用，修饰名词        | 紧跟先行词             | The movie **that is in 3D** is boring.     | 问“能不能换成一个形容词？”               |
| 副词性从句   | Adverbial Clause            | 当副词用，修饰动词/整句     | 句首或句末，逗号隔开   | **While Daniel was walking**, he whistled. | 问“能不能换成 suddenly / because of …？” |

> 课程原话：  
> “外国人眼里只有三种从句：noun / adjective / adverb，没有‘定语’这种中文黑话。”

---

## 2. 定语从句的「that」vs「which」

| 对比维度       | that                                          | which                                                |
| -------------- | --------------------------------------------- | ---------------------------------------------------- |
| 是否加逗号     | 不加                                          | 可加（非限制）                                       |
| 信息是否必须   | 必须（限制性）                                | 可有可无（非限制）                                   |
| 先行词是否含糊 | 可以含糊                                      | 必须具体                                             |
| 例句           | The book **that is popular** is on the table. | Harry Potter, **which is popular**, is on the table. |

> 课程原话：  
> “如果删掉从句别人就找不到是哪一本书，用 that；删掉也没事，用 which。”

---

### 2.1 介词 + which 的万能逻辑

| 先行词 | 介词         | 等价副词 | 例句                                     |
| ------ | ------------ | -------- | ---------------------------------------- |
| place  | in which     | where    | the building **in which we study**       |
| time   | during which | when     | the summer **during which we had fun**   |
| reason | for which    | why      | the reason **for which he left**         |
| means  | with which   | how      | the knife **with which he cut the rope** |

口诀：  
**“介词看先行词，先行词看出语义；绝不死记硬背。”**

---

## 3. 同位语 & 逗号成双对

- 同位语 = 用另一个名词解释前面的名词  
  a fish, **a human-like creature**, processes information  
- 如果同位语前后出现逗号，必须成对出现，不能落单。

---

## 4. 修饰语错位（Misplaced Modifier）

一句话的 adverb / prepositional phrase 放错地方，会产生荒唐歧义。

| 错误示范                                         | 歧义                             | 修正                                                                  |
| ------------------------------------------------ | -------------------------------- | --------------------------------------------------------------------- |
| She only said she loved him.                     | 是“只说、没干别的”还是“只爱他”？ | Only **she** said … / She said she loved **only him**.                |
| Please don’t touch the door **for your safety**. | 门=安全门？                      | **For your safety**, please don’t touch the door.                     |
| When met a guy **in Beijing**.                   | 是在北京撩？还是撩了北京小哥？   | When I met **a guy from Beijing** / When **in Beijing**, I met a guy. |

可视化（Mermaid）：

```mermaid
flowchart LR
    A[修饰语] --> B[靠近被修饰词]
    A --"远离"--> C[产生歧义]
    style C fill:#ffcccc
```

---

## 5. 平行结构（Parallelism）

| 错误                                                                   | 修正                                                 | 技巧                           |
| ---------------------------------------------------------------------- | ---------------------------------------------------- | ------------------------------ |
| The cost of maintenance is as much as **the initial plastic surgery**. | …as much as **that of the initial plastic surgery**. | 用 that/those 代指前面同类名词 |
| She likes **to swim, jogging and to ride**.                            | She likes **to swim, jog and ride**.                 | 并列成分词性/结构一致          |

---

## 6. 写作评分 TR 6 → 7 的跳板

以 transcript 中 Emma 的段落为例：

> “The high cost … will increase the economic burden on individuals or families.”

问题 & 建议：

| 问题     | 具体表现                                                  | 升级方案                             |
| -------- | --------------------------------------------------------- | ------------------------------------ |
| 逻辑跳跃 | 未解释“为什么维护比初手术贵”                              | 补细节：医生按小时计费、修复手术更贵 |
| 句式单调 | 连续 3 句 “is/are” 开头                                   | 使用让步、倒装、分词                 |
| 词汇普通 | expensive → exorbitant / prohibitive                      |
| 指代不清 | the cost of maintenance … **that of** the initial surgery |

口袋模板（可直接背）：

> Not only does the **initial** procedure entail **exorbitant** surgeon fees and material costs, but the **subsequent** maintenance—ranging from routine injections to corrective revisions—can **outstrip** the original bill by a factor of two or three, **bankrupting** middle-class households and **plunging** teenagers who lack independent income into debt.

---

## 7. 考前 10 分钟口袋版

1. 三种从句：名词/形容词/副词  
2. that vs which：信息必须=that，可有可无=which  
3. in/on/during which = where/when/how，看先行词  
4. 修饰语“就近原则”，歧义必改  
5. 平行结构：and 前后词性对称，that/those 补全比较对象  
6. 写作 TR 提分：补细节 + 换高级词 + 句式多变

---

## 8. 后续学习建议

| 任务                                       | 资源                 | 时长   |
| ------------------------------------------ | -------------------- | ------ |
| 刷 10 道 that/which 改错                   | 剑桥雅思语法 Unit 12 | 20 min |
| 写 1 段 80 字小作文，刻意用 3 个介词+which | 自查平行 & 修饰语    | 15 min |
| 回听原音频 1.25x                           | 标记粗口→语法点      | 10 min |

> 最后一句原文：  
> “以后你们最好听外国人解释，不要他妈的听‘定语’这种鬼话。”