# GRA语法体系完整梳理 - Day 0 Overview

## 📊 语法体系总览图

```mermaid
graph TD
    A[GRA语法体系] --> B[高频工具]
    A --> C[次高频工具]
    A --> D[外围工具]
    
    B --> B1[LP - 逻辑主语]
    B --> B2[Fragment - 句子片段]
    B --> B3[Run-on - 连写句]
    B --> B4[主谓一致]
    
    C --> C1[平行呼应]
    C --> C2[指代错误]
    C --> C3[时态错误]
    C --> C4[动作发出者]
    C --> C5[修饰与逻辑]
    
    D --> D1[虚拟语气]
    D --> D2[独立主格]
    D --> D3[倒装句]
    D --> D4[固定搭配]
    
    style B fill:#ff9999,stroke:#ff6666
    style C fill:#ffcc99,stroke:#ff9966
    style D fill:#ccffcc,stroke:#99cc99
```

## 🎯 权重分层体系

| 层级 | 重要性 | 特征 | 学习策略 |
|------|--------|------|----------|
| **高频工具** | 🔴 极高 | 考试频率高，学生常犯错误 | 必须掌握 |
| **次高频工具** | 🟡 中等 | 影响句子逻辑和清晰度 | 重点掌握 |
| **外围工具** | 🟢 较低 | 使用频率低，不影响基本沟通 | 了解即可 |

## 📋 高频工具详解

### 1. LP (Logical Predication) - 逻辑主语
**定义**: 句子中动作或状态的逻辑主体不明确或错误

**错误示例**:
- ❌ "Walking down the street, the trees were beautiful."
- ✅ "Walking down the street, I saw beautiful trees."

**影响**: 直接影响读者理解句子的主体是谁

### 2. Fragment - 句子片段
**定义**: 不完整的句子，缺少主语或谓语

**错误示例**:
- ❌ "Because I was tired."
- ✅ "I went home because I was tired."

**影响**: 导致句子不完整，影响communication

### 3. Run-on - 连写句
**定义**: 两个独立句子错误地用逗号连接或没有连接词

**错误示例**:
- ❌ "I love writing, it helps me express myself."
- ✅ "I love writing, and it helps me express myself."

**影响**: 造成句子结构混乱，主语指代不清

### 4. 主谓一致 (Subject-Verb Agreement)
**定义**: 主语和谓语在数上不一致

**错误示例**:
- ❌ "The list of items are long."
- ✅ "The list of items is long."

## 🔄 次高频工具详解

### 1. 平行呼应 (Parallel Structure)
**定义**: 并列结构中的语法形式要保持一致

**正确示例**:
- ✅ "I enjoy reading, writing, and speaking English."
- ❌ "I enjoy reading, to write, and speaking English."

**影响**: 影响句子逻辑性和专业性

### 2. 指代错误 (Pronoun Reference)
**定义**: 代词指代不清或错误

**错误示例**:
- ❌ "John told Mike that he failed the test." (he指代不明)
- ✅ "John told Mike, 'You failed the test.'"

### 3. 时态错误 (Tense Issues)
**关键概念**: 时与态的分离学习

**时态对比表**:

| 时态形式 | 使用场景 | 示例 | 含义区别 |
|----------|----------|------|----------|
| will do | 一次性动作 | "I will study tomorrow." | 明天会学习 |
| will be doing | 习惯性动作 | "I will be studying every day." | 未来每天的习惯 |

**实用技巧**:
- Task 2写作中主要使用一般现在时
- 描述过去事件时使用一般过去时
- 避免复杂的时态变化

### 4. 动作发出者 (Action Actor)
**定义**: 确定动作的发出者是主动还是被动

**对比示例**:
- ✅ "The policy was implemented by the government." (被动)
- ✅ "The government implemented the policy." (主动)

### 5. 修饰与逻辑 (Modification & Logic)
**定义**: 修饰语的位置和逻辑关系要清晰

**错误示例**:
- ❌ "Running quickly, the finish line appeared."
- ✅ "Running quickly, I saw the finish line."

## 🌟 外围工具说明

### 需要了解的工具

| 工具 | 重要性 | 使用建议 |
|------|--------|----------|
| 虚拟语气 | 🟡 中等 | 了解基本用法即可 |
| 独立主格 | 🟡 中等 | 掌握基本结构 |
| 倒装句 | 🟢 低 | 无需刻意使用 |
| 固定搭配 | 🔴 高 | 需要记忆，但优先级低于高频工具 |

### 虚拟语气基本用法
**结构**: If + 主语 + were/过去式，主语 + would/could + 动词原形

**示例**:
- "If I were you, I would study harder."

### 独立主格基本结构
**结构**: 名词 + 分词短语

**示例**:
- "The weather being fine, we decided to go out."

## 🎯 学习优先级矩阵

```mermaid
graph LR
    A[学习优先级] --> B[立即掌握]
    A --> C[逐步提升]
    A --> D[了解即可]
    
    B --> B1[LP]
    B --> B2[Fragment]
    B --> B3[Run-on]
    B --> B4[主谓一致]
    
    C --> C1[平行呼应]
    C --> C2[指代清晰]
    C --> C3[动词形式]
    
    D --> D1[虚拟语气]
    D --> D2[独立主格]
    D --> D3[复杂时态]
```

## 📈 实用检查清单

### 写作前检查
- [ ] 每个句子都有明确的主语和谓语
- [ ] 检查主谓是否一致
- [ ] 确认没有句子片段
- [ ] 检查没有连写句
- [ ] 确保代词指代清晰

### 写作后检查
- [ ] 平行结构是否一致
- [ ] 动词时态是否正确
- [ ] 修饰语位置是否合理
- [ ] 动作发出者是否明确

## 💡 核心学习建议

### 1. 优先级策略
**不要追求完美语法，而要追求清晰表达**
- 重点掌握高频工具：LP、Fragment、Run-on、主谓一致
- 次高频工具影响逻辑，需重点练习
- 外围工具了解即可，不要过度投入时间

### 2. 实用技巧
- **简化句子结构**：使用简单句确保准确性
- **主动检查**：写作后专门检查高频错误
- **语境学习**：将语法点放在具体语境中学习
- **错误分类**：建立自己的常见错误清单

### 3. 练习方法
- 每天专注练习一个高频工具
- 写句子时先确保结构完整，再考虑复杂性
- 用简单句表达复杂思想，避免炫技
- 重点练习动词形式的正确使用

### 4. 考试策略
- **Task 2**：重点使用一般现在时，避免复杂时态
- **检查时间**：预留2-3分钟专门检查语法错误
- **错误优先级**：优先修正影响理解的高频错误

## 🎯 一句话总结

> 掌握高频工具确保基础正确，理解次高频工具提升表达逻辑，外围工具了解即可——**清晰永远比复杂更重要**。