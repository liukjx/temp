课程名称：Day 7——Problem-Solution Essay 进阶写作  
主题：大城市扩张带来的社会问题之「卖淫合法化 vs. 刑事化」

一、总体结构速览
| 模块          | 关键信息                                               | 课堂举例                                 |
| ------------- | ------------------------------------------------------ | ---------------------------------------- |
| 开场          | 需提前下课；学生作文提交不足                           | “did you guys write some of the essays?” |
| 写作原则      | 三个黄金标准：effective、efficient、no adverse effects | 水草治理：投放草鱼（有效+无二次污染）    |
| Problem 讨论  | 大城市扩张→crime↑→prostitution↑                        | 香港 70-80s、台湾 90s、Gotham City       |
| Solution 讨论 | 合法化(legalization)+监管(regulation)                  | 澳大利亚、加拿大、日本红灯区             |
| 语言技巧      | 抽象→具象；负面情感动词                                | “sky-rocketing / insane growth”          |

二、Problem-Solution Essay 知识点系统梳理
1. 选题原则（如何锁定 1 个 problem）
   - 不清单式罗列，只深挖 1 个最有深度的点  
   - 必须和 city growth 直接因果（否则 TR 直接 5 分）  
   - 推荐角度：prostitution / wealth gap / crime / social stratification

2. Solution 的 4 级评估表
| 维度              | 解释            | 课堂例子                  |
| ----------------- | --------------- | ------------------------- |
| Plausible         | 现实可行        | 政府财政、法律允许        |
| Effective         | 解决 root cause | 合法化→削弱黑帮 & 人贩子  |
| Efficient         | 成本低 & 见效快 | 用税收监管替代大规模扫黄  |
| No adverse effect | 无副作用        | 性工作者定期体检→减少 STD |

3. 段落写作公式（可直接套模板）
   1) Hook → Thesis (1 句)  
   2) Cause 1 → Cause 2 (递进逻辑)  
   3) Solution → Why better (对比 criminalization)  
   4) Evaluation (短期 & 长期效果)  
   5) Conclusion (呼吁合法化 + 展望)

4. 抽象→具象化示范
   抽象词 → 具象化表达  
   “crime increases” → “In Gotham City, police response time lags 15 min behind emergency calls.”  
   “legalization protects” → “Licensed brothels install panic buttons & CCTV; bouncers evict violent clients.”

5. 高频地道表达
   - sky-rocketing/insane/exponential growth  
   - sweep … under the rug（掩盖问题）  
   - root cause ≠ symptom  
   - crack down on illegal brothels  
   - regulate & tax the industry

三、Mermaid 流程图：从 City Growth 到 Solution
```mermaid
graph TD
A[City Rapid Growth] --> B[Wealth Gap Widens]
B --> C[Underground Demand for Sex Work ↑]
C --> D[Human Traffickers + Drugs Supply]
D --> E[Unregulated Prostitution]
E --> F[STD Spread & Violence]
E --> G[Police Resources Overstretched]

H[Legalization + Regulation] --> I[Licensed Brothels]
I --> J[Mandatory Health Checks]
I --> K[Security/Bouncers]
I --> L[Tax Revenue → Public Health]
H -.-> M[Crack Down on Illegal Rings]

F & G --> N[Social Harm]
J & K & L --> O[Reduced Harm & Protected Workers]
```

四、课堂延伸任务
| 任务                                           | 资源                 | 目的                                          |
| ---------------------------------------------- | -------------------- | --------------------------------------------- |
| 观看 TED Talk《What sex workers want》         | 澳大利亚性工作者独白 | 获取一手词汇 & 情感角度                       |
| 观看 Asian Boss《Korean sex worker interview》 | 亚洲语境案例         | 对比东西方差异                                |
| 写作练习                                       | 250–300 词           | 运用上述模板完成一篇 legalization 的 solution |

五、教师建议
1. 先写 body 再补开头：开头只需一句 “Among the myriad issues fuelled by urban sprawl, prostitution stands out as the most socially corrosive.”  
2. 数据不足时——用电影/纪录片作“软证据”：  
   “As depicted in *Batman Begins*, Gotham’s crime surge mirrors real-world statistics from 1970s Hong Kong.”  
3. 结尾拔高：把 legalization 放到联合国 SDG 5（Gender Equality）框架，提升格局。