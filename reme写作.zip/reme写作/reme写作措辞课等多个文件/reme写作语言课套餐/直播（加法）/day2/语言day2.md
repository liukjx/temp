## 📚 课程知识点系统梳理

### 一、语言升级核心思路：从“讲事”到“讲理”再到“事理结合”

| 阶段 | 目标 | 示例对比 |
|------|------|----------|
| 1. 讲事 | 以人为主，描述动作 | "Students can learn how to communicate with others through daily interaction." |
| 2. 讲理 | 抽象概念作主语，逻辑推导 | "Communication skills can be developed through daily interactions with people of diverse temperaments." |
| 3. 事理结合 | 抽象推导 + 具体例子 | "Schools, as miniature societies, provide optimal settings for such interactions through varied subjects and peer discussions." |

---

### 二、逻辑连接与语言习惯

#### 1. 逻辑连接词的正确使用
| 常见错误 | 原因 | 正确用法示例 |
|----------|------|--------------|
| `except for academic knowledge` | 暗示“学术知识不重要” | `besides/apart from academic knowledge` |
| `and get prepared` | 主语缺失，逻辑断裂 | `and thus prepare them for...` |
| `a great opportunity` | 抽象笼统，缺具体信息 | `a great opportunity to develop social skills` |

#### 2. 避免逻辑鸿沟
- **问题**：直接跳到细节（如“学生如何交流”），未解释“为何学校是最佳平台”。
- **解决方案**：  
  1. 先抽象定义（学校=微型社会）  
  2. 再具象化（课程、同龄人互动）  

---

### 三、抽象概念主语替换法

| 人作主语（低阶） | 抽象概念作主语（高阶） |
|------------------|------------------------|
| Students learn social skills. | Social skills are cultivated through... |
| Teachers guide students. | Guidance from educators ensures... |
| Schools help students. | The school environment fosters... |

---

### 四、语法与词汇升级点

#### 1. 词汇替换
| 普通词 | 升级词 |
|--------|--------|
| `important` | `essential/pivotal` |
| `school is like a small society` | `school functions as a miniature society` |
| `different people` | `individuals from diverse backgrounds` |

#### 2. 语法修正
- **主谓一致**：  
  `full time education take place` → `full time education takes place`  
- **平行结构**：  
  `develop social skills and be prepared` → `develop social skills and prepare them for...`

---

### 五、写作流程优化（Mermaid流程图）

```mermaid
graph TD
A[题目要求] --> B[确定核心观点]
B --> C{是否偏离主题?}
C -->|是| D[修正逻辑链]
C -->|否| E[抽象概念作主语]
E --> F[添加具象化细节]
F --> G[检查逻辑连接词]
G --> H[最终检查语法/词汇]
```

---

### 六、实战建议与练习

#### 1. 每日训练任务
| 任务 | 示例 |
|------|------|
| **抽象化一句话** | 将“Students practice teamwork in school”改为“Teamwork capabilities are honed through collaborative school projects.” |
| **修复逻辑鸿沟** | 原文：`School is good. Students learn skills.` → 升级：`Schools provide structured environments where interpersonal skills are systematically developed.` |

#### 2. 自查清单
- [ ] 是否每段首句明确“理”而非“事”？
- [ ] 是否用抽象概念（如interaction, skill development）作主语？
- [ ] 是否避免了“人-动作”的直白表达？
- [ ] 逻辑连接词（therefore, as a result）是否准确？

---

### 七、评分标准对应（雅思写作）
| 维度 | 6.5分表现 | 7.5分升级策略 |
|------|-----------|---------------|
| **TR（任务回应）** | 有观点但逻辑松散 | 用抽象概念强化因果链 |
| **CC（连贯衔接）** | 用“and/so”连接句子 | 用分号/副词（therefore）替代 |
| **LR（词汇）** | 普通词+少量大词 | 精准抽象词（miniature society, optimal platform） |
| **GRA（语法）** | 简单句为主 | 非人主语+被动语态（skills are developed） |

---

通过以上系统梳理，学员可逐步将6.5分作文升级为7.5分，关键在于：**用抽象概念主导逻辑，用细节补充论证，用连接词缝合逻辑鸿沟**。