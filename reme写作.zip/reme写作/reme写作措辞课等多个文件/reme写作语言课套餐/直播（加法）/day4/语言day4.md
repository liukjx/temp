# 📑 课程知识系统梳理  
> 来源：语言 day4 语音转文字稿  
> 适用：雅思写作 Task-2（议论文）  
> 核心：从“学生作文 → 教师逐句讲评 → 提炼通用写作原则”

---

## 1. 高频失分点速查表
| 失分点 | 学生常见错误 | 正确做法/示例 | 备注 |
|---|---|---|---|
| **Phrasing Issue** | technology has been transforming | in retrospect, people realize **how transformative** technology has been | 用形容词表达评价 |
| **词性混用** | government expenditure grant for… | government **spending should be allocated to** … | expenditure 后接 on；grant 多为主动 |
| **逻辑断层** | 一整段只下定义，未回应题干 | 把定义弱化为从句，主句直接回答题目 | 见“强化-弱化”技巧 |
| **Run-on 句** | …ability, **in that** children need… | …ability **by having** children respond… | 避免逗号拼接两个完整句 |
| **上位词陷阱** | traditional Games = 拔河、陀螺 | 聚焦 **traits**（physically demanding）而非举例 | 防止以名词代替特征 |
| **主次颠倒** | 重点信息被塞进非限定从句 | 用 **that** 限定重要信息，**which** 弱化次要信息 | 见例句对比 |

---

## 2. 强化-弱化重组技巧（Re-framing）
> 目的：把“定义/背景”揉进主干，避免段落游离

### 2.1 三步流程图
```mermaid
flowchart LR
A[题干关键词] --> B[先给结论/立场]
B --> C[用弱化从句/同位语嵌入定义]
C --> D[立刻给出例证或因果]
```

### 2.2 示范改写
| 学生原句 | 改写后 |
|---|---|
| **Progress** can be defined as a list of development of social components… | **For a developing country whose priority is to raise green yield and accelerate industrialization**, progress is measured by its capacity to apply cutting-edge farming technology—something that science education directly enables. |

---

## 3. 评分标准映射表
| 雅思带分 | 语言层面 | 逻辑层面 | 示范金句 |
|---|---|---|---|
| 6.0-6.5 | 语法基本正确，仍有中式搭配 | 段落功能清晰，但信息割裂 | Government spending should not only grant for science education… |
| 7.0 | 搭配地道，标点正确 | 每段 Topic Sentence 直接回应题干 | Government spending should not be **solely allocated to** education in science; **while** it is **instrumental**, it is **not the sole determinant** of national development. |
| 7.5+ | 精准词汇+灵活句式 | 全文“论点-解释-例证”环环相扣 | In retrospect, we realize how transformative technology has been; yet **it is the synergy among science, arts and physical education** that cultivates a generation capable of **strategically planning and executing** national visions. |

---

## 4. 今日作业 & 实操建议
| 任务 | 要求 | 工具/资源 |
|---|---|---|
| 重写「政府投资科学教育」一题 | 用“强化-弱化”技巧把定义揉进论证 | 朗文/牛津搭配词典核查动词+介词 |
| 新建「Technology 主题词汇表」 | 收集 **prosperity, sector, determinant, allocate** 等词的地道搭配 | 语料库：YouGlish / COCA |
| 自查清单 | ①有无 run-on 句 ②是否头段直接回应 ③是否把次要信息放进从句 | Grammarly + 朗读法 |

---

## 5. 一页速用模板
> 适合 6.5 保底，可再升级  
**开头段**  
Some people argue that … . While I agree that … is important, I believe it should not be the sole focus because … .

**主体段 Topic Sentence**  
① For countries whose immediate priority is …, investment in … proves indispensable **in that** …  
② What also matters is …, **without which** …

**结尾段**  
Therefore, a balanced allocation that integrates …, rather than privileging any single area, is more likely to …

---

### 🎯 今日金句
> “Don’t define first; argue first, then weave the definition into your argument.”