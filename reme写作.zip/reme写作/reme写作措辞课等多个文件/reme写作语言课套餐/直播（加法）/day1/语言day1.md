# 语言 Day1 课程系统整理

---

## 一、课程目标与结构

| 阶段 | 目标 | 方法 | 输出要求 |
|------|------|------|----------|
| 第1天 | 用英文**具象化**教育类题目，写出6.5分文章 | 以人/事件/物品为起点讲故事 | 控制思想（controlling idea）+ 具象化段落 |
| 第2天 | 把具象化段落**抽象化升级**到7.5+ | 提炼上位词，用抽象概念串全文 | 抽象化论点 + 高分句型 |

---

## 二、核心知识点

### 1. Controlling Idea（控制思想）
- **定义**：一句话回答题目，点明全文主旨。
- **写法**：  
  - 主语必须是**题目关键词**（如 full-time education），而非“people/they”。  
  - 用动词连接“结果/影响”。

| ❌错误示例 | ✅正确示例 |
|-----------|-----------|
| Young people who study until 18 will gain skills. | Full-time education until 18 ensures that young people master the skills to thrive in modern society. |

---

### 2. 具象化逻辑链（4 步循环）
```mermaid
graph TD
    A[事件/教育] --> B[使人做某事]
    B --> C[得到技能/结果]
    C --> D[满足社会需求]
    D --> A
```

- **例**：  
  Full-time education → students learn critical thinking → solve workplace problems → meet employer demands.

---

### 3. 技能分类与上位词

| 技能类型 | 下位例子 | 上位词 |
|----------|----------|--------|
| Academic knowledge | math, physics, IT | foundational knowledge |
| Soft skills | teamwork, leadership, communication | interpersonal skills |
| Core skills | critical thinking, problem-solving | cognitive skills |
| Language skills | reading, writing, listening | literacy skills |

---

### 4. 具象化写法模板

| 步骤 | 模板 | 示例 |
|------|------|------|
| 1. 控制思想 | Full-time education until 18… | …ensures that students acquire enough skills to be competent in modern society. |
| 2. 解释“competent” | Being competent means… | …the skills can be applied at work and meet employer demands. |
| 3. 具象化技能 | Full-time education helps students master… | …critical thinking and problem-solving, both of which are necessary for career success. |
| 4. 情景化动作 | Once they step into the workplace… | …they identify problems → analyze data → see patterns → create solutions. |
| 5. 反证强化 | Without such education… | …they would lack the skills to survive in the workplace. |

---

### 5. 高分 vs 低分区别

| 维度 | 6-6.5 具象化段 | 7.5+ 抽象化段 |
|------|----------------|----------------|
| 主语 | 具体人/事 | 抽象概念 |
| 动词 | ensure, help, allow | guarantee, cultivate, foster |
| 连接 | because, once | given that, in view of |
| 例子 | 无具体人名 | 完全说理，无故事 |

---

## 三、课堂练习示范

### 题目
Some people think all young people should study full-time until 18. To what extent do you agree?

### 6.5 示范段（具象化）
> Full-time education until students are at least eighteen ensures that they acquire adequate skills to compete in the modern labor market. Being competitive means that the critical-thinking and problem-solving abilities they develop at school can be directly transferred to the workplace. Because once these adolescents enter their first jobs, they will need to break down complex tasks, analyze information and generate practical solutions. Without such prolonged schooling, they would struggle to meet even the basic entry requirements of most employers.

---

## 四、作业与下一步

| 任务 | 要求 | 提示 |
|------|------|------|
| Homework | 写 1 段 advantage + 1 段 disadvantage | 每段 4-5 句，使用“控制思想→技能→情景→反证”结构 |
| 明天 | 把今天段落改写成 7.5 抽象版 | 用抽象名词作主语，减少“people/students” |

---

## 五、易错提醒

| 错误点 | 正确做法 |
|--------|----------|
| 用 “they/people” 开头 | 用题目关键词作主语 |
| such as 直接接动词 | such as + 名词列举 |
| for example 不具体 | 给出数据/品牌/量化细节 |
| basically/at least 滥用 | 只保留必要的“at least eighteen” |

---

## 六、快速检查清单（写作前自查）

- [ ] 控制思想是否以“full-time education until 18”开头？  
- [ ] 是否出现具体人名或故事？（6.5 可接受，7.5 要去掉）  
- [ ] 每句主语是否与前句逻辑一致？  
- [ ] 是否用“because/once/without”完成因果链？  
- [ ] 有无至少 1 个上位词（skills, competence, demands）？

---

祝写作顺利！