# 雅思写作 Day 6 课程系统性总结  
（根据语音转文字稿提炼知识点 + 示例 + 建议）

---

## 1. 题目解读与结构规划
| 知识点          | 解释 & 示例                                                                                                                               | 建议                                                                           |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------ |
| **“四问”陷阱”** | 题干：in many countries … give reasons and make some suggestions。表面 2 问，实则隐含 4 个任务：①原因 ②对个人的问题 ③对社会的问题 ④建议。 | 先用 1 分钟拆分任务，再决定段落。若时间紧，把原因+建议合并为一段。             |
| **9 分结构**    | 4 问 → 5~6 段：<br>Intro – Cause – Indiv. problems – Soc. problems – Solutions – Conclusion。                                             | 考场优先 4 段：Intro – Cause – Problems (Indiv.+Soc.) – Solutions+Conclusion。 |

---

## 2. 中文逻辑 → 英文表达流程图
```mermaid
flowchart LR
A[中文逻辑混乱] -->|Step1| B[理清因果链]
B -->|Step2| C[抽象核心概念]
C -->|Step3| D[英文主语+动词+修饰]
D -->|Step4| E[删减冗余/具象化]
```

| 步骤  | 操作要点           | 示例                                                                            |
| ----- | ------------------ | ------------------------------------------------------------------------------- |
| Step1 | 用“因为…所以…”口述 | 因为培训应届生太贵，所以公司偏爱熟练工。                                        |
| Step2 | 提炼名词化主语     | “培训成本”→ the cost of training                                                |
| Step3 | 主谓宾+限定        | The cost of training new recruits deters companies from hiring fresh graduates. |
| Step4 | 删除冗余/具象化    | 删除 “apparently enough”, 改为 “it is costly…”                                  |

---

## 3. 常见错误类型对照表
| 错误类型   | 原句（Chinglish）                    | 修正                                       | 备注                   |
| ---------- | ------------------------------------ | ------------------------------------------ | ---------------------- |
| 主语重心错 | Companies prefer...                  | The preference among companies for...      | 用名词化主语提升抽象度 |
| 冗余副词   | apparently enough                    | 删除                                       | enough 已含“足够”      |
| 形容词堆砌 | low educational specialized worker   | skilled workers with vocational training   | 用精准名词代替         |
| 逻辑断层   | 直接跳到下一点                       | 加衔接 “As a result / This leads to...”    | 防止清单式写作         |
| 指代歧义   | they and their parents who… believe… | students and their parents, who…, believe… | 用逗号隔开非限定       |

---

## 4. 词汇-句型升级清单
| 普通表达                     | 升级表达                                    | 语境      |
| ---------------------------- | ------------------------------------------- | --------- |
| choose                       | recruit / take on / opt for                 | 招聘语境  |
| nowadays                     | in the current labour market                | 更具体    |
| cost a lot                   | it is costly / a heavy financial burden     | 名词化    |
| mismatch                     | the skills gap between…                     | 学术化    |
| young people can’t find jobs | the prevalence of youth unemployment ensues | 因果+正式 |

---

## 5. 课程示范段落（可直接背诵骨架）
> **Introduction**  
> Across industrialised nations, a growing proportion of school-leavers are failing to secure employment immediately after graduation. This essay will first explore the underlying causes of this phenomenon and then examine the repercussions for both individuals and society, before proposing feasible remedies.

> **Cause**  
> The root cause lies in **the preference that employers have for vocationally-trained labour over fresh graduates**. Having conducted a cost-efficiency analysis, firms find it more rational to hire **skilled workers who can be productive from day one** than to invest **scarce resources in training newcomers with purely theoretical knowledge**.

> **Problem for individuals**  
> Young adults who experience prolonged joblessness often suffer from **eroded self-esteem** and **skills depreciation**, which may trap them in a vicious cycle of under-employment.

> **Problem for society**  
> On a societal level, high youth unemployment translates into **lost productivity**, **increased welfare expenditure** and, in extreme cases, **social unrest**.

> **Solutions**  
> To bridge the gap, governments should **subsidise apprenticeship schemes** while universities embed **mandatory internships** in curricula, ensuring that graduates possess **market-relevant competencies**.

---

## 6. 课后自检 3-步曲
| 检查项   | 操作                                  | 工具                        |
| -------- | ------------------------------------- | --------------------------- |
| 逻辑链   | 用箭头图把“原因→问题→影响→方案”串起来 | 手绘 or XMind               |
| 语言     | 朗读→删除口语/冗余词                  | Grammarly & On Writing Well |
| 主语重心 | 每段首句必须是抽象名词                | 高亮检查                    |

---

## 7. 下周任务
1. 用以上骨架独立完整写 250 词。  
2. 录音 2 分钟口头因果链，训练逻辑口语化。  
3. 收集 5 篇外媒社论，摘录名词化主语句 10 句。  

> 坚持“先中文逻辑 → 英文抽象化 → 删减冗余”三步，写作 7.5 不再玄学。