# 女权主义 IELTS 写作主题课程总结  
> 适用：雅思大作文（Task-2）  
> 主题：University should accept equal numbers of male and female students in every subject. To what extent do you agree or disagree?  
> 来源：语言 day9.txt 语音转写

---

## 1 整体思路速览

| 步骤       | 核心问题                 | 课堂结论                                                                                          |
| ---------- | ------------------------ | ------------------------------------------------------------------------------------------------- |
| ① 审题     | 题目到底在问什么？       | 不是问「性别平等好不好」，而是问「强行 1:1 招生是否可行、可取」。                                 |
| ② 立场     | 推荐立场？               | **Disagree（完全不同意）** 更容易写到 7+ 分。                                                     |
| ③ 逻辑链   | 三大攻击角度             | 1️⃣ 不可行（not viable）<br>2️⃣ 违背教育初衷（defeats purpose）<br>3️⃣ 带来负面效应（negative effects） |
| ④ 段落架构 | Body 1 / Body 2 / Body 3 | 任选其二写深即可，避免“清单式”罗列。                                                              |

---

## 2 三大核心知识点展开

### 2.1 知识点：可行性攻击（Not Viable）

| 子点             | 解释                      | 课堂原文示例                                                   | 可套用的英文表达                                                                                    |
| ---------------- | ------------------------- | -------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| 男女自然偏好差异 | 不同学科天然吸引不同性别  | “girls tend to choose arts, guys tend to choose STEM”          | The preference that males and females have for **subject choice** differs markedly.                 |
| 招生是双向选择   | 学校无法强制学生志愿      | “招生不是一个学校单向决定的数字游戏”                           | Admission is a **two-way selection**; universities cannot **dictate** student preferences.          |
| 绝对配额不可操作 | 精确 1:1 在统计学上不现实 | “you can’t say ‘we need exactly 15,034 girls in CS this year’” | Maintaining a rigid 1:1 ratio is **statistically impractical** and **administratively burdensome**. |

> 高分句型  
> It is simply **not viable** to enforce a 50/50 quota in every discipline, because **student self-selection** follows **natural preference curves** rather than administrative decree.

---

### 2.2 知识点：违背初衷 / 适得其反（Defeats the Purpose）

| 子点                  | 解释                       | 课堂示例                                   | 可套用的英文表达                                                                                                             |
| --------------------- | -------------------------- | ------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------- |
| 初衷：gender equality | 表面为了平等，实际扭曲选择 | “affirmative action 反噬”                  | The policy **purports** to promote gender equality, yet it **undermines meritocracy** and breeds **reverse discrimination**. |
| 剥夺学生选择权        | 强制指派专业=侵犯自由      | “students would not be entitled to choose” | Such a rule **infringes upon students’ autonomy** and **runs counter to the liberal spirit of higher education**.            |

> 高分句型  
> Ironically, the policy **defeats its own purpose**: by **prioritising gender parity over aptitude**, it **entrenches inequality** under the guise of fairness.

---

### 2.3 知识点：负面效应（Negative Effects）

| 子点         | 解释                         | 课堂示例                                                | 可套用的英文表达                                                                                                                                                |
| ------------ | ---------------------------- | ------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 人才错配     | 高分者被拒，仅因性别名额已满 | “a qualified boy loses his seat to meet the girl quota” | Qualified applicants may be **turned away solely on gender grounds**, leading to **talent misallocation**.                                                      |
| 学习动机下滑 | 被调剂到不感兴趣专业         | “强制换专业→热情下降”                                   | Being coerced into an **ill-suited major** can **erode motivation** and **impair academic performance**.                                                        |
| 职业市场错配 | 某些行业性别比例本就失衡     | “kindergarten teachers 90 % female”                     | Even if universities enforce parity, the **job market** will still **favour certain genders** in specific sectors, rendering the policy **futile in practice**. |

> 高分句型  
> In the long run, the mismatch between **graduation ratios** and **sectoral demand** will **nullify** any artificial parity achieved at university level.

---

## 3 段落示范（Body-1 模板）

```mermaid
graph TD
    A[论点：Not Viable] --> B[自然偏好差异]
    A --> C[双向选择]
    B --> D[女性偏好情感型学科]
    B --> E[男性偏好逻辑型学科]
    C --> F[学校无法强制志愿]
    F --> G[行政不可行]
```

**段落示例（Band-8 水平）**  
It is **neither feasible nor rational** to impose a strict 50:50 gender quota across all subjects. First, **student self-selection** follows **innate preference curves** rather than administrative decree. Females, on average, gravitate toward disciplines that harness **empathy and linguistic dexterity**—such as psychology or early-childhood education—whereas males tend to opt for fields requiring **systemising and spatial reasoning**, like computer science. Second, university admission is a **two-way street**: institutions cannot **commandeer** applicants into specific programmes simply to balance a spreadsheet. Consequently, any attempt to **micromanage enrolment numbers** is doomed to administrative failure and statistical absurdity.

---

## 4 写作流程图（建议步骤）

```mermaid
flowchart LR
    1[审题：抓关键词 equal numbers / every subject] --> 2[立场：Disagree 更易写]
    2 --> 3[列三大攻击点]
    3 --> 4[选两点深挖 → 每点 80-90 词]
    4 --> 5[首段：背景+立场]
    5 --> 6[主体段：论点+解释+举例+回题]
    6 --> 7[尾段：重申立场+总结理由]
    7 --> 8[通读：避免重复、升级词汇]
```

---

## 5 词汇与短语升级表

| 口语/普通词       | 学术升级词                               | 示例句                                                                    |
| ----------------- | ---------------------------------------- | ------------------------------------------------------------------------- |
| stupid policy     | **myopic and counter-productive policy** | The proposal is **myopic and counter-productive**.                        |
| can’t do it       | **is statistically unattainable**        | A 1:1 ratio **is statistically unattainable** in practice.                |
| take away choice  | **infringe upon autonomy**               | The rule **infringes upon students’ autonomy**.                           |
| make things worse | **exacerbate existing inequalities**     | Far from alleviating disparity, it **exacerbates existing inequalities**. |

---

## 6 常见误区提醒

| 误区             | 课堂提醒                              | 解决策略                                                                                 |
| ---------------- | ------------------------------------- | ---------------------------------------------------------------------------------------- |
| 写“清单”式 Body  | 容易写成 “first… second… third…”      | 每段只深挖 **一个** 论点，用 “解释-例证-回题” 三层结构                                   |
| 性别刻板印象过度 | 直接说 “girls are emotional” 会被扣分 | 用 **学术包装**：“females statistically display higher average scores on empathy scales” |
| 重复词汇         | 多次出现 “not viable”                 | 同义替换：**impractical / unworkable / statistically untenable**                         |

---

## 7 课后练习任务

1. 用 15 分钟写 **Body-1**（not viable 角度），80-90 词。  
2. 用 10 分钟写 **Body-2**（defeats purpose 或 negative effects），80-90 词。  
3. 互换批改：检查是否出现①主语重心游离②清单式罗列③词汇重复。  
4. 把全文输入 Grammarly/ChatGPT 进行可读性检查，重点优化 **句子长度多样性** 与 **连接词密度**。

---

> 最后叮嘱：这道题的 **高分关键** 在于把“强行 1:1”写成 **逻辑荒谬 + 操作不可行 + 违背教育伦理** 的三重打击，而非简单重复“性别平等很重要”。