【雅思图表作文 1 小时速成笔记】  
——基于 Day9-2 课程逐字稿的系统整理  
（用「知识点 + 例子 + 建议」方式呈现，可打印/收藏）

---

### 1. 描述“占比”的 5 种高分表达
| 表达                     | 释义                   | 例句                                                         |
| ------------------------ | ---------------------- | ------------------------------------------------------------ |
| **直接数字开头**         | 最简洁、最推荐         | 8 % **of the total population** **was / were** aged 50–55.   |
| **account for**          | 占……比例               | The 50–55 age group **accounted for** 8 % of the population. |
| **make up / constitute** | 组成                   | Females **made up** 52 % of the workforce.                   |
| **take up**              | 占用（时间/金钱/比例） | Housing **takes up** 35 % of household spending.             |
| **represent**            | 占比（学术风）         | Overweight pupils **represented** one fifth of the sample.   |

⚠️ 注意：  
- 单复数由 **of 后的名词** 决定：  
  8 % **of the waste** **is** recycled.  
  8 % **of the residents** **are** immigrants.  
- 避免 **correspond / occupy / be responsible for** 表达占比。

---

### 2. 描述“均匀 / 不均匀分布”
| 表达                        | 例句                                                                          |
| --------------------------- | ----------------------------------------------------------------------------- |
| **evenly distributed**      | The elderly population was **evenly distributed between the two genders**.    |
| **more evenly distributed** | France showed a **more even distribution across age cohorts** than India.     |
| **an even distribution**    | There **was an even distribution of males and females** in every age bracket. |

替代表达：  
- **evenly split / apportioned / shared**  
- **a roughly equal split between A and B**

---

### 3. 描述“图形形状”——让 overview 瞬间高级
| 形状     | 英文关键词                          | 示例句                                                                                       |
| -------- | ----------------------------------- | -------------------------------------------------------------------------------------------- |
| 金字塔形 | pyramid-shaped (pattern/structure)  | India’s age structure **presented a pyramid-shaped pattern** with a broad base.              |
| 纺锤形   | spindle-shaped / barrel-shaped      | The chart **was spindle-shaped**, bulging in the middle age groups.                          |
| 沙漏形   | hourglass-shaped / sandglass-shaped | The population distribution **resembled an hourglass**, slim at 30–45 and wide at both ends. |
| 倒金字塔 | inverted pyramid                    | Italy displayed an **inverted pyramid**, dominated by the elderly.                           |

---

### 4. 让句子多样化的 4 个技巧

#### 4.1 换主语（摆脱千篇一律的 “The percentage of…”）
- 原：The percentage of government spending on education **increased**.  
- 改：The government **allocated** more funds to education.  
- 改：The period 2000–2020 **witnessed** a steady rise in education expenditure.

#### 4.2 时间状语提前，避免重复
- **Over the same period**, health spending **fell** to 6 %.  
- **Between 1980 and 2000**, the budget for transport **tripled**.

#### 4.3 用分词 / 形容词短语精简信息
- **Starting at** 10 % in 1990, the figure **climbed to** 25 % by 2010.  
- **Down from** 30 %, the share **bottomed out at** 6 %.

#### 4.4 逻辑衔接词
| 功能 | 词汇                                          |
| ---- | --------------------------------------------- |
| 对比 | whereas, while, in contrast, conversely       |
| 让步 | despite, although, even though                |
| 因果 | lead to, result in, give rise to, fuel, drive |

---

### 5. 常见动词/名词替换表
| 高频词        | 替换 1      | 替换 2   | 替换 3   |
| ------------- | ----------- | -------- | -------- |
| increase (v.) | rise        | grow     | climb    |
| decrease (n.) | fall        | drop     | decline  |
| percentage    | proportion  | share    | fraction |
| money spent   | expenditure | budget   | outlay   |
| section       | sector      | category | bracket  |

---

### 6. 易错点 10 秒速查清单
| 错误                | 纠正                                      |
| ------------------- | ----------------------------------------- |
| lead to + 句子 ❌    | lead to **a sharp fall in profits** ✅     |
| sixfold decrease ❌  | **fell to one sixth / dropped by 83 %** ✅ |
| deep drop ❌         | **sharp / dramatic / precipitous drop** ✅ |
| the three quarter ❌ | **three quarters (复数)** ✅               |
| be constituted by ❌ | **was / were made up of** ✅               |

---

### 7. 流程图：写段落时的思路
```mermaid
graph TD
A[读图找特征] --> B{Overview一句话}
B --> C[选主语换句型]
C --> D[时间状语提前]
D --> E[加逻辑衔接]
E --> F[检查单位/单复数]
```

---

### 8. 实战 30 秒模板（可直接套用）
**Overview（一句）**  
Overall, the chart **presented a pyramid-shaped pattern**, and the proportion of elderly people **was markedly higher in France than in India**.

**Body（两句）**  
France **allocated 35 % of its annual budget to health and human resources**, **up from** just 20 % two decades earlier.  
**In contrast**, spending on transport **fell to 6 %**, **despite a brief recovery** in 2005.

---

### 9. 提分建议
1. **每天背 3 个形状/替换词**，写句子立刻用上。  
2. **写完后自查**：是否连续 3 句主语都是 “The percentage…”，如果是，立刻换主语。  
3. **读英文报纸**（Guardian Data section）积累真实数据表达。  
4. **考前 3 天**：把本笔记打印，放在桌边当“小抄”，保证上考场能条件反射。

祝你考场 7+！