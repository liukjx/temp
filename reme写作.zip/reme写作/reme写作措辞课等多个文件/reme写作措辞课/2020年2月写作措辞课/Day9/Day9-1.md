以下内容将本次雅思小作文课程录音转写稿中的全部语言点与写作技巧，按照「任务类型 → 段落 → 知识点 → 例句 / 建议」四层级进行系统梳理。  
如无特别说明，均以雅思 Task 1（图表 / 地图 / 流程图）为适用场景。

---

## 1. 通用高分原则
| 原则                  | 解释                                                             | 易错示例                            | 推荐表达                                    |
| --------------------- | ---------------------------------------------------------------- | ----------------------------------- | ------------------------------------------- |
| **同类比较**          | 比较对象必须同类（数字 vs 数字，国家 vs 国家，而非数字 vs 国家） | “The figure was higher than Spain.” | “…than the figure for Spain.”               |
| **时态一致**          | 图表若无时间提示 → 一般现在时；有明确过去时间 → 一般过去时       | “The chart showed…” (过去时)        | “The chart shows…” (现在时)                 |
| **概述段 (Overview)** | 必须有一句宏观概括，不含具体数字                                 |                                     | 见下文模板                                  |
| **被动语态**          | 强调“发生了什么”而非“谁做了”                                     | “The island built many facilities.” | “Many facilities were built on the island.” |

---

## 2. 静态图表（表格 / 饼图 / 柱状图）

### 2.1 开头段
| 知识点          | 解释                                                                            | 示范句                                                                                                                                              |
| --------------- | ------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| paraphrase 题干 | 同义替换题干动词 & 名词                                                         | The **table illustrates** how **household expenditure** in **five countries** is **distributed across** three **categories of goods and services**. |
| 替换 “items”    | 泛指商品或服务 → **categories / types / kinds / products / goods and services** | Consumer spending on **food, drinks, and tobacco**…                                                                                                 |

### 2.2 概述段（Overview）
| 写法     | 模板句                                                                                                                                                                                    | 备注     |
| -------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------- |
| 横向比较 | “Overall, **food and drinks** accounted for the **largest share of spending** in all five countries, whereas **education and leisure** consistently made up the **smallest proportion**.” | 不写数字 |
| 纵向比较 | “In general, **Turkish residents devoted a higher proportion of their income** to all three categories **than their counterparts** in the other four nations.”                            | 不写数字 |

### 2.3 细节段
| 语言点                                      | 解释 & 高分表达                                                                                       | 示例                                                                                                                          |
| ------------------------------------------- | ----------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| **proportion / percentage / figure** 做主语 | 谓语动词用 **单数**                                                                                   | “The **figure for food** was 28 % in Turkey.”                                                                                 |
| **占比例** 动词                             | **account for / make up / comprise / constitute / represent**                                         | “Education **accounted for** only 3 %.”                                                                                       |
| **程度副词**                                | 避免 **extremely + 比较级** → 用 **considerably / significantly / substantially / noticeably higher** | “Turkey’s figure was **significantly higher** than that of Spain.”                                                            |
| **同位语数字**                              | 括号或直接嵌入                                                                                        | “Turkey, **with 28.91 %**, had the highest proportion.”                                                                       |
| **分组比较**                                | One group vs the other                                                                                | “The **first group**, comprising Ireland and Turkey, **spent markedly more on food** than **the remaining three countries**.” |

---

## 3. 地图题（Island Development）

### 3.1 开头段
| 知识点       | 高分表达                                                                                               | 错误示例                       |
| ------------ | ------------------------------------------------------------------------------------------------------ | ------------------------------ |
| 描述“变化”   | **major changes / a dramatic transformation / significant developments**                               | ❌ “a big change of the island” |
| 时态         | 过去变化 → **took place / occurred**                                                                   | ❌ “a change has taken place”   |
| compare 结构 | **The map compares the current layout of the island with what it looked like before the development.** | ❌ “compare A and B” 缺 with    |

### 3.2 描述方位
| 表达                     | 示范                                                   | 备注                                                                     |
| ------------------------ | ------------------------------------------------------ | ------------------------------------------------------------------------ |
| **倒装**                 | “**To the north of the reception is a restaurant.**”   | 介词短语开头 → 完全倒装                                                  |
| 动词“位于”               | **is located / is situated / lies / stands**           | ❌ “a beach located in the west” → ✅ “a beach **is located** in the west” |
| **around / surrounding** | “**A group of huts has been built around the trees.**” | 避免 encircle 误用                                                       |

### 3.3 设施增减
| 动作 | 名词化                                        | 示例                                             |
| ---- | --------------------------------------------- | ------------------------------------------------ |
| 建造 | the **construction** of / the **building** of | “the **construction of new tourist facilities**” |
| 拆除 | the **demolition** of / the **removal** of    | “the **demolition of old houses**”               |
| 增添 | the **addition** of                           | “the **addition of a swimming area**”            |
| 保留 | **remain / stay unchanged**                   | “The trees **remain** where they were.”          |

---

## 4. 人口结构图（Population Pyramids）

### 4.1 开头段
| 知识点   | 表达                                                                                                                                                             |
| -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 描述对象 | “The chart **illustrates the age structure of the populations** of France and India.”                                                                            |
| 坐标轴   | “The **horizontal axis indicates age groups** in five-year **increments**, while the **vertical axis shows the percentage of males and females** in each group.” |

### 4.2 概述段
| 写法     | 模板                                                                                                                    |
| -------- | ----------------------------------------------------------------------------------------------------------------------- |
| 对称性   | “Overall, **both countries display a roughly symmetrical distribution** between males and females in every age cohort.” |
| 形状概括 | “India’s profile **resembles a pyramid**, whereas France’s **is more barrel-shaped**.”                                  |

### 4.3 细节段
| 语言点       | 高分表达                                                  | 错误示例                                                                                      |
| ------------ | --------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| **占比**     | **account for / make up / constitute**                    | ❌ “correspond to 7 %”                                                                         |
| **递减表达** | **with progressively smaller proportions**                | “…**with each older cohort making up a progressively smaller proportion** of the population.” |
| **区间表达** | **fell within the range of 3 % to 4 %**                   | ❌ “between 3 % and 4 % without preposition”                                                   |
| **连接词**   | **Looking at France / Turning to France / As for France** | ❌ 直接 “In France” 与前句割裂                                                                 |

---

## 5. 易错语法速查表

| 错误                                                   | 解释                 | 正确                                         |
| ------------------------------------------------------ | -------------------- | -------------------------------------------- |
| percentages **on** sth.                                | 介词误用             | percentages **of** spending **on** sth.      |
| **was extremely higher**                               | 副词与比较级搭配不当 | **was significantly higher**                 |
| **the other three nations** vs **other three nations** | 特指与泛指           | 前文已列出 → **the other three nations**     |
| **a lot of facilities took place**                     | 主语不能“发生”       | **a lot of facilities were built / emerged** |
| **the lowest figure are Sweden**                       | 主语-表语不一致      | **the lowest figures are for Sweden**        |
| **money… were**                                        | 不可数名词           | **the money spent… was**                     |

---

## 6. 分段策略（Mermaid 流程图）

```mermaid
graph TD
    A[拿到图表] --> B{静态? 地图? 动态?}
    B -->|静态| C[开头段 paraphrase]
    B -->|地图| D[开头段 describe changes]
    C --> E[概述段 1-2句 无数字]
    D --> E
    E --> F[主体段1 最高 & 特征]
    E --> G[主体段2 次高/最低 & 细节]
    F --> H[结尾可选 重申概括]
    G --> H
```

---

## 7. 提分建议清单

1. **背诵 10 句型**  
   - “The figure for A was **almost twice that** for B.”  
   - “A **accounted for the largest share**, at approximately 30 %.”  
   - “**Compared with** 2000, the proportion **rose by 5 %**.”

2. **每天 5 分钟改写错误**  
   把老师标出的 ❌ 句子 → 用表格里的 ✅ 表达改写。

3. **建立“数字+形容词”搭配库**  
   - 高：substantial / considerable / significant  
   - 低：minimal / marginal / negligible  
   - 相等：comparable / identical / alike

4. **地图题模板句默写**  
   - “After the development, a restaurant **has been built at the end of a footpath leading north from the reception**.”

5. **检查三步**  
   ① 比较对象同类？② 时态一致？③ 副词+原级 / 比较级搭配正确？

---

按以上清单逐项练习，可在 2–3 周内显著减少 Task 1 语法 & 逻辑错误，并提升 Lexical Resource & Cohesion 的评分档次。