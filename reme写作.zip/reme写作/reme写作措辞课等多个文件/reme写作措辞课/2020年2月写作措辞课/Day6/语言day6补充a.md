## 课程语音转文字稿·系统梳理

### 一、课程目标
| 目标                                            | 解释                                                                                      |
| ----------------------------------------------- | ----------------------------------------------------------------------------------------- |
| 1. 把 6.5 作文升级为 7.5                        | 6.5 作文：单句都对，但逻辑跳跃、连接弱；7.5 作文：逻辑顺滑、抽象-具象结合、语言单位完整。 |
| 2. 掌握「先讲理 → 再讲事 → 事理结合」的写作顺序 | 理＝上位概念、抽象判断；事＝具体场景、动作；避免“人-人-人”堆砌。                          |
| 3. 识别并修复「逻辑鸿沟」                       | 任何一句话与前一句若出现“突然跳到人/物”或缺失因果，即为鸿沟。                             |

---

### 二、核心知识点

#### 2.1 抽象概念作主语（提升语言层级的关键）
| 原句（人作主语）                                   | 升级句（抽象概念作主语）                                                                             |
| -------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| Students can learn how to communicate with others. | Communication skills can be developed through daily interactions with peers of diverse temperaments. |
| Schools allow students to practice social skills.  | Schools, as miniature societies, provide optimal settings for such interactions.                     |

> 技巧：把“人”换成 skill / interaction / environment / platform 等上位词，再补一句“因为……”填平逻辑鸿沟。

#### 2.2 逻辑连接词与标点
| 功能      | 推荐                      | 不推荐                       | 例子                                            |
| --------- | ------------------------- | ---------------------------- | ----------------------------------------------- |
| 补因果    | because, as, since        | so（口语）, thus（悬空副词） | …because schools serve as the optimal platform… |
| 并列/递进 | ; moreover, and           | 逗号+and（易成 run-on）      | …; moreover, such skills are…                   |
| 总结      | therefore, in other words | so                           | Therefore, full-time education…                 |

#### 2.3 语言单位完整性
- **错误拆分**  
  `Full-time education gives kids a great opportunity.`（缺“to do…”）  
- **正确合并**  
  `Full-time education gives kids a great opportunity to develop social skills.`

#### 2.4 中英思维差异
| 中文           | 英文对应                                                    | 注意                      |
| -------------- | ----------------------------------------------------------- | ------------------------- |
| 除了…之外还有… | besides / apart from                                        | except for = 排除         |
| 学校像小社会   | a miniature society full of people from diverse backgrounds | 避免“small society”口语化 |

---

### 三、课堂示范：6.5 → 7.5 改写流程

```mermaid
flowchart TD
A[Emma 原句 6.5] --> B[识别文章重心]
B --> C[补充逻辑链]
C --> D[抽象概念作主语]
D --> E[填平逻辑鸿沟]
E --> F[7.5 版本]

A1["Full-time education enables students to go enough interaction…"]
B1["重心=develop social skills"]
C1["为何18岁前必须在学校完成？"]
D1["Communication skills can be developed…"]
E1["because schools serve as optimal platform…"]
F1["Some maintain that students should be required to stay in full-time education until at least 18 because schools where such education takes place serve as the optimal platform for them to learn how to deal with different people in varying situations."]
```

---

### 四、自检清单（交作业前）
| 步骤 | 问题                                                  | 是否完成 |
| ---- | ----------------------------------------------------- | -------- |
| 1    | 每段第一句话是否直接回答题目？                        | ✅ / ❌    |
| 2    | 是否存在“人-人-人”主语堆叠？                          | ✅ / ❌    |
| 3    | 是否出现“opportunity / ability…”后缺 to do？          | ✅ / ❌    |
| 4    | 是否用 therefore/so 总结整段而非单句？                | ✅ / ❌    |
| 5    | 是否所有抽象词（skill, interaction…）后都跟因果解释？ | ✅ / ❌    |

---

### 五、课后练习建议
1. **抽象主语造句**  
   把今天作文里所有“人”开头的句子挑出来，用 communication / interaction / environment / curriculum 等抽象词重写，保持原意。
2. **逻辑鸿沟排查**  
   用箭头图把段落中每句话前后连接画出来，凡是没有“因为/所以/例如”标注的即为鸿沟，补上因果或例子。
3. **朗读-回译**  
   读英文句，立刻脑中翻译成中文；再中文翻回英文，检查是否丢失逻辑或词汇。

---

### 六、一句话总结
> 7.5 作文=抽象概念当主语 + 因果链锁 + 无逻辑鸿沟 + 精准词汇，6.5 与 7.5 之间只差“把理说圆”。