# 雅思写作 Day6 课程知识点系统梳理

> 本节课以“青年失业”话题为引，深入拆解了一篇学生范文（杜世迅），并现场示范如何写出逻辑更严密、语言更地道的段落。以下用“知识点 + 例子 + 建议”的形式，完整复盘所有要点，并给出可立即落地的学习方案。

---

## 1. 题目解析 & 审题陷阱

| 题目原文                                                                                                                                                                                                                                          | 拆解要点                                                                                                | 常见误判                 | 正确做法                                                                                                                              |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- | ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------- |
| In many countries more and more young people are leaving school and unable to find jobs after graduation. **What problems do you think youth unemployment will cause to the individual and the society? Give reasons and make some suggestions.** | 1. **因果类**（cause → problem）<br>2. 双主体：individual + society<br>3. 需要给出reasons & suggestions | 误以为是4问，准备写5-6段 | 实质是 **2问**：<br>① cause → youth unemployment<br>② problems (individual & society) + suggestions<br>共4段：Intro-2 body-Conclusion |

**示例**：  
错误审题 → 写成“原因段+问题段A+问题段B+建议段”导致段落拥挤。  
正确审题 → 先回答“为何失业”，再回答“带来什么社会问题”，最后给出建议。

---

## 2. 段落结构：从“清单式”到“因果链”

| 写作模式   | 特征                               | 评分影响 | 改进模板                                                                         |
| ---------- | ---------------------------------- | -------- | -------------------------------------------------------------------------------- |
| **清单式** | 每段列一个新点，无逻辑衔接         | TR 5-6   | 避免：一段内写“公司偏好+教育体制+经济衰退”                                       |
| **因果链** | 每段围绕一个核心原因展开，层层递进 | TR 7+    | 模板：<br>① 提出原因（抽象概念）<br>② 具象化解释<br>③ 反向现实（对比）<br>④ 结果 |

**示例（因果链）**  
> The reason behind rampant youth unemployment is **the corporate preference** for skilled laborers over fresh graduates. **This preference stems from** cost-efficiency analysis: training newbies is costly. **However, the sad reality is that** students are still pushed toward general education, believing degrees guarantee jobs. **Consequently**, a mismatch of skills ensues, fueling unemployment.

---

## 3. 语言“减法”与“加法”策略

| 策略     | 定义                         | 示例                                                                                                                                                                                                | 课堂金句                               |
| -------- | ---------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------- |
| **减法** | 删除冗余、模糊、中式表达     | ❶ "our attention is attracted by increasing unemployment rate" → "the rising unemployment grabs headlines" <br>❷ "low educational specialized worker" → "skilled laborers with vocational training" | “Redundancy is clutter. Kill it.”      |
| **加法** | 增加逻辑衔接、抽象名词、对比 | ❶ 添加 "the preference for A over B" 替代 "companies would rather..." <br>❷ 对比 "academic background vs hands-on experience"                                                                       | “Use abstract nouns to elevate logic.” |

---

## 4. 主语重心 & 抽象名词化

| 错误示范                                            | 问题                       | 修正                                                                         | 效果                                     |
| --------------------------------------------------- | -------------------------- | ---------------------------------------------------------------------------- | ---------------------------------------- |
| "Companies are more likely to choose candidates..." | 主语是“公司”，偏离宏观原因 | "The **preference** for experienced workers **is rooted in** cost concerns." | 主语变为抽象概念“preference”，逻辑更宏观 |

**Mermaid 流程图：主语重心迁移**

```mermaid
graph LR
A[具体主体: Companies] -->|名词化| B[抽象概念: Preference]
B --> C[因果链: Preference → Cost → Unemployment]
```

---

## 5. 具象化 & 细节填充

| 抽象表达             | 具象化技巧  | 示例                                                                                                                             |
| -------------------- | ----------- | -------------------------------------------------------------------------------------------------------------------------------- |
| "Training is costly" | 量化 + 对比 | "Training a fresh graduate costs **3 months and $5,000**, while hiring an experienced worker yields **immediate productivity**." |
| "Skills mismatch"    | 举例        | "Universities teach **theoretical economics**, but employers need **data analysis proficiency**."                                |

---

## 6. 对比结构：预期 vs 现实

| 句型模板                           | 课堂例句                                                                                                           |
| ---------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| **The sad reality is that...**     | "The sad reality is that students are **herded into** general education, **which sidelines** practical skills."    |
| **Contrary to the belief that...** | "Contrary to the belief that degrees ensure jobs, **vocational certificates** are now the passport to employment." |

---

## 7. 词汇升级：避免“chinglish”

| 中式表达               | 地道替换                  | 备注                     |
| ---------------------- | ------------------------- | ------------------------ |
| "low educational"      | "vocational training"     | 用具体名词替代形容词堆砌 |
| "this year's graduate" | "fresh college graduates" | 简洁自然                 |
| "apparently enough"    | 删除                      | 冗余，语义重复           |

---

## 8. 课后练习方案

| 步骤      | 任务                                                                                                                            | 工具                                                                                                                       | 检查点                 |
| --------- | ------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- | ---------------------- |
| 1. 审题   | 找一道“cause-problem-solution”题，划出关键词                                                                                    | 用下划线标出双主体                                                                                                         | 是否误判为“多问答”     |
| 2. 列提纲 | 画因果链：原因→具象化→对比→结果                                                                                                 | 思维导图                                                                                                                   | 每段是否只服务一个核心 |
| 3. 写段落 | 用“抽象名词化”改写以下句子：<br>"Many companies prefer to hire experienced workers because training new graduates needs money." | 参考答案：<br>"The corporate preference for seasoned employees stems from the **prohibitive cost of onboarding novices**." | 主语是否为抽象名词？   |
| 4. 检查   | 朗读段落，删除冗余词（如“very”, “actually”）                                                                                    | 使用Hemingway Editor                                                                                                       | 可读性≤Grade 8         |

---

## 9. 教师金句合集（背诵）

1. **“Redundancy is not vocabulary. It’s clutter.”**  
2. **“If you can’t explain it to a 12-year-old, rewrite it.”**  
3. **“Abstract nouns are the skeleton of logic.”**  
4. **“Contrast creates clarity.”**  

---

## 10. 下一步学习路径

- **Day7**：继续“青年失业”问题段写法，学习“社会问题”的3种展开模型（数据/案例/影响链）。  
- **长期**：建立“抽象名词库”（见下表），每周替换5个中式表达。

| 抽象名词   | 场景     | 例句                                                          |
| ---------- | -------- | ------------------------------------------------------------- |
| Prevalence | 描述现象 | "The prevalence of unpaid internships reflects..."            |
| Disparity  | 对比差异 | "The disparity between academic skills and market demands..." |
| Incentive  | 分析原因 | "Financial incentives drive companies to favor..."            |

---

> **结语**：写作不是“堆高级词”，而是“让每一句都服务于逻辑链”。按本框架练习，任何话题都能在20分钟内写出7分+段落。