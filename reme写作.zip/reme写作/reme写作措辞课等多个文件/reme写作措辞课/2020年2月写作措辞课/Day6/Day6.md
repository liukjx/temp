课程核心知识点系统梳理  
（按逻辑顺序排列，配解释 / 示例 / 可视化）

---

### 1. 写作评分“潜规则”  
| 分数段 | 教师心理活动 | 典型错误举例 | 建议 |
|---|---|---|---|
| 5.5↓ | “What the fuck are you talking about” | 缺谓语：`…the decrease in frequency among customers, because…` | 先补全主谓宾，再谈高级结构 |
| 6 | 大体能猜，但局部 WTF | `the accuracy of AI`（没限定范围） | 用 of 后必须接“可衡量精度的系统”：`the accuracy of the positioning system` |
| 6.5 | 语言好，但线性、深度不足 | 只写“AI→efficiency→economy”单线因果 | 加 counter-argument & rebuttal（见第 5 点） |
| 7↑ | 逻辑闭环，用词地道 | 使用 language chunks：`a dead giveaway`, `blew his cover` | 用 corpus 验证搭配：skell.com / youglish.com |

---

### 2. 中式英语三大病灶  
| 病灶 | 中式表达 | 母语者表达 | 纠正方法 |
|---|---|---|---|
| 逐字直译 | the spy exposed himself | the spy **blew his cover** | 查 chunk，而非单词 |
| 词性混用 | safety/steady (adj↔n) | **safety** (n.) / **stability** (n.) | 用英英+例句：Macmillan Dictionary |
| 搭配不当 | fatigue driving | **driving fatigue** / **drowsy driving** | 读原版交通报告：NHTSA, AAA |

---

### 3. Language Chunks 速查表（口语+写作通用）  
| 场景 | Chunk | 中文映射 | 例句 |
|---|---|---|---|
| 暴露身份 | a dead giveaway | “一眼识破” | His accent was a dead giveaway. |
| 卧底暴露 | blow one’s cover | “穿帮” | One wrong word and you’ll blow your cover. |
| 经济拖累 | drag the economy down | “拖经济后腿” | High unemployment could drag the economy down. |
| 过渡阶段 | transitioning/temporary phase | “阵痛期” | Job losses are only a **transitioning phase**. |

---

### 4. XYZ 题型的“揉合”写法  
题目示例：`AI-driven cars will pose a serious threat to our economy. To what extent do you agree?`

#### 4.1 思维流程图  
```mermaid
graph TD
    A[AI普及] --> B[失业率↑<br>taxi/truck drivers]
    B --> C{只是阵痛期?}
    C -->|YES| D[再培训→新岗位]
    C -->|NO | E[技能不匹配]
    E --> F[政府介入<br>welfare & reskilling]
    F --> G[财政负担↑<br>→经济短期拖累]
    G --> H[长期：多数再就业<br>→threat 不 serious]
```

#### 4.2 段落模板  
1. **抽象上位句**：The most immediate threat AI-driven cars pose to the economy is a spike in unemployment.  
2. **具象化展开**：Taxi, bus and truck drivers—who account for roughly X % of the labor force—will be displaced within a decade.  
3. **反方**：Some argue this is merely a **transitioning phase**; retraining programs can funnel them into new logistics-tech roles.  
4. **反驳**：Yet, a sizeable minority—older or low-skilled workers—**lack the ability** to adapt, and the **training cost** may outweigh fiscal gains.  
5. **折中结论**：While the transition will **initially drag the economy**, targeted government-industry coalitions can turn the threat into a **short-lived dip** rather than a structural collapse.

---

### 5. 写作自检 5 步  
| 步骤 | 自查问题 | 工具 |
|---|---|---|
| 主谓完整 | 每句有主语+谓语？ | Grammarly / 朗读法 |
| 搭配地道 | Collocation 正确？ | Skell / Ludwig.guru |
| 抽象-具象平衡 | 是否只有 facts 或只有 big words？ | 用“电梯总结法”：30 秒口述段落大意 |
| 逻辑闭环 | 每个论点都有 counter & rebuttal？ | 用颜色笔标出 A-R-A 链 |
| 经济话题词汇 | cost-effectiveness, productivity, fiscal burden, welfare, reskilling | Notion 建专属词库 |

---

### 6. 课后任务（按优先级）  
1. 重写：把“AI-driven cars & economy”按 XYZ 结构写一篇 270 词作文，使用以上模板。  
2. 收集 10 个交通/经济领域高频 chunks，做成 Quizlet 卡片。  
3. 用 mermaid 再画一个“AI-driven cars & safety”XYZ 流程图，练习抽象-具象转换。  

---

一句话总结  
先让句子“说人话”，再让段落“有辩论”，最后用 language chunks 包装成 7+ 作文。