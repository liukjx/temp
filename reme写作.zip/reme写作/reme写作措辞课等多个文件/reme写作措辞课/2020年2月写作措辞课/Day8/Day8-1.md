【课程全文知识梳理 & 学习建议】  
文件是一堂 IELTS/SAT 写作口语直播课的逐字稿。老师用大量例子指出中国考生最容易犯的 4 类错误，并给出对应的训练方法。下面用「知识点 → 解释/例子 → 训练工具」三步法系统梳理，并给出可立即执行的 21 天学习计划。

---

### 一、四大高频失分点与补救策略

| 类别 | 典型错误 | 正确做法 | 课堂案例 | 自查/训练工具 |
|---|---|---|---|---|
| **逻辑链缺失** | 以偏概全：把“开不了会”直接等同于“business 完蛋” | 每个论点必须回答「Why & How」 | climate change→bad weather→transportation shutdown→meeting cancelled→business impact 才完整 | “So-What 三连问”模板：<br>①论点 → ②为什么 → ③那又怎样 |
| **中式直译** | making sb. fail to arrive / working could be done | 用地道动词+状态：<br>render sb. stranded / cause a blackout | 把 making the businessman fail to… 改成 rendering the businessman stranded | Grammarly+DeepL Write 反向翻译法 |
| **冗余 & 重心偏移** | 为了“首尾接龙”硬塞细节 | 每段只服务一个 main idea，删掉无关信息 | 写 Martin Luther King 演讲，却插入「学校哪年建校」 | SAT 官方 Writing 题库：<br>只保留「relevant detail」题 |
| **连接词误用** | 用 by / which / even though… 导致逻辑跳跃 | 先写“手段”再写“结果”；区分 even if vs. even though | by bringing out an abominable environment ❌ | 建立「连词-功能」对照表（见下） |

---

### 二、关键连接词对照表

| 英文连词 | 功能 | 例句 | 易混淆点 |
|---|---|---|---|
| **even if** | 让步：即使条件成立，结果仍发生 | Even if the weather is fine, the meeting may still be cancelled. | vs. even though（已发生的事实） |
| **by + V-ing** | 手段：前面动作的实现方式 | The storm **by cutting power** halted the meeting. | 后面必须接“具体动作”而非抽象名词 |
| **render + 宾语 + 形容词** | 使…处于某种状态 | The flood **rendered the roads impassable**. | 替代 make sb./sth. do |
| **locally** | 副词 = in the local area | The event was held **locally**. | 不用 *in the local* |

---

### 三、Mermaid 流程图：如何把“抽象理由”写成“可感细节”

```mermaid
flowchart TD
    A[抽象论点<br>climate change hurts business] --> B[找“桥梁”概念]
    B --> C{选最直接影响}
    C -->|供应链| D[极端天气 → 港口关闭 → 货物延迟]
    C -->|人力| E[暴雪 → 员工滞留 → 生产力下降]
    D --> F[写成 2-3 句细节<br>+ 数据或例子]
    E --> F
    F --> G[回指论点<br>Thus, revenue drops]
```

---

### 四、21 天可执行训练计划

| 周期 | 每日任务 | 工具 & 资源 | 输出形式 |
|---|---|---|---|
| 第 1-7 天 | **纠正中式表达** | 1. 每天改 5 句中式直译（老师给的错句）<br>2. 用 Grammarly 检查并记录高频错误 | 建立《中式→地道》错句本 |
| 第 8-14 天 | **逻辑链训练** | 1. 选 3 个 IELTS 大作文题，用「So-What 三连问」写提纲<br>2. 对照范文，标出缺失的“桥梁概念” | 思维导图（XMind） |
| 第 15-21 天 | **SAT 语法冲刺** | 1. 每天限时做 2 篇 SAT Writing（OG/可汗）<br>2. 精析错题，归类到「逻辑/冗余/词法」三类 | 错题 Excel + 模板句背诵 |

---

### 五、示范：如何把一句“烂句”改成 7 分句

**原句（5 分水平）**  
Climate change may hold up many important meetings by bringing out an abominable environment, which prevents meeting being held smoothly.

**改写步骤**  
1. 找出“手段-结果”链：恶劣天气 → 交通中断 → 参会者无法到场  
2. 替换中式搭配：  
   - hold up → delay / ground  
   - abominable environment → extreme weather events  
   - prevents meeting being held → cause the meeting to be called off  
3. 加入细节与地道表达：  
   **Severe snowstorms can ground flights and strand attendees, forcing organisers to call off critical negotiations.**

---

### 六、一句话总结  
停止“词汇+语法”单机思维，用 **SAT 逻辑题** 练框架，用 **地道语料库** 改表达，再用 **So-What 三连问** 检查逻辑链——三周即可把写作从 6 提到 7+。