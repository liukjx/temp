这份长达数万字的课堂实录，内容横跨 SAT 阅读、雅思大作文、小作文（图表、地图）、逻辑连接词、心理技巧在广告中的运用等多个板块。下面用「知识点 + 例子/模板 + 可视化」的形式做一份系统梳理，方便复习与直接使用。

---

## 1. SAT 阅读：逻辑连接词预判法  
核心思路：先背住连接词，再倒推后半句应该长什么样。  

| 连接词      | 后半句逻辑预判（例子）                                                       | 中文口诀         |
| ----------- | ---------------------------------------------------------------------------- | ---------------- |
| furthermore | 追加同类信息：400 graduates …, **furthermore**, 1 000 staff came.            | 再添一把火       |
| as a result | 前因后果：400 graduates …, **as a result**, extra chairs were brought in.    | 所以坐不下       |
| by contrast | 反向对比：400 came to MLK, **by contrast**, nobody showed up for X’s speech. | 对手惨兮兮       |
| however     | 重点落在后句：400 came, **however**, MLK stole the spotlight.                | 但是后面才是重点 |

➡ Mermaid 流程图：看到连接词 → 脑中瞬间补出后半句框架  
```mermaid
graph LR
A[看到连接词] -->| furthermore | B[补“还有谁/多少”]
A -->| as a result | C[补“结果如何”]
A -->| by contrast | D[补“反例多惨”]
A -->| however | E[补“后半句才是重点”]
```

---

## 2. 雅思大作文：双边讨论（XY）万能骨架  
题目：发展中国家到底需要 **financial help** 还是 **practical aid & advice**？

| 段落             | 内容模板                                                                                                                                        | 可套用的例子             |
| ---------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| Intro            | Some argue **X**, while others insist **Y**. This essay explores both views before presenting my stance.                                        | 疫情、非洲基建           |
| Body1 (X)        | ① Flexibility – money can buy **whatever is needed**. ② Easy & fair distribution – wire transfer vs shipping vaccines.                          | 联合国直接拨款买口罩     |
| Body2 (Y)        | ① Money ≠ availability – money cannot buy **non-existent** resources. ② Less corruption – 100 000 masks are harder to steal than $100 000 cash. | 湖北口罩被截留事件       |
| Body3 (自己观点) | After weighing both, I lean to **X/Y** because…                                                                                                 | 1–2 句即可，不再重复细节 |

⚠ 注意：不要把重心写成“为什么穷国缺钱”，而是写“钱的**特性**”！

---

## 3. 雅思大作文：广告类 “to what extent” 写法  
题目：Consumers are faced with increasing ads → to what extent are they influenced?

### 3.1 三种立场模版
| 立场     | 一句话立场句                                                                            | 后续写法提示                   |
| -------- | --------------------------------------------------------------------------------------- | ------------------------------ |
| 完全不受 | Consumers are **not influenced at all** because they have a mind of their own.          | 举“理性消费”例子               |
| 部分受   | Consumers are **somewhat influenced**, even though they still make independent choices. | 让步写法：even though…, still… |
| 强烈受   | Consumers are **strongly influenced** by psychological tricks embedded in ads.          | 微观心理描写（见下）           |

### 3.2 微观写法（Micro）  
公式：**心理动词 + 具体场景 + 结果**  
- 例：When a teenager scrolls through Instagram, the ad **compares** her worn-out sneakers with the influencer’s dazzling new Jordans; vanity **kicks in** and she **clicks “buy now”** without checking the price.  

### 3.3 心理技巧清单（可直接嵌入段落）
| Trick             | 一句话解释 | 课堂原话                                   |
| ----------------- | ---------- | ------------------------------------------ |
| Social comparison | 把人比下去 | “wanting to be better in social hierarchy” |
| Sex appeal        | 性暗示     | “sex sells”                                |
| Scarcity          | 限量倒计时 | “only 3 left”                              |
| Bandwagon         | 人人都在买 | “all your friends have it”                 |

---

## 4. 雅思小作文：静态图表 7.5+ 写法  
以「四国垃圾处理方式」为例：

### 4.1 高分 Grouping 思路
| Group 1：Diversified           | Group 2：Less diversified                           |
| ------------------------------ | --------------------------------------------------- |
| Italy & UK（三种方式比例接近） | Spain（≈70 % burning）<br>Finland（recycling 最低） |

一句话 Overview：  
**Overall, Italy and the UK employed a more balanced mix of methods, whereas Spain relied predominantly on burning and Finland recycled the least.**

### 4.2 段落模板
- **Para1**：The table compares **how Finland, Italy, Spain and the UK disposed of their waste** in **three different ways** (burning, recycling, landfill).
- **Para2**：Italy and the UK … (具体数值 + 多样性)
- **Para3**：By contrast, Spain … (专烧) while Finland … (几乎不回收)

---

## 5. 雅思小作文：动态图表高分心法  
核心：**抓最大趋势 + 忽略细枝末节**  
例：1992–2012 图书销量变化  
- 升：adult fiction  
- 降：biography  
- 其余：travel 轻微波动 → 可一句带过  

一句话 Overview：  
**Between 1992 and 2012, adult fiction overtook biography as the best-selling category, while travel books experienced only marginal change.**

---

## 6. 写作细节与考场策略

| 问题         | 老师原话                               | 建议                                                  |
| ------------ | -------------------------------------- | ----------------------------------------------------- |
| 全大写       | “你时间绝壁不够”                       | 保持正常大小写                                        |
| 数据不会描述 | “不用统计，告诉考官你**每天看到什么**” | 用日常场景代替数字                                    |
| 结尾段       | “I don’t give a f***”                  | 双边类文章：Body3 已给出立场，**无需再写 conclusion** |

---

## 7. 复习清单（Checklist）

- [ ] 能用 furthermore / as a result / by contrast / however 倒推后半句  
- [ ] 双边讨论模板背熟：Flexibility + Availability + Corruption 三点  
- [ ] 广告类掌握程度副词：strongly / somewhat / not at all  
- [ ] 小作文静态表：先找“最单一 vs 最多样”分组  
- [ ] 小作文动态表：只写“最大升降”，其余一笔带过  
- [ ] 心理 trick 举例至少 3 个，能塞进广告段落  

---

祝写作一次分手！