# 📚 雅思写作 Day5-1 课程精华速查手册  
> 一句话总结：把“特质”降级为状语/从句，把“重心”写成主句；逻辑顺序＝“因→果/对比→果”的倒三角结构。  

---

## 1️⃣ 评分真相速览
| 分数档 | 考官真实体验                 | 能否抢救             |
| ------ | ---------------------------- | -------------------- |
| ≤6     | 看不懂＝改不了               | 先解决“看不懂”       |
| 6.5    | 能看懂、逻辑不差，但主次颠倒 | 调主谓顺序即可冲到 7 |
| ≥7     | 主次分明＋具象化＋地道搭配   | 少犯小错就稳         |

---

## 2️⃣ 核心概念：主次（Main vs. Sub）
| 概念                            | 判断方法                | 写作位置           | 改写示例                                                                                            |
| ------------------------------- | ----------------------- | ------------------ | --------------------------------------------------------------------------------------------------- |
| **重心**（Main Point）          | 回答题目、给出因果/对比 | 主句               | Computers can cope with emergencies better than humans **because all human errors are eliminated**. |
| **特质**（Feature / Condition） | 只描述主体属性          | 状语、从句、同位语 | **Unlike humans**, who get tired, computers constantly monitor every direction.                     |

---

## 3️⃣ 高分结构公式（倒三角）
```mermaid
%% 倒三角写作流程图
graph TD
    A[开宗明义：立场/对比句] --> B[次要条件：电脑特质]
    B --> C[次要条件：人类特质]
    C --> D[重心句：所以电脑更安全]
    D --> E[具象化：举例/数据]
```

---

## 4️⃣ 常见失分坑 & 现场改错
| 原句（6.5 水平）                                                                | 问题                 | 7+ 改写                                                                                        |
| ------------------------------------------------------------------------------- | -------------------- | ---------------------------------------------------------------------------------------------- |
| The essence of autonomous driving **is** collecting and processing information. | 抽象下定义，逻辑不通 | **Because** onboard computers **can** collect and process real-time data, …                    |
| …manoeuvre in a fleet **which significantly reduce…**                           | 缺主语、缺具象       | …**allowing each car to keep a safe distance via GPS**, thus **reducing** rear-end collisions. |
| …computers **never getting tired** or **distracted**…                           | 非谓语并列超限       | …computers, **which never get tired or distracted**, respond…                                  |

---

## 5️⃣ 自查 Checklist（写完后 3 分钟）
1. **圈出每段第一句**：它是不是“立场或因果”？  
2. **高亮所有 Because / Since / If**：它们前面是否为“条件”，后面是否为“结果”？  
3. **删除纯定义句**（如 “X is Y”），改为 “As X can do Y, …”  
4. **替换口语词**：thing → factor / issue；make sth better → enhance / optimise  
5. **语法微改**：  
   - can be faster → **are** faster  
   - which are proved → **which specialists claim**  

---

## 6️⃣ 训练建议
| 目标       | 工具                         | 操作指南                                                              |
| ---------- | ---------------------------- | --------------------------------------------------------------------- |
| 强化主次感 | SAT “Combine Sentences” 题库 | 每天 5 题，强制把两句“特质”压缩成一句从句                             |
| 地道搭配   | COCA/Sketch Engine           | 搜 “computers * collisions” 找高频动词                                |
| 具象化     | 反向举例法                   | 每写一个优点，立刻补一句人类反例（e.g., humans tailgate → accidents） |
| 逻辑连贯   | 口头复述                     | 用 30 秒中文说清“电脑为何更安全”，再英文写一遍                        |

---

## 7️⃣ 一页速背模板
> **立场句** + **Since 条件1** + **and unlike 条件2** + **重心句** + **具象化**  
> **例**：  
> Autonomous cars are safer **since** they constantly monitor surroundings **and unlike** human drivers, who get distracted, **they eliminate** most human errors, **thus cutting rear-end collisions by 90 %**.

---

### ✅ 课后 24h 行动清单
- [ ] 把今天自己作文按“主次”重标颜色  
- [ ] 用 checklist 自查并改出 7 版本  
- [ ] 发群里互评，重点挑“哪句是重心”  

> **Remember：考官只在乎“一眼看懂你的逻辑”。主次分明，你就已经赢了 80 % 的考生。**