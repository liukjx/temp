课程主题  
广告如何影响人们的价值观与行为——写作逻辑、语句重心、倒三角结构、词汇替换与评分标准

──────────────────────────────────  
一、知识点速览表  

| 知识点                        | 一句话定义                                                                   | 例子 / 操作步骤                                                                                                                                                                                  |
| ----------------------------- | ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 语句重心（Sentence Focus）    | 每句话的主语与谓语必须直指段落核心论点，否则文章重心会被“带偏”。             | 错：Nowadays people are surrounded by ads and this affects their lives.（主语跳来跳去）<br>对：Advertisements distort people’s value system by glorifying materialism.（主语-谓语-结果一目了然） |
| 文章重心（Essay Focus）       | 全文只能有一个 controlling idea；任何例子、数据、对比都必须直接服务该 idea。 | 主题：广告→materialism→不幸福。<br>删掉与“广告创意很棒”相关的任何句子，否则重心漂移。                                                                                                            |
| 倒三角结构（Reverse Pyramid） | 先给结论/抽象概念，再给原因，最后才是细节或例子。                            | 段内顺序：<br>1. Ads breed materialism（结论）<br>2. Because they equate happiness with possessions（原因）<br>3. Celebrity endorsement & special effects（细节）                                |
| 正三角 vs 倒三角              | 正三角：先细节→后总结（易跑题）<br>倒三角：先结论→后细节（易聚焦）           | 正三角写法：过去人穷→现在人富→所以广告让人消费。<br>倒三角改写：广告导致消费主义→消费欲望被经济+广告合力放大→过去资源匮乏无此欲望。                                                              |
| 抽象-具象交替                 | 每 1-2 句抽象句后必须跟 1 句具象句，防止“飘”。                               | 抽象：Materialism equates happiness with ownership.<br>具象：A TikTok star flashes a new iPhone and says “This is life!”                                                                         |
| 修辞升级（Diction Upgrade）   | 把口语化、低级词汇换成学术/抽象词汇。                                        | 口语：people have more money now<br>学术：economic prosperity / increased purchasing power                                                                                                       |
| 逻辑链缺口（Logical Gap）     | 任何因果之间若无桥梁，考官会认为“跳跃”。                                     | 跳跃：广告很美→人们就买了。<br>补缺口：广告用特效美化产品→观众把“美”与“高生活品质”关联→产生购买冲动。                                                                                            |
| 动词表现“思维转变”            | 用 show / reveal / indicate → demonstrate / underscore / cement              | 原：Ads tell people that…<br>升：Ads cement the belief that…                                                                                                                                     |
| 评分潜规则                    | 逻辑 > 词汇 > 语法；逻辑链完整即可 6.5-7。                                   | 词汇简单但逻辑顺：6.5；词汇华丽却跳跃：5.5。                                                                                                                                                     |

──────────────────────────────────  
二、段落示范：倒三角 + 抽象-具象交替  

```mermaid
%% 段内逻辑流程图（从上往下读=倒三角）
graph TD
    A[广告诱发物质主义] --> B[机制：把幸福与购买绑定]
    B --> C[绑定手段：名人+特效]
    C --> D[结果：价值观扭曲]
```

文字版  
1. Advertisements instill *materialism*—the belief that buying what appeals to us most is the shortest path to happiness.  
2. This association is forged the moment viewers see a celebrity holding the product and imagine their own lives becoming equally glamorous.  
3. To intensify this illusion, manufacturers employ celebrity endorsements and cinematic special effects, transforming an ordinary phone into a symbol of success.  
4. Gradually, consumers end up equating happiness with perpetual purchasing, thereby normalizing materialism.

──────────────────────────────────  
三、常见问题快速修正表  

| 问题症状                 | 诊断                 | 修改示例                                             |
| ------------------------ | -------------------- | ---------------------------------------------------- |
| 第一句就举例             | 正三角写法，重心后置 | 把“过去人穷”移到段落后半，段首先写“广告导致消费主义” |
| 主语频繁换               | 语句重心漂移         | 统一主语： Advertisements → They → Such strategies   |
| “people think” 重复 5 次 | 词汇单调             | people → individuals / consumers / the public        |
| “make people believe” ×3 | 动词弱               | instill / cement / reinforce the belief              |
| 缺逻辑桥                 | 因果跳跃             | 插入“beauty → higher living standard → desire” 三步  |

──────────────────────────────────  
四、课后 20 分钟练习建议  

1. 选题：Do ads make us materialistic?  
2. 结构：  
   - Intro：转述题干 + 立场（完全同意）  
   - Body1：倒三角阐述“广告如何把幸福与购买绑定”  
   - Body2：反方（广告也能传递有用信息）→ 让步+反驳  
   - Conclusion：重申立场 + 建议（媒体素养教育）  
3. 自查清单：  
   - [ ] 每段第一句是否给出 controlling idea？  
   - [ ] 抽象句后是否紧跟 1 句具象例子？  
   - [ ] 所有因果是否用“because / by / thus”显式连接？  
   - [ ] 是否用至少 3 个学术动词（cement, underscore, perpetuate）？  

把自查后的段落发回给老师或同学，互查逻辑链是否仍有“跳跃”。