# Day4-1: IELTS写作高分策略与词汇运用

## 课程核心知识点

### 1. 雅思考试经验分享

#### 1.1 考试地点与成绩关系
- **个人经历**: 所有8分成绩均在大陆(深圳)考取
- **误区澄清**: 不存在"压分"现象，关键在于真实水平
- **海外考试**: 澳洲考试三次均为7-7.5分

#### 1.2 成绩构成分析
| 考试类型 | 听力 | 阅读 | 写作 | 口语 | 总分 |
|---------|------|------|------|------|------|
| 最近一次 | 8.5  | 9.0  | 7.0  | 7.5  | 8.0  |
| 前一次   | 8.5  | 8.5  | 7.0  | 7.5  | 8.0  |

### 2. 词汇学习策略

#### 2.1 避免死记硬背
```mermaid
graph TD
    A[传统背单词] --> B[记住中文意思]
    B --> C[无法正确使用]
    C --> D[写作中出错]
    
    E[正确方法] --> F[学习搭配用法]
    F --> G[理解语境含义]
    G --> H[自然运用表达]
```

#### 2.2 Collocation学习法
- **定义**: 词汇的习惯性搭配
- **工具**: Just The Word网站查询
- **示例**:
  - ✅ efficient at doing something
  - ❌ efficient to do something

#### 2.3 常见错误分析
| 错误表达 | 正确表达 | 错误原因 |
|---------|----------|----------|
| learn knowledge | acquire knowledge | 搭配不当 |
| quality education | education focused on character development | 中式英语 |
| quality oriented | character-building | 误解词义 |

### 3. 语法检查工具

#### 3.1 Grammarly使用指南
- **功能**: 基础语法错误检测
- **局限**: 无法识别逻辑错误
- **示例**: 第三人称单数、时态错误

#### 3.2 LP错误识别
- **定义**: Logical Prediction错误
- **示例**: 
  - 错误: "When doing homework, the teacher is strict"
  - 正确: "When students do homework, the teacher is strict"

### 4. 写作评分标准解析

#### 4.1 评分维度
```mermaid
graph TD
    A[IELTS Writing] --> B[Task Response]
    A --> C[Coherence & Cohesion]
    A --> D[Lexical Resource]
    A --> E[Grammatical Range & Accuracy]
    
    B --> B1[审题准确性]
    C --> C1[逻辑连贯性]
    D --> D1[词汇多样性]
    E --> E1[语法准确性]
```

#### 4.2 分数段特征
- **5分**: 基本无法理解，语法错误严重
- **6分**: 可以理解，有语法错误但不影响理解
- **7分**: 几乎无语法错误，有一定复杂度
- **8分**: 极少错误，表达自然流畅

### 5. 实用工具推荐

#### 5.1 在线资源
- **Just The Word**: 查询词汇搭配
- **Grammarly**: 语法检查
- **剑桥词典**: 权威释义

#### 5.2 学习建议
1. **阅读原版材料**: 报纸、文章
2. **积累地道表达**: 记录常用搭配
3. **避免直译**: 理解英语思维
4. **反复接触**: 7次以上才能真正掌握

### 6. 写作技巧总结

#### 6.1 词汇运用原则
- 优先使用动词而非形容词
- 避免生僻词汇
- 注重语境适配

#### 6.2 例句对比
| 中式表达 | 地道表达 |
|---------|----------|
| make life more convenient | facilitate daily life |
| make people more happy | bring joy to people |
| make the environment better | improve environmental quality |

### 7. 练习建议

#### 7.1 每日任务
- 阅读一篇7分以上范文
- 记录10个地道搭配
- 仿写一段200字文章

#### 7.2 长期积累
- 建立个人语料库
- 定期复习巩固
- 模拟考试练习

---

**关键要点**: 词汇学习应注重搭配和语境，而非孤立记忆。通过大量阅读和模仿，逐步培养英语思维。