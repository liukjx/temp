# Day4-2: IELTS写作逻辑深化与错误分析

## 核心知识点框架

### 1. 写作评分逻辑解析

#### 1.1 评分标准深度解读
```mermaid
graph TD
    A[写作评分] --> B[逻辑与审题]
    A --> C[语言表达]
    
    B --> B1[论点明确性]
    B --> B2[论证合理性]
    B --> B3[结构完整性]
    
    C --> C1[语法准确性]
    C --> C2[词汇多样性]
    C --> C3[句式复杂度]
```

#### 1.2 分数段特征对比
| 分数 | 逻辑特征 | 语言特征 | 常见错误 |
|------|----------|----------|----------|
| 5.0 | 论点模糊 | 基础错误多 | 跑题严重 |
| 6.0 | 论点清晰 | 有语法错误 | 论证浅显 |
| 6.5 | 逻辑连贯 | 少量错误 | 深度不足 |
| 7.0 | 论证深入 | 几乎无误 | 细节完美 |

### 2. 常见逻辑错误类型

#### 2.1 主谓不一致(LP错误)
- **错误示例**: "Driving by computer might be positive improvement"
- **问题分析**: 
  - 主语应该是"cars driven by computers"或"autonomous driving"
  - "driving"不能作为"computer"的动作
- **正确表达**: "Self-driving vehicles might represent a positive improvement"

#### 2.2 比较级使用错误
- **错误示例**: "would be safer for both sides"
- **问题分析**:
  - 缺少比较对象
  - "both sides"指代不明
- **正确表达**: "would be safer than traditional human-driven cars"

#### 2.3 逻辑主语混乱
```mermaid
graph LR
    A[原句] --> B["When doing homework, the teacher is strict"]
    B --> C[错误: 谁在做作业?]
    
    D[修正] --> E["When students do homework, teachers are strict"]
    E --> F[正确: 主语明确]
```

### 3. 词汇搭配精讲

#### 3.1 介词搭配
| 形容词 | 正确介词 | 错误示例 | 正确示例 |
|--------|----------|----------|----------|
| efficient | at/in | efficient to do | efficient at managing |
| good | at | good in doing | good at swimming |
| capable | of | capable to do | capable of solving |

#### 3.2 动词搭配
- **pose a threat/challenge/problem** ✅
- **pose a danger/risk** ✅
- **pose a question** ✅

#### 3.3 名词搭配
- **traffic accidents** ✅ (not "traffic accident")
- **road safety** ✅ (not "road safeties")
- **driver negligence** ✅ (not "negligent driving")

### 4. 论证结构优化

#### 4.1 段落结构模板
```
主题句(论点) → 解释论证 → 具体例子 → 总结回扣
```

#### 4.2 论证层次递进
1. **表面现象**: 描述问题
2. **深层原因**: 分析本质
3. **具体影响**: 列举后果
4. **解决方案**: 提出建议

### 5. 典型错误案例分析

#### 5.1 自动驾驶主题
**学生原句**: "driving by computer might be positive improvement"

**错误分析**:
- 主谓搭配不当
- 缺少冠词
- 比较对象不明

**优化版本**:
```
Self-driving vehicles might represent a significant improvement 
in road safety compared to human-driven cars, as they eliminate 
the possibility of human error caused by fatigue or distraction.
```

#### 5.2 安全设备描述
**学生原句**: "without any safe device"

**优化表达**:
- **正确**: "without essential safety mechanisms"
- **更优**: "lacking critical safety features such as airbags and ABS"

### 6. 高级表达技巧

#### 6.1 抽象概念具体化
| 抽象概念 | 具体表达 |
|----------|----------|
| safety | passenger protection systems |
| efficiency | fuel consumption reduction |
| convenience | user-friendly interface |

#### 6.2 因果关系表达
- **原因**: due to, owing to, as a result of
- **结果**: lead to, result in, contribute to
- **目的**: in order to, so as to, with the aim of

### 7. 实战应用建议

#### 7.1 写作检查清单
- [ ] 主谓是否一致
- [ ] 比较对象是否明确
- [ ] 介词搭配是否正确
- [ ] 逻辑是否连贯
- [ ] 词汇是否地道

#### 7.2 提分策略
1. **诊断错误**: 识别个人常犯错误类型
2. **专项训练**: 针对薄弱点强化练习
3. **范文模仿**: 学习7分以上范文表达
4. **定期回顾**: 建立错题本并定期复习

### 8. 语言自然度提升

#### 8.1 避免中式英语
| 中式表达 | 自然表达 |
|---------|----------|
| very important significance | great importance |
| make great progress | make significant strides |
| pay attention to | focus on |

#### 8.2 句式多样化
- **简单句**: 主谓宾结构
- **复合句**: 主从复合结构
- **强调句**: It is...that...结构
- **倒装句**: 强调重点信息

---

**核心要点**: 写作高分的关键在于逻辑清晰、表达准确、语言自然。通过系统分析错误类型，针对性训练，可以显著提升写作水平。