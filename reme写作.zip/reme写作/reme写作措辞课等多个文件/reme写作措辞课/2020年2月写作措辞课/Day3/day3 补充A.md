以下内容将「day3 补充A.txt」中所有口语化、跳跃式的课堂实录，系统地拆分为 8 组可复用的写作知识点，并配解释、示例与训练建议。  

---

### 一、雅思大作文审题的「两步定位法」
| 步骤           | 操作                                                         | 目的                                                  | 示例（2015 真题）                                                                                     |
| -------------- | ------------------------------------------------------------ | ----------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| ① 本质 or 影响 | 看题干是否给出「因果 / 对比 / 最高级 / 条件 / 否定」等逻辑词 | 决定文章主论点：是「定义-分类-匹配」还是「结果-利弊」 | Some people think that young people can also be leaders → 本质是“young people 是否具备 leader 的特质” |
| ② 性价比评估   | 判断写「本质」与「影响」哪一个自己词汇、论证更从容           | 避免写不擅长的抽象度                                  | 同题：若对 leadership virtues 词汇量大，可写本质；若擅长举例，可写影响                                |

---

### 二、线性逻辑 VS 非线性逻辑
| 类型   | 定义                           | 风险               | 升级方法                                           |
| ------ | ------------------------------ | ------------------ | -------------------------------------------------- |
| 线性   | a→b→c 单链因果                 | 考官认为“重心偏移” | 在 a→b 段中预埋 “meaning that …c” 的暗示，保持主线 |
| 非线性 | 多条因果、对比、让步、条件并行 | 容易跑题           | 用 controlling idea 反复锚定（见知识点三）         |

---

### 三、Controlling Idea 的「三步锚定」
1. 显性改写题干：把题干改成一个 Why/Whether 问句。  
   例：Whether young people possess the virtues required of a leader.  
2. 全文同义反复：每段首句用不同词性复述该 idea。  
3. 段内回扣：举例后立刻用 “This exactly shows that …(controlling idea)” 强制回扣。

---

### 四、段落展开「双具象化」模型
```mermaid
graph TD
    A[段落主题：Young people can make the tough call] --> B[抽象定义: the ability to take calculated risks under uncertainty]
    B --> C[语境化例子: 25 岁产品经理在预算腰斩时砍掉低 ROI 功能]
    C --> D[回扣: This instance illustrates that young leaders can indeed make the tough call when stakes are high.]
```

---

### 五、抽象词汇库：Leadership Virtues
| 短语级表达                                  | 避坑提示            | 场景示例                                                                                                                       |
| ------------------------------------------- | ------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| make the tough call                         | 不要只说 “decision” | When the team was split between two incompatible designs, the 28-year-old CTO made the tough call to scrap six months of work. |
| resilience – bounce back from failures      | 需要具体失败情境    | After the crowdfunding campaign flopped, she demonstrated resilience by pivoting to B2B within two weeks.                      |
| skills in management ≠ management knowledge | 用 “skills in” 短语 | His skills in management include delegating micro-tasks without micromanaging.                                                 |
| emotionally stable / temperance             | 用反例刻画          | Unlike more volatile peers, he rarely vents frustration publicly, keeping the team climate steady.                             |

---

### 六、避免“重心偏移”的 2 个小技巧
| 技巧     | 操作                                                           | 模板                                                                                                                                                      |
| -------- | -------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 预埋伏笔 | 在 a→b 例子末尾加一句 “…, thereby laying the groundwork for c” | “By launching small-scale pilot tests, she not only curbs financial risk (a→b) but, more importantly, accumulates data for a company-wide rollout (b→c).” |
| 段尾回扣 | 用一句话把 a-b-c 串回 controlling idea                         | “Therefore, these two episodes jointly refute the stereotype that young people lack the **strategic composure** required of a leader.”                    |

---

### 七、题型快速判别表
| 题干关键词                       | 推荐主攻方向     | 示范破题                                   |
| -------------------------------- | ---------------- | ------------------------------------------ |
| to what extent do you agree      | 本质（匹配特质） | 先列 3 virtues，再逐条匹配 young/old       |
| discuss both views               | 影响（利弊比较） | 一方写“控制噪音的好处”，一方写“自由的坏处” |
| what are the reasons & solutions | 因果链 + 建议    | 噪音→健康风险→立法/技术降噪                |

---

### 八、从托福到雅思的思维转换
| 维度     | 托福                           | 雅思                      |
| -------- | ------------------------------ | ------------------------- |
| 论证核心 | 例子堆叠                       | 抽象概念链                |
| 模板容忍 | 高（ETS 现用 Turn-it-in 查重） | 低（需同义替换+逻辑深度） |
| 段落结构 | 故事→总结                      | 定义→分类→匹配/对比       |

---

### 课后训练建议
1. 审题 5-min Drill  
   随机抽取 5 道真题，限时 5 分钟完成「两步定位法」并写下 controlling idea。  
2. 词汇升级卡  
   把常见“万能词” (decision, communication) 写成短语卡，每天抽 3 张造句。  
3. 段落双盲测试  
   同学 A 给出抽象论点，同学 B 10 分钟内完成“双具象化”例子并回扣；互换角色。