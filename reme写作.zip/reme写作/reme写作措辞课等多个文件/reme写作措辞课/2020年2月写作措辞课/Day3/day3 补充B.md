雅思写作 Day3 答疑课  
系统梳理 & 备考建议  
（基于语音转文字稿）

────────────────────────────  
一、题型两分法：本质题 vs 影响题  
────────────────────────────  
| 维度 | 本质题（Essence） | 影响题（Impact） |  
|------|------------------|------------------|  
| 题干特征 | 含因果、对比、最高级、假设、前提等「逻辑链」 | 描述现象/动作，问「原因」「利弊」「程度」 |  
| 命题动词 | agree/disagree, to what extent, why | advantages outweigh disadvantages, what are the causes/effects |  
| 写作任务 | 验证或反驳题干里的逻辑是否成立 | 列举并分析利弊或因果 |  
| 典型问法示例 | The best way to reduce traffic is to provide free public transport 24/7. | With increasing demand for energy, people start to drill in remote areas. Do the advantages outweigh the disadvantages? |  
| 高分关键 | 拆解逻辑链 XYZ；证明成立 or 不成立 | 具象化好处/坏处；避免万能观点 |  

快速判断流程  
```mermaid
graph TD
A[读题干] --> B{题干是否含逻辑链?}
B -->|是| C[本质题：拆XY→Z]
B -->|否| D[影响题：找利弊/因果]
```

────────────────────────────  
二、段落结构：核心原则  
────────────────────────────  
1. 段数不限  
   • 考官只看「每段第一句是否为中心句」，后面所有句子是否围绕第一句展开。  
   • 4 段 or 5 段均可；形式不重要。  

2. 由抽象到具象的“剥洋葱”写法  
   中心句（抽象） → 次抽象（含部分具象） → 再次抽象 → 纯具象（例子/数据/情景）。  
   例：  
   中心句：Free public transport is not the best solution to congestion.  
   次抽象：Because it tackles only the symptom—vehicle numbers—rather than the root cause.  
   再次抽象：The root cause lies in urban planning that separates residential and commercial zones.  
   具象化：In Beijing’s Huilongguan, despite 24-hour subway service, traffic persists because 80 % residents commute 30 km to IT parks.  

────────────────────────────  
三、语言细节高频提醒  
────────────────────────────  
| 误区 | 纠正示例 |  
|---|---|  
| 万能观点（broaden horizons） | 改为“gain region-specific culinary techniques”等具体结果 |  
| 短语堆砌 | 用上位词：people between 80-89 → octogenarian |  
| 字数焦虑 | 500 词亦可，只要每句服务中心；但能用一词表达就别用三词。 |  

────────────────────────────  
四、实战建议（按提分路径）  
────────────────────────────  
1. 目标 6.5  
   • 锁定影响题写法：好处/坏处各一段，具象化即可，无需挑战本质。  

2. 目标 7.5+  
   • 识别本质题，用“逻辑拆链”模板：  
     – 题干：X → Y（导致）  
     – Body1：X 未必 → Y（反驳或限定）  
     – Body2：即使 X→Y，也不是“最”…（回应最高级）  

3. 素材积累  
   • 犯罪类：量刑程度取决于①罪行严重性②是否蓄意③是否知法。  
   • 教育类：compulsory 课程需两层论证：重要性＋必要性。  

4. 复习节奏  
   • 本周：把 2014-2018 真题按“本质/影响”分类，每类写 2 篇精修。  
   • 每日微信打卡：@老师 1 个题目＋你的中心句，老师回“逻辑是否成立”。  

────────────────────────────  
五、一分钟速查表（打印贴墙）  
────────────────────────────  
看到题目先问：  
1. 题干里有没有逻辑词？  
2. 没有→影响题→列利弊。  
3. 有→本质题→拆 XYZ。  
4. 每段第一句＝中心句，后面每句证明它。  
5. 例子要“此题专属”，杜绝 broaden horizons。  

祝写作提分！