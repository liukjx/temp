这份长达 1.5 万字的课堂转写稿，实质是老师带着学生围绕「雅思大作文 XY 型 vs XYZ 型」做的一场思维演练。  
下面用「知识点 → 解释 → 例子」的三栏表格，把全部关键内容重新梳理，并给出可直接落地的写作建议。  

---

### 1. 两种题型结构总览  

| 题型          | 解释                                                                                                   | 例子                                                                                                   |
| ------------- | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------ |
| XY（2 点式）  | 题干只给「一个现象 / 一个观点」，考生只需回答「我是否同意」并给 2 个理由即可。                         | “AI will replace many human jobs. Do you agree or disagree?”                                           |
| XYZ（3 点式） | 题干包含「X-Y-Z 三个概念」，考生需找出 X 与 Y 的共同点 Z，并论证「因为具备 Z，所以 X 与 Y 同等重要」。 | “Writing, reading and math are 3 recognized subjects; computer skill should be the 4th. Do you agree?” |

---

### 2. 题干关键词拆解模板  

| 关键词                   | 作用                           | 常见陷阱                                          |
| ------------------------ | ------------------------------ | ------------------------------------------------- |
| recognized / traditional | 只是背景信息，**不是限制条件** | 不要纠结“traditional 是否包括 computer”，忽略即可 |
| should be                | 观点动词，**必须回应**         | 必须表态 agree / disagree，不能中立               |

---

### 3. 段落分配（通用骨架）  

```mermaid
%% 雅思 Task 2 骨架（XYZ 型）
graph TD
   A[Para 1 引入+表态] --> B[Para 2 定义 X & Y 的共同特质 Z]
   B --> C[Para 3 论证 computer skill 也具备 Z]
   C --> D[Para 4 结论重申]
```

| 段落       | 写作任务                                                 | 常用句型                                                                                                                   |
| ---------- | -------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| Intro      | 改写题干 + 明确表态                                      | “While some may argue …, I believe …”                                                                                      |
| Body 1     | 定义 Z：解释为什么 writing/reading/math 能并称“传统三科” | “The three subjects share a defining feature: they are **fundamental survival tools** for modern citizens.”                |
| Body 2     | 证明 computer skill 也符合 Z                             | “Likewise, knowing how to operate computers has become a **daily survival skill**, from sending emails to analyzing data.” |
| Conclusion | 重申立场                                                 | “Therefore, recognizing computer skill as the fourth pillar is a logical move.”                                            |

---

### 4. 高频西方思维三维度  

| 维度          | 定义                           | 举例                                                                    |
| ------------- | ------------------------------ | ----------------------------------------------------------------------- |
| Efficiency    | **单位时间产出更多**且质量不变 | 新药 A 两天治愈 100%，药 B 七天治愈 100%，A 更高效                      |
| Effectiveness | **最终效果百分比**             | 药 A 两天治好 70%，药 B 七天治好 100%，B 更有效                         |
| Economy       | **投入-产出比**                | 雇佣员工 A 成本高但服务好，B 成本低但差评多；高端餐厅选 A，街边快餐选 B |

> 提示：写作时把这 3E 当作“万能理由库”，任何科技 / 教育 / 工作话题都能套用。

---

### 5. 语言技巧 5 连击  

| 技巧         | 解释                                     | 模板                                                                                                             |
| ------------ | ---------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| 定义前置     | 在首段或 Body 1 给关键词下定义，避免歧义 | “For the sake of simplicity, computer skills here refer to the ability to operate common software and hardware.” |
| 同位语压缩   | 把次要信息塞进同位语，不抢占主句         | “Given that computer literacy has become a survival skill, it deserves equal curricular status.”                 |
| 抽象→具体    | 先给抽象论点，再补 1-2 句具体场景        | “Using a spreadsheet to budget monthly expenses is one such daily example.”                                      |
| 对比论证     | 用 A vs B 量化差异                       | “A clerk who masters Excel can finish the report in 2 hours, whereas one who does not may spend a whole day.”    |
| 防止线性思维 | 避免“因为 A→所以 B→必然 C”的绝对化       | 加入条件句： “This is **often** the case, **provided that** proper training is available.”                       |

---

### 6. 写作建议（可直接执行）

1. 选题  
   - 若题干只有 1 个现象 → 用 **XY 两点式**（易写但难高分）。  
   - 若题干出现类比 / 并列 → 用 **XYZ 三点式**（易冲 7+）。

2. 思维路径  
   1. 先快速把题干拆成 X-Y-Z。  
   2. 用「三维度卡片」列出 2-3 条西方主流理由（Efficiency, Effectiveness, Economy）。  
   3. 把最硬的 2 条写成主题句，后面各补 1 个具体例子。

3. 时间分配（40 分钟）  
   | 阶段      | 时间   | 任务                    |
   | --------- | ------ | ----------------------- |
   | 审题+大纲 | 5 min  | 画 X-Y-Z，写 2 个主题句 |
   | 写作      | 30 min | 按骨架填充              |
   | 检查      | 5 min  | 专挑动词时态 & 拼写     |

4. 常见失分点  
   - 把 background 信息当限制条件 → 导致跑题。  
   - 用中文直译英文 → 出现 “outcomp” 这类不存在的词。  
   - 只写“computer is important” → 缺少 Z 的论证，TR 卡在 6。

---

### 7. 一页速查表（考前 2 分钟）

| 题型 | 表态句                                                           | 万能理由                                                     | 收尾句                                                     |
| ---- | ---------------------------------------------------------------- | ------------------------------------------------------------ | ---------------------------------------------------------- |
| XY   | “I firmly believe that …”                                        | Efficiency / Effectiveness / Economy                         | “In light of the above, I restate my position that …”      |
| XYZ  | “This essay will argue that X and Y share the feature Z, thus …” | “a daily survival skill” / “a prerequisite for civilization” | “Hence, equating X with Y is both logical and inevitable.” |

---

把这张速查表打印出来贴书桌，配合以上骨架模板，任何“computer skill”类题目都能 10 分钟内搭好框架，30 分钟完成全文。