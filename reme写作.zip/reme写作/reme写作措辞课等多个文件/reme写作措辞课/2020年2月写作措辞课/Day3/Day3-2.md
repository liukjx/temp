课程主题  
外国人（特别是商学院/学术写作）在分析任何议题时，最关心的四个关键词：  
Efficiency ‑ Effectiveness ‑ Economy ‑ Positive/Negative Impact  
并用“具象化动词”把抽象概念落到可操作的细节上。

────────────────────────────  
一、四大核心概念  
| 关键词              | 中文            | 关键问题                           | 例子（以自动驾驶为例）                               |
| ------------------- | --------------- | ---------------------------------- | ---------------------------------------------------- |
| Efficiency          | 效率            | 单位投入→最大产出                  | 电脑驾驶省燃油、缩短通勤时间、减少拥堵               |
| Effectiveness       | 有效性          | 目标达成度                         | 把人安全地从 A 运到 B 且体验良好                     |
| Economy             | 性价比/成本效益 | 投入资源（钱、时间、人力）是否划算 | 省燃油费、减少司机人力成本、降低事故保险支出         |
| Positive / Negative | 正面/负面       | 是否带来副作用或可抵消的负面       | Positive：减少事故；Negative：黑客攻击、驾驶乐趣缺失 |

────────────────────────────  
二、“具象化动词”工具箱  
把宏观议题拆成可操作的动词链，写作/口语立刻有细节。  

```mermaid
graph TD
    A[坏事发生] -->|Prevent| B[预防]
    A -->|Alleviate| C[减轻]
    A -->|Stop / Cease| D[终止]
    A -->|Reverse| E[逆转损害]

    B --> B1[疫苗研发]
    C --> C1[封城隔离]
    D --> D1[Kill-virus药物]
    E --> E1[干细胞修复肺纤维化]
```

举例：  
• Prevent: 新生儿接种疫苗 → 病毒根本爆发不起来  
• Alleviate: 疫情期间戴口罩、消毒 → 降低传染速度  
• Stop/Cease: 找到病毒源头并切断传播链  
• Reverse: 干细胞疗法让肺纤维化患者恢复功能（轻症可以，重症不行）

写作句型模板  
“In order to **alleviate** the spread of COVID-19, governments **enforced** city-wide quarantine and **mandated** mask-wearing in public areas.”

────────────────────────────  
三、议题分析万能流程  
1. 先列标签（列出事物所有属性）  
   drug A：2 天、70 % 治愈率、$2/粒、需 100 人  
   drug B：7 天、100 % 治愈率、$6/粒、需 30 人+自动化  
2. 套四问  
   • Efficiency：谁更快/更省人力？  
   • Effectiveness：治愈率高不高？  
   • Economy：每治愈一人总成本多少？  
   • Positive/Negative：副作用？可逆转后遗症？  
3. 做决策/写立场  
   疫情初期缺人手 → 先产 drug A；后期有产能 → 转 drug B。

────────────────────────────  
四、本次作业框架（仅围绕“安全”维度）  
题目：Scientists believe future cars will be driven by computer, not people. Positive or negative?  
要求：只写两段 body paragraph，一段写“更安全”，一段写“更不安全”。  

Body 1 思路（safer）  
• Prevent human errors（酒驾、疲劳、路怒）  
• Alleviate accident severity（AI 0.1 秒刹车）  
• 24/7 传感器 → Stop collision before it happens  

Body 2 思路（not safe）  
• Hacker attack → Cease all traffic / Cause crashes  
• Software bug → Cannot reverse deadly decision in milliseconds  
• Sensor failure in extreme weather → Negative impact amplified

写作技巧  
1. 每段至少出现 2 个具象化动词：prevent, alleviate, stop, reverse…  
2. 数据 + 场景：  
   “According to the U.S. NHTSA, 94 % of serious crashes involve human error. If AI can prevent even half of them, tens of thousands of lives would be saved annually.”  
3. 结尾加一句 cost-efficiency 回扣 economy：  
   “Beyond saving lives, fewer crashes mean lower insurance and medical costs—an economic bonus.”

────────────────────────────  
五、学习建议  
1. 日常训练  
   拿任何热点新闻，先列标签，再套“四问”，用动词链写 3-5 句 summary。  
2. 口语/写作模板化  
   把今天的“prevent → alleviate → stop → reverse”做成四张卡片，随时抽取。  
3. 跨情境复用  
   今天练自动驾驶，明天换“远程办公”、“基因编辑”仍用同一套逻辑维度，只替换情境词即可。