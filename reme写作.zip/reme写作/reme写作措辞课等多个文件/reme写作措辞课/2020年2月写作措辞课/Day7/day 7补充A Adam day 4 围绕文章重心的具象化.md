## 📚 课程总结：如何围绕「文章重心」进行具象化写作  
（基于 Adam Day 7 语音稿）

---

### 1️⃣ 核心问题定位
| 问题类型       | 具体表现                                                 | 课程示例                       |
| -------------- | -------------------------------------------------------- | ------------------------------ |
| **语言不地道** | 自创搭配（如 *regular readers*）                         | 用 **avid readers** 替代       |
| **抽象词堆砌** | *imagination skills* / *superficial ideas*               | 改为 **具象化表达**（见第3节） |
| **逻辑断层**   | *different ways of information are presented* 与主旨无关 | 改为 **因果链**（见第4节）     |

---

### 2️⃣ 语言准确性：避免「伪同义词」
| 错误表达                | 修正                                 | 原因                                               |
| ----------------------- | ------------------------------------ | -------------------------------------------------- |
| *regular TV viewers*    | people who **watch TV frequently**   | *regular* 仅用于固定搭配（如 *regular customers*） |
| *encourage imagination* | **cultivate the ability to imagine** | *encourage* 需接不定式（*encourage sb to do*）     |

---

### 3️⃣ 具象化技巧：从抽象到画面
#### 🎯 三步法
1. **定位抽象词**  
   *superficial ideas* → 具体指什么？
2. **追问细节**  
   - 如何表现「浅显」？  
   - 通过「角色动作」而非「复杂语言」。
3. **重构句子**  
   **原句**：TV ideas are superficial.  
   **具象化**：  
   > *Higher-order thinking must be **deduced from characters’ actions**, not directly presented through **uncommon lexis**.*

#### 🎨 对比案例
| 抽象表达                           | 具象化改写                                                              |
| ---------------------------------- | ----------------------------------------------------------------------- |
| *imagination skills*               | the **ability to imagine things that never existed**                    |
| *mental pictures of the situation* | **mental pictures of what is happening to the characters in the story** |

---

### 4️⃣ 逻辑链构建：因果+对比
#### 📌 模板：「A > B 因为…」
**阅读 vs 电视**  
> *Reading cultivates imagination **more than TV does**, because novels **force readers to conjure images**, while TV **provides ready-made visuals**.*

#### 🔍 语言发展对比
| 维度         | 阅读               | 电视             |
| ------------ | ------------------ | ---------------- |
| **语言输入** | 复杂句式、生僻词汇 | 简短对话、高频词 |
| **思维层次** | 需推断抽象观点     | 直接呈现动作行为 |
| **输出能力** | 可复制作者表达方式 | 受限于简单语言   |

---

### 5️⃣ 流程图：如何检查抽象表达
```mermaid
graph TD
A[遇到抽象词] --> B{能否用五感描述?}
B -->|是| C[保留]
B -->|否| D[追问: 具体指什么?]
D --> E[替换为画面/动作]
E --> F[重构句子]
```

---

### 6️⃣ 实战建议
#### ✍️ 修改步骤
1. **划抽象词**：如 *complex ideas*, *language skills*。
2. **追问细节**：  
   - *complex ideas* → 具体是「哲学观点」还是「科学理论」？  
   - *language skills* → 指「学术词汇」还是「修辞手法」？
3. **替换表达**：  
   - *TV fails to develop language skills* →  
     *TV dialogues are too short to expose viewers to **elaborate syntax**.*

#### 🚫 禁止清单
- ❌ 自创搭配（*regular readers*）  
- ❌ 空洞形容词（*superficial* 无解释）  
- ❌ 逻辑跳跃（*different ways → imagination* 无因果）

---

### 7️⃣ 最终范例段落
> **原版**：  
> *Reading is better than TV because it gives complex ideas.*  
> **具象化版**：  
> *Unlike TV’s rapid-fire dialogues, books **embed philosophical debates in layered prose**, forcing readers to **decode metaphors** and **trace logical threads**—skills that **transfer to articulate speech**.*

---

### 📌 一句话总结  
**用「画面」替代「形容词」，用「因果链」替代「并列句」**——这是6.5→7+ 的关键。