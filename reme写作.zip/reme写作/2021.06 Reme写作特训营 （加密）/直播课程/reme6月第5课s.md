---

# 📘 课程文字稿系统梳理  
**主题：雅思写作 Task 2 – “跑题式”思维训练与高分表达**

---

## 1️⃣ 课程目标与方法论

| 关键词              | 解释                                                                                                | 课堂原句/例子                                                     |
| ------------------- | --------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------- |
| 跑题                | 以具体话题为切入口，边“跑题”边把地道表达、句型、观点“偷偷塞”给学生，再让学生自己 structure 成文章。 | “边跑题边把表达偷偷塞给你们，最后你们自己把它 structure 成文章。” |
| 具象化              | 把抽象概念用具体细节、场景、数字、例子表现出来。                                                    | “不要只说中年人失业，而要列出房贷、车贷、孩子学费、老人医疗费。”  |
| 心理具象 → 动作具象 | 先写出人们“心里怎么想”，再写“因此会怎么做/受到怎样的对待”。                                         | “人们觉得老人慢 → 因此公司不给加班 → 老人收入更低。”              |

---

## 2️⃣ 高频话题深度拆解

### 🧩 A 老龄化与就业竞争

| 子话题             | 可写 problem                                 | 高分表达 & 例子                                                                                       |
| ------------------ | -------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| 经济负担           | 中年人一旦失业，现金流断裂                   | housing & car mortgage, children’s tuition, elderly care, critical illness insurance (≈ ¥30k–100k/年) |
| AGEISM（年龄歧视） | stereotype → unfair treatment                | “fossilized thinking”, “can’t stand OT”, “unlikely to get promoted”, “menial service positions”       |
| 代际矛盾           | 年轻人觉得老人“抢饭碗”                       | “Why don’t you just retire and free up the seat?”                                                     |
| 解决路径           | 1) robust welfare system 2) 承认无法根除歧视 | 见下节                                                                                                |

---

### 💰 B “Robust Welfare System” 写作模板

| 维度             | 解释                                                           | 高分词汇/短语                                    |
| ---------------- | -------------------------------------------------------------- | ------------------------------------------------ |
| Sustainable      | 长期财政可负担；帮助人们重新成为 functional members of society | “help-out-until-self-reliant”                    |
| Selective / Fair | 只帮助真正需要的人；设门槛防滥用                               | “filter out anyone who tries to scam the system” |
| Comprehensive    | 多种形式：cash, food coupons, retraining vouchers              | “a mix of cash transfers and in-kind benefits”   |

**Mermaid 流程图：福利金发放原则**
```mermaid
graph TD
    A[申请福利] --> B{资格审查}
    B -->|符合条件| C[发放：现金/券/培训]
    B -->|不符/欺诈| D[拒绝并记录黑名单]
    C --> E[定期复审]
    E -->|已自立| F[停止福利]
    E -->|仍困难| C
```

---

### 🏆 C 教育类话题：reward the best vs reward improvement

| 立场                 | 背后逻辑                                                                      | 课堂关键词                                            |
| -------------------- | ----------------------------------------------------------------------------- | ----------------------------------------------------- |
| Reward the best only | 1) Create a competitive environment <br>2) Motivate all to strive for the top | “competitive paradigm”, “KPI-driven in Asian schools” |
| Reward improvement   | 1) No child left behind <br>2) Raise the whole “bottom line”                  | “socialist mindset”, “egalitarian approach”           |

**注意**  
- 考官要看到的是“**why they think so**”，而不是简单罗列利弊。  
- 两个观点本质对立：资本主义精英筛选 vs 社会主义兜底提升。

---

## 3️⃣ 高分表达/词组清单

| 词组/短语                 | 用法示例                                                                                           |
| ------------------------- | -------------------------------------------------------------------------------------------------- |
| detrimental to …          | Falling into unemployment at mid-age is **detrimental to** both the individual and the family.     |
| fossilized thinking       | Employers often equate older workers with **fossilized thinking**.                                 |
| menial service positions  | Retirees can only find **menial service positions** such as supermarket cashiers.                  |
| robust welfare system     | Only a **robust, selective and sustainable welfare system** can cushion the shock of unemployment. |
| deeply seated / hardwired | Ageism is **deeply seated**; education alone can hardly uproot it.                                 |
| no child left behind      | Rewarding improvement aligns with the **“no child left behind”** philosophy.                       |

---

## 4️⃣ 实战写作建议（Checklist）

| 步骤       | 操作                                              | 课堂金句                                                        |
| ---------- | ------------------------------------------------- | --------------------------------------------------------------- |
| ① 审题     | 划出 **what problem has this caused?** 的因果链   | “逻辑上最准确：it will **exacerbate** already existing ageism.” |
| ② 具象化   | 把“失业”拆成房贷、学费、保险、养老                | “不要只写unemployment，要写四张账单。”                          |
| ③ 结构     | Problem → Cause (ageism) → Examples → Solution    | “先列惨状，再点出歧视，再给例子，最后承认无解。”                |
| ④ 对立观点 | 教育奖励题：用 **“capitalism vs socialism”** 框架 | “考官一眼看出：这是精英 vs 兜底的两套价值观。”                  |
| ⑤ 语言     | 用话题词+地道搭配                                 | “vehicle mortgage ❌ car mortgage ✅”                             |

---

## 5️⃣ 课后任务（老师布置）

1. 任选老龄化或教育奖励题，写一段 **150 词** 的 body paragraph。  
2. 要求包含：  
   - 至少 2 个具象化细节  
   - 至少 1 个高分短语（见第 3️⃣ 节）  
   - 结尾承认问题难以彻底解决（参考第 4️⃣-④）

> “写完后自查：有没有把考官当傻子只写 ‘unemployment is bad’？如果没有，你就及格了。”