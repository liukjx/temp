# 2021年6月写作特训营 Day 2 - 雅思写作逻辑与结构分析

## 课程主题：论证逻辑与段落结构深度解析

### 🎯 核心教学目标
本节课通过分析学生作文，重点解决三大核心写作问题：
1. **论证逻辑缺陷** - 因果链条断裂与逻辑跳跃
2. **主次信息颠倒** - 具体细节与核心观点的错位
3. **线性思维局限** - 缺乏层次化的论证结构

---

## 📊 作文题目回顾
**题目**："Government should control the amount of violence in films and on television in order to reduce violent crime in society." 

**核心要求**：分析政府控制媒体暴力内容是否能有效降低社会暴力犯罪率

---

## 🔍 典型问题分析与解决方案

### 问题1：因果逻辑缺陷

#### ❌ 错误案例展示
```
原句："controlling these views and tv programs... since it is difficult for people 
who have the intention of committing the violent crime to access their relevant information"
```

#### 📋 逻辑漏洞分析
| 错误类型 | 具体表现 | 改进策略 |
|---------|----------|----------|
| **因果断裂** | 控制媒体→减少犯罪信息→降低犯罪率 | 缺乏中间论证环节 |
| **假设错误** | 认为犯罪者主要通过电视获取犯罪信息 | 忽略其他信息渠道 |
| **过度简化** | 将复杂犯罪动机单一归因 | 未考虑心理、社会等多重因素 |

#### ✅ 正确逻辑链
```mermaid
graph TD
    A[控制媒体暴力内容] --> B[减少特定人群接触频次]
    B --> C[降低模仿性犯罪概率]
    C --> D[对易感人群产生保护效果]
    D --> E[社会层面暴力犯罪率可能下降]
    
    style A fill:#f9f,stroke:#333
    style E fill:#9f9,stroke:#333
```

### 问题2：主次信息颠倒

#### ❌ 典型错误结构
```
错误模式：
1. 青少年占观众比例大
2. 青少年缺乏法律知识
3. 青少年容易模仿
4. 因此控制媒体暴力能降低犯罪
```

#### ✅ 正确信息层级

| 信息类型 | 角色定位 | 表达方式 |
|---------|----------|----------|
| **核心观点** | 主要论点 | 主句呈现 |
| **群体特征** | 支撑论据 | 从句或修饰语 |
| **数据事实** | 辅助论证 | 插入语或例证 |

#### 📝 改写示例
**错误版本**：
> "Teenagers account for a large proportion of audiences... teenagers have two characteristics..."

**正确版本**：
> "The effectiveness of media violence control largely depends on its impact on vulnerable groups, *particularly teenagers who lack mature judgment and are prone to imitation due to their developmental stage*."

### 问题3：线性思维局限

#### ❌ 线性思维特征
```
暴力画面展示 → 观众产生暴力想法 → 暴力想法导致犯罪行为 → 犯罪率上升
```

#### ✅ 立体化论证结构

```mermaid
graph LR
    A[媒体暴力内容] --> B{观众反应}
    B --> C[大多数人：厌恶/无影响]
    B --> D[易感人群：潜在影响]
    D --> E[已有犯罪倾向者]
    D --> F[价值观未成熟者]
    E --> G[可能触发犯罪行为]
    F --> H[可能产生模仿行为]
    
    I[社会环境因素] --> G
    I --> H
    J[个人心理背景] --> G
    J --> H
```

---

## 🎯 高分作文结构模板

### 段落1：观点陈述+核心论证
**模板**：
```
While [承认表面关联], the correlation between [媒体暴力] and [实际犯罪率] is largely superficial. 
The root causes of violent crime lie in [社会结构问题], [经济不平等], and [教育缺失], 
rather than media representation itself.
```

### 段落2：分层论证
**模板**：
```
Admittedly, exposure to violent media may influence [特定人群], particularly those who 
already exhibit [predisposing factors]. However, for the general population, 
the impact is minimal compared to [更直接的社会因素].
```

---

## 🔧 语言精炼技巧

### 常见Chinglish修正
| 错误表达 | 地道表达 | 说明 |
|---------|----------|------|
| "lack legal knowledge" | "lack moral discernment" | 准确表达判断对错的能力 |
| "vent their steam" | "act out aggressively" | 更符合英语习惯 |
| "easily irritated" | "emotionally volatile" | 更精准的学术表达 |

### 逻辑连接词升级
- **因果关系**: 不只是"because"，使用"stem from", "be attributed to", "arise from"
- **对比关系**: 除了"but"，使用"whereas", "in contrast", "conversely"
- **让步关系**: 用"while acknowledging...", "despite the perception that..."

---

## 📈 评分标准解读

### TR (Task Response) 7分要求
```
✅ 直接回应题目要求
✅ 论证有深度和层次
✅ 观点清晰且一贯
✅ 有效使用例证支撑
❌ 避免跑题或偏题
```

### 常见失分点预警
1. **5分以下特征**：
   - 大量清单式写作
   - 主次信息颠倒
   - 逻辑链条断裂
   - 频繁跑题

2. **6-6.5分特征**：
   - 有基本逻辑结构
   - 主次相对分明
   - 语言有一定准确性
   - 论证深度不足

3. **7分以上特征**：
   - 主次信息精准区分
   - 多层次论证
   - 语言表达精准
   - 深度社会洞察

---

## 📝 课后练习指导

### 作业要求：
1. **题目分析**：为每个题目写出最稳的controlling idea
2. **结构规划**：明确body1和body2的论证布局
3. **主次区分**：标注每段的主次信息层次

### 自我检查清单：
- [ ] 我的核心观点是否直接回应题目？
- [ ] 主次信息是否区分清晰？
- [ ] 论证是否有深度而非简单罗列？
- [ ] 是否避免了线性思维陷阱？
- [ ] 语言表达是否精准专业？

### 下节课预告：
- 题目controlling idea稳定输出
- 段落重心精准定位
- 句子级别的逻辑优化

---

**关键提醒**：
> 写作的核心不是展示你"知道什么"，而是展示你如何"组织已知信息来有效论证观点"。避免知识堆砌，追求论证深度。