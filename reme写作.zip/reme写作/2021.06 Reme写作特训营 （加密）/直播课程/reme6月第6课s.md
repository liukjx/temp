课程主题：雅思/托福写作精修课  
讲师：未具名（以下简称“老师”）  
时间：2025-06 第6课  
文件：reme6月第6课s.txt  

——————————————————  
一、课程总览（Mermaid 思维导图）
```mermaid
mindmap
  root((写作精修课))
    目标
      7→8分
      具象化+逻辑链
    流程
      1. 审题立意
      2. 搭建Controlling Idea
      3. 具象化机制
      4. 语言打磨(语法/词汇/衔接)
    高频问题
      清单式写作
      句子重心错位
      指代不清(it/they)
      伪科学/逻辑跳跃
    工具箱
      语法录播
      PDF练习包
```

——————————————————  
二、知识点系统梳理  

| 编号 | 知识点                | 解释 & 示例                                                                                                                                                               | 课堂原话 / 备注                                                              |
| ---- | --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| 1    | Controlling Idea (CI) | 段内唯一核心论点，所有句子围绕它展开。 <br>例：CI=“Noise causes mental illness” → 下文只能解释“如何致病”。                                                                | “第一句opinion+because后就是CI，后面只能具象化它。”                          |
| 2    | 具象化机制            | 用“生理/心理链条”把CI拆成 3-4 步，避免只重复观点。 <br>例：chronic exposure → synapses keep firing → brain tense → cannot rest → higher risk of mental disorders          | “把loud noise锁死在chronic exposure…keep synapses firing…cannot rest well。” |
| 3    | 首尾接龙              | 前一句末尾关键词=后一句开头，形成锁链式衔接。 <br>例：…**noise** → **such noise** might…                                                                                  | “Pamela用了手接龙，接得非常牢。”                                             |
| 4    | 句子重心              | 主句放“结果/观点”，条件/背景用状语提前。 <br>错：People feel annoyed **when concentrate**. <br>对：**When concentrating**, people feel annoyed **if disturbed by noise**. | “次要条件往前丢，重心才稳。”                                                 |
| 5    | 因果动词区分          | cause / lead to / result in / trigger <br>• cause：直接因果 <br>• lead to：需“人”作主语或路径 <br>• trigger：瞬间触发                                                     | “living…**will lead to**”→缺人，改为“**may cause**”。                        |
| 6    | 情态弱化              | might / may / can 避免绝对化；隔太远时补一个。 <br>例：might put strain **and may therefore trigger**…                                                                    | “外国人怕绝对，隔太远再补一个may。”                                          |
| 7    | 指代清晰              | 不使用悬空it/they；用this+名词回指。 <br>错：It might overload the brain…（it=?） <br>对：**This chronic exposure** might overload…                                       | “it太多，完全不知道指谁。”                                                   |
| 8    | 避免清单式写作        | 一段只服务一个CI；若写双CI需语言7+并用串联句。 <br>串联句：Prolonged noise not only **damages hearing** but also **imposes psychological strain**.                        | “语言不够好就写一个CI，否则考官直接5.5。”                                    |
| 9    | 伪科学容忍度          | 雅思考官接受“合理推测”，只要逻辑自洽。 <br>例：耳膜>85dB→over-vibration→irreversible tear.                                                                                | “大胆写机制，考官知识盲区反而给高分。”                                       |
| 10   | 语法录播重点          | fragment / run-on / 并列连词 / 从属连词                                                                                                                                   | “下发音视频+PDF练习，专门治这些。”                                           |

——————————————————  
三、典型错误案例对照表  

| 错误类型 | 原句（学生）                                                    | 修改示范                                                               | 错因标签       |
| -------- | --------------------------------------------------------------- | ---------------------------------------------------------------------- | -------------- |
| 悬空it   | It might overload the brain…                                    | **This continuous firing** might overload the brain…                   | 指代不明       |
| 清单式   | 写 mental + physical 两段均浅                                   | 只选 **hearing damage** 并深挖机制                                     | 重心分散       |
| 重心错位 | People feel annoyed when concentrate…                           | **When people are concentrating**, they feel annoyed **if disturbed**. | 条件后置       |
| 逻辑跳跃 | …will lead to psychological problems                            | …**may cause** users to develop psychological problems.                | 缺主语/绝对化  |
| 词性混淆 | …the invention **aims to bring** benefits and **collect** info. | …aims at **bringing** benefits and **collecting** info.                | 并列结构不对称 |

——————————————————  
四、7→8 分写作流程图  
```mermaid
flowchart TD
    A[审题] --> B[确定唯一CI]
    B --> C[3-4步具象化机制<br>(生理/心理/社会)]
    C --> D[首尾接龙+指代回指]
    D --> E[检查句子重心<br>条件状语提前]
    E --> F[情态动词/动词精准化]
    F --> G[通读流畅度<br>朗读测试]
```

——————————————————  
五、课后行动清单  

1. 立即行动  
   • 观看老师发放的语法录播（fragment & run-on）  
   • 完成PDF练习包并自查：句子是否 fragment / run-on / 悬空指代  

2. 写作训练（3步走）  
   Step1 选题 → 在纸上画出“CI + 3-4步机制”流程图  
   Step2 写段 → 强制使用首尾接龙 & 指代回指  
   Step3 朗读 → 每句重音落在“结果/观点”，条件轻读提前  

3. 自检表（发布前30秒）  
   ☐ 本段只有1个CI  
   ☐ 每句开头能接上前句关键词  
   ☐ 所有 it/they 换成 this/these + 名词  
   ☐ might/may 至少出现1次弱化  
   ☐ 朗读无卡顿  

——————————————————  
六、老师金句速记  
• “大胆写机制，考官知识盲区给9分。”  
• “一句只能有一个重心，其余统统状语化。”  
• “写两个CI之前，先看看自己语言到7没有；没到7就老实写一个。”  

——————————————————  
End