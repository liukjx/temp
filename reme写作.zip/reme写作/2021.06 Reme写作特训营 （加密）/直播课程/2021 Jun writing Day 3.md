# 2021年6月写作特训营 Day 3 - Controlling Idea深度解析

## 课程核心目标
掌握**Controlling Idea**（核心论点）的构建方法，确保文章逻辑严密、论证有力。

## 一、Controlling Idea核心概念

### 1.1 定义与重要性
**Controlling Idea**是主宰整篇文章的主线陈述，是文章的灵魂所在。只有Controlling Idea正确，整篇文章才不会偏离主题。

### 1.2 判断标准
一个有效的Controlling Idea必须满足以下条件：
- ✅ **逻辑站得住脚**：经得起推敲和辩论
- ✅ **获得普遍认同**：不是个人主观臆断
- ✅ **紧扣题目要求**：围绕题目核心展开
- ✅ **经过充分论证**：通过多方面讨论验证

### 1.3 构建流程
```mermaid
graph TD
    A[初步想法] --> B[与他人讨论]
    B --> C[验证逻辑]
    C --> D[达成共识]
    D --> E[形成Controlling Idea]
    E --> F[全文围绕展开]
```

## 二、XY与XYZ题型分析法

### 2.1 题型分类
所有写作题目本质上只有两类：

| 题型 | 特征 | 示例 |
|------|------|------|
| **XY型** | 单一要素讨论 | "教育是否应该免费" |
| **XYZ型** | 两要素比较讨论 | "口语交流是否比书面交流更有力量" |

### 2.2 XYZ题型深度解析
以"口语交流是否比书面交流更有力量"为例：
- **X**: 口语交流 (spoken communication)
- **Y**: 书面交流 (written communication)
- **Z**: 更有力量 (more powerful)

### 2.3 "Powerful"的多维度定义
在英语语境中，"powerful"包含以下层面：

| 维度 | 具体表现 | 口语优势 | 书面语优势 |
|------|----------|----------|------------|
| **说服力** | persuasive ability | 语调、停顿、情感表达 | 精准用词、逻辑结构 |
| **传播速度** | speed of spread | 即时传播、口口相传 | 需印刷、分发时间 |
| **传播范围** | reach of spread | 现场限制、面对面 | 可跨越时空传播 |
| **权威性** | authority | 难以正式认证 | 可公证、法律效应 |
| **持久性** | lasting impact | 转瞬即逝 | 可长期保存 |

## 三、Controlling Idea构建实例

### 3.1 优秀案例分析
**题目**: In some countries, criminal trials are shown on TV. Do advantages outweigh disadvantages?

**优秀Controlling Idea示例**:
> "Criminal trials being exposed to the public might have a deterrent effect on potential criminals, which in turn will reduce the crime rate."

**分析要点**:
- ✅ 逻辑清晰：公开审判→威慑效应→犯罪率下降
- ✅ 用词准确：deterrent effect, crime rate (非criminal rate)
- ✅ 可论证性强：可从心理学、社会学角度展开

### 3.2 常见错误警示

#### 错误类型1: 概念模糊
❌ **错误**: "violation of human rights"
✅ **修正**: "violation of privacy rights of both criminals and victims"

#### 错误类型2: 论点重叠
❌ **错误**: 两段都写隐私权问题
✅ **修正**: 
- 第一段：隐私权侵犯的具体表现
- 第二段：隐私权侵犯的长期后果（如重返社会困难）

## 四、口语vs书面语论证框架

### 4.1 口语交流优势论证

#### 论证角度1: 情感传达的直接性
```
口语交流 > 书面交流
- 语调(intonation)能直接反映情感状态
- 停顿(pause)能强调重点
- 能量变化(energy level)能引导听众情绪
- 即时反馈(immediate feedback)增强互动效果
```

#### 论证角度2: 传播效率
- **古代**: 口语传播更快（文盲率高）
- **现代**: 视频形式口语传播超越文字
- **案例**: TikTok演讲技巧、现场感染力

### 4.2 书面交流优势论证

#### 论证角度1: 逻辑结构的严谨性
- **句法结构**(syntactic structure)承载逻辑关系
- **修辞手法**(rhetorical devices)增强表达效果
- **可重复研读**确保信息准确接收

#### 论证角度2: 权威性与持久性
- **法律文件**: 可公证、认证
- **学术著作**: 可长期引用、验证
- **历史记录**: 跨越时空传播

## 五、写作技巧精要

### 5.1 词汇选择要点
| 常用错误 | 正确表达 |
|----------|----------|
| criminal rate | crime rate |
| deterrent impact | deterrent effect |
| manipulate (负向) | influence, guide (中性) |

### 5.2 论证展开技巧
1. **上位词-下位词法**: 从抽象到具体
2. **对比论证法**: 突出差异
3. **举例论证法**: 具体化抽象概念
4. **因果链法**: A→B→C的逻辑递进

### 5.3 段落结构模板
```
主题句(Controlling Idea) + 
解释说明 + 
具体例证 + 
对比分析 + 
小结提升
```

## 六、实战应用建议

### 6.1 写作前准备
1. **明确题型**: XY还是XYZ
2. **定义关键词**: 如"powerful"的多维定义
3. **构建Controlling Idea**: 确保逻辑严密
4. **设计论证框架**: 多角度展开

### 6.2 写作中要点
1. **避免论点重复**: 每段不同controlling idea
2. **精准用词**: 避免模糊表达
3. **逻辑递进**: 层层深入论证
4. **文化语境**: 考虑英语母语者认知框架

### 6.3 检查清单
- [ ] Controlling Idea是否明确且可论证
- [ ] 论点之间是否有重叠
- [ ] 用词是否准确地道
- [ ] 论证是否有逻辑漏洞
- [ ] 是否考虑了反方观点

## 七、课程总结

本节课通过深度分析Controlling Idea的构建方法，让学员掌握：
1. **系统思维**: 从多个维度分析问题
2. **精准表达**: 避免模糊和冗余
3. **文化适应**: 符合英语母语者认知习惯
4. **逻辑严谨**: 确保论证过程无懈可击

记住：**一个好的Controlling Idea不是凭空想象，而是经过充分讨论和验证的共识性观点。**