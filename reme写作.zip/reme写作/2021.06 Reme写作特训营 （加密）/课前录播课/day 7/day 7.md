雅思小作文「图表题」系统梳理  
（基于 Day-7 课程语音转文字稿）

---

## 1. 图表题三大核心维度  
| 维度       | 目的                                                 | 举例说明                                                             |
| ---------- | ---------------------------------------------------- | -------------------------------------------------------------------- |
| Grouping   | 把若干数据单位逻辑地分成若干组                       | 把北美、欧洲归为“工业用水占主导”；把南美等四地区归为“农业用水占主导” |
| Comparison | 组与组之间（群间）或组内不同项目之间（群内）进行对比 | 农业用水 88 % vs 工业+生活 12 %，倍数≈7 倍                           |
| Trend      | 描述随时间变化的整体走向（仅动态图需要）             | 1970-2000 年英国 CO₂ 人均排放量从 11 t 降到 9 t                      |

---

## 2. 图表三分法（所有题型都能归进去）
| 类型      | 分析单位数量 | 时间点数量 | 常见图型         | 写作优先级（权重）               |
| --------- | ------------ | ---------- | ---------------- | -------------------------------- |
| 动态 A 类 | 多（≥5）     | 少（≤3）   | pie、bar         | 1.分组 2.对比 3.趋势（轻描淡写） |
| 动态 B 类 | 少（≤4）     | 多（≥3）   | line、bar、table | 1.趋势 2.对比 3.分组（可有可无） |
| 静态图    | 多           | 0 或 1     | pie、bar、table  | 1.分组 2.对比（无趋势）          |

> 地图与流程图属于独立题型，不进入以上三分法。

---

## 3. 评分标准拆解
| 得分 | TA（Task Achievement）关键要求                | 易犯误区                    |
| ---- | --------------------------------------------- | --------------------------- |
| 5    | 有数据无 overview，或反之                     | 把细节当 overview；预测未来 |
| 6    | 数据+overview 都有，但宏观性不足              | 只写“最高/最低”当 overview  |
| 7    | 数据几乎无错；overview 宏观且正确             | 把 2006 年小波动当趋势      |
| 8-9  | 用“数学语言”概括总体特征；insightful overview | 引入因果或主观猜测          |

> 小技巧：overview 可以放在 intro 后单独一句，也可做结尾；不要再写 conclusion 重复。

---

## 4. 高分写作流程（通用）
```mermaid
flowchart TD
    A[审题：找 grouping 逻辑] --> B[写 Introduction: 1.抄/改写题干 2.给宏观分组]
    B --> C[Body1: 描述第一组特征<br>抽象大句+数据+对比]
    C --> D[Body2: 描述第二组特征<br>同上]
    D --> E[检查：数据、单位、语法]
```

- **Introduction 万能模板**  
  The chart below shows **how water is used** for different purposes in **six areas of the world**. The data can be roughly divided into two groups: one involving **North America and Europe**, and another including **South America, Africa, Central Asia and Southeast Asia**.

- **抽象大句示例（静态图 Body1 第一句）**  
  In the four developing regions, **agricultural use accounts for the lion’s share of water consumption**, averaging 81 %.

- **群内对比句模板**  
  This figure is **up to seven times higher than the combined percentage for industrial and domestic use**.

---

## 5. 动态图写法差异
| 类型   | 开篇第一句举例                                                                                                   | 数据组织方式                     |
| ------ | ---------------------------------------------------------------------------------------------------------------- | -------------------------------- |
| 动态 A | “The bars can be split into two groups…”                                                                         | 先分组，再在每个组里提趋势       |
| 动态 B | “Overall, the UK and Sweden managed to reduce per-capita CO₂ emissions, while Italy and Portugal saw increases.” | 按每条线顺序写趋势；无需强行分段 |

---

## 6. 考场时间分配建议（Task 1）
| 阶段          | 时间   | 任务                           |
| ------------- | ------ | ------------------------------ |
| 审题+分组     | 2 min  | 画圈分组，找关键对比           |
| 写 Intro      | 1 min  | 可整句照搬题干，减少改写风险   |
| Body1 & Body2 | 10 min | 先抽象句→数据→对比；勿纠结语法 |
| 检查          | 3 min  | 单复数、时态、单位、拼写       |

> 如果大作文更强，可先写大作文；但官方无硬性顺序要求，以个人性价比为准。

---

## 7. 常见雷区清单
1. 把 **region** 写成 **country**（×）。  
2. 用 **developing vs developed** 分组，可能触文化敏感（×）。  
3. 逐条罗列数字，无概括句（5 分特征）。  
4. 写原因、结果或未来预测（TA 直接 5 分）。  
5. 字数不够：2018-04 前算字数，之后看内容完整性；但明显不足仍可被考官手动降级。

---

## 8. 一句话总结  
**无论哪种图表，先把数据“分组-对比-（必要时）说趋势”，用一句宏观 abstract 句开头，再用精准数字证明，就能稳拿 TA 7+。**