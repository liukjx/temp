以下是将这份长达 3 小时的雅思写作课程语音转文字稿，进行**系统性梳理与知识点总结**，以**“问题-知识点-解决方法-例子”**的结构呈现，便于理解与复习。

---

## ✅ 一、课程核心问题分类

| 问题类型     | 描述                                                   | 解决方法举例                                     |
| ------------ | ------------------------------------------------------ | ------------------------------------------------ |
| **逻辑问题** | 论点跳跃、因果不清、主次不分、逻辑鸿沟                 | 使用“XYZ”逻辑链（X原因 → Y过程 → Z结果）         |
| **语法问题** | 主谓不一致、被动语态误用、非谓语动词错误、独立主格误用 | 引入“逻辑发出者”概念，明确动作发出者             |
| **词汇问题** | 大词乱用、搭配错误、抽象词堆砌、Chinglish              | 用“具体+准确”替代“抽象+华丽”                     |
| **结构问题** | 重心偏移、段落断裂、句子孤立、缺乏controlling idea     | 使用“倒三角结构”：抽象结论 → 具体解释 → 例证支持 |
| **审题问题** | 忽略题目关键词、跑题、答非所问                         | 用“controlling idea”锁定段落主旨                 |

---

## ✅ 二、知识点系统梳理

### 📌 1. 逻辑链（XYZ结构）

| 名称  | 说明      | 示例                   |
| ----- | --------- | ---------------------- |
| **X** | 背景/原因 | “由于地球人口过剩”     |
| **Y** | 过程/手段 | “寻找外太空可居住星球” |
| **Z** | 结果/目的 | “为人类提供新的栖息地” |

> ✅ 建议：每段第一句就用一句话完整表达XYZ逻辑链，避免跳跃。

---

### 📌 2. 句子重心与主语选择

| 错误类型       | 例子                                            | 正确写法                                                                    |
| -------------- | ----------------------------------------------- | --------------------------------------------------------------------------- |
| 动作为主语     | “Exploring space needs to adapt...” ❌           | “People exploring space need to adapt...” ✅                                 |
| 抽象名词作主语 | “The process may help us find planets...” ✅     | “Finding planets with life may help us...” ✅                                |
| 主语不明确     | “It is difficult to send devices into space.” ❌ | “Sending devices into space is difficult due to gravity and fuel issues.” ✅ |

> ✅ 建议：主语必须是动作发出者或抽象核心概念，避免“it is...”模糊句。

---

### 📌 3. 独立主格 vs 定语从句

| 结构类型 | 用法说明                   | 示例                                          |
| -------- | -------------------------- | --------------------------------------------- |
| 独立主格 | 强调动作本身，修饰整个句子 | “Fearing the broadcast, millions panicked.” ✅ |
| 定语从句 | 修饰名词，强调名词属性     | “People who feared the broadcast panicked.” ✅ |

> ✅ 建议：不要用V-ing结构修饰人，除非强调动作本身。

---

### 📌 4. Controlling Idea（段落主旨句）

| 错误写法                                             | 正确写法                                                                                                |
| ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| “By focusing on work, bosses can make more money.” ❌ | “Employers should prioritize work performance over dress code, as it directly impacts profitability.” ✅ |

> ✅ 建议：每段第一句必须包含：
- **观点**（agree/disagree）
- **原因**（controlling idea）
- **价值导向**（profit/safety/image等）

---

### 📌 5. 词汇与搭配（避免Chinglish）

| 错误表达                           | 正确表达                          |
| ---------------------------------- | --------------------------------- |
| “low oxygen content” ❌             | “oxygen-deficient environments” ✅ |
| “improve their physical fitness” ❌ | “enhance physical endurance” ✅    |
| “make more money” ❌                | “boost profitability” ✅           |

> ✅ 建议：用**地道搭配词组**替代直译，参考《剑桥雅思写作语料库》。

---

## ✅ 三、结构建议：倒三角写作法

```mermaid
graph TD
A[抽象结论] --> B[具体解释]
B --> C[例证支持]
```

**示例段落结构**：

> **段落第一句**：观点+原因（controlling idea）  
> **中间句**：解释原因（逻辑链）  
> **结尾句**：举例或总结（具象化）

---

## ✅ 四、作业与练习建议

| 任务类型     | 内容说明                                                                |
| ------------ | ----------------------------------------------------------------------- |
| **改写练习** | 将5.5分作文改写为6.5分：补充逻辑链、修正主语、加入controlling idea      |
| **审题训练** | 每天写1句段落主旨句，包含：观点+原因+价值导向                           |
| **语料积累** | 每天背诵5个地道搭配（如：boost productivity / enhance corporate image） |
| **句式模仿** | 模仿XYZ结构造句，如：                                                   |
> “Since Earth is overpopulated, we must find habitable planets, ensuring human survival.”

---

## ✅ 五、常见误区提醒

| 误区                         | 正确做法                     |
| ---------------------------- | ---------------------------- |
| 用复杂词装逼                 | 用准确词+清晰逻辑            |
| 每句都写“it is...”           | 用具体主语+动词              |
| 段落之间逻辑断裂             | 每段用“抽象→具体→例子”结构   |
| 忽略题目关键词               | 划出关键词，每段都回应       |
| 用“some people think...”开头 | 直接表达观点：“I believe...” |

---

## ✅ 六、推荐写作模板（适用于Task 2）

| 段落   | 模板句                                                                 |
| ------ | ---------------------------------------------------------------------- |
| 开头段 | Some argue that [A], while others insist [B]. I believe [your stance]. |
| 主体段 | [Controlling idea], because [reason]. For example, [example].          |
| 结尾段 | In conclusion, [restate controlling idea] is crucial for [goal].       |

---

## ✅ 七、结语与下一步行动

- ✅ **本周任务**：我将发3篇5.5分作文到群里，请每位同学用“倒三角+XYZ+controlling idea”方法改写。
- ✅ **下周目标**：每位同学提交一篇完整作文，重点检查：
  - 是否有逻辑鸿沟
  - 主语是否明确
  - 是否有controlling idea
  - 是否有具体例子支撑

---

如需我为你准备**“5.5→6.5改写模板”**或**“逻辑链训练题”**，请回复关键词【模板】或【训练】。