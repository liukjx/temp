一、课程总览  
主题：2021-11 词汇 Day-1 直播课  
工具：Cahoot（实时点击答题）+ Quizlet（课后复习）  
目标：  
1. 先通过 Poll 题“猜词义”，再给出更精准的定义；  
2. 用 Townsend 例句做“in-context”巩固；  
3. 兼顾基础 45 分左右与高水平学员。  

二、词汇精讲  
（按直播出现顺序，已剔除口癖、无关闲聊）

| 词汇             | 精准定义                                            | 易错/近义词辨析                      | 场景例句                                             |
| ---------------- | --------------------------------------------------- | ------------------------------------ | ---------------------------------------------------- |
| understanding    | agreement（双方意见一致）                           | ≠ precious / protect / entertain     | They reached an understanding on the price.          |
| (to) cancel      | not do as planned（原计划取消）                     | ≠ prepare / suggest / curious        | The flight was canceled due to fog.                  |
| satisfy          | to meet sb’s demand; make content                   | ≠ simply “make happy”                | A good salary alone doesn’t satisfy every employee.  |
| factual          | based on fact; true                                 | ≠ logical（逻辑通但可能假）          | The report must be factual, not speculative.         |
| refer            | ① mention / consult ② direct sb to sb/sth           | ≠ suspect / doubt                    | Please refer to the manual on page 10.               |
| suspect vs doubt | suspect=believe sb may be guilty; doubt=lack belief | —                                    | I doubt his story, but I don’t suspect him of lying. |
| flexible         | able to bend; adaptable                             | —                                    | Yoga makes your body more flexible.                  |
| leisure          | free time without duties                            | ≠ flexible / tension                 | Reading is my favorite leisure activity.             |
| definite         | clear and certain                                   | —                                    | We need a definite answer by Friday.                 |
| tension          | mental strain; tightness                            | ≠ flexible                           | There was tension in the room before the exam.       |
| produce          | to make / create                                    | ≠ older / smell                      | This plant produces oxygen.                          |
| older (odor)     | unpleasant smell                                    | ≠ neutral “smell”                    | The older of garlic lingered in the kitchen.         |
| minor            | ① small/insignificant ② under-age                   | ≠ minority（少数群体）               | Only minor changes are needed.                       |
| inspire          | to motivate; be a role model                        | —                                    | Her speech inspired the whole team.                  |
| prepare          | get ready in advance                                | —                                    | Prepare the documents before the meeting.            |
| suggest          | offer an idea; imply                                | ≠ accuse / identify                  | He suggested a new marketing plan.                   |
| accuse           | claim sb did wrong (bad connotation)                | ≠ blame / charge (legal) / identify  | She accused him of cheating.                         |
| daily            | happening each day                                  | weekly / yearly / annually           | He reads the news daily.                             |
| entertain        | to amuse; provide enjoyment                         | ≠ benefit                            | The clown entertained the kids.                      |
| benefit          | to do good to; be useful to                         | ≠ entertain; may not cause happiness | Exercise benefits both body and mind.                |
| experience       | sth one has lived through; event felt               | —                                    | Skydiving was an unforgettable experience.           |
| identify         | point out; recognize                                | ≠ simply “make”                      | Can you identify the suspect in the photo?           |
| negative         | not good; undesirable                               | ≠ necessarily “bad”                  | The test came back negative.                         |
| original         | completely new; never seen before                   | ≈ novel (≠ fresh food)               | Her idea is truly original.                          |
| attack           | inflict damage (physical or verbal)                 | ≠ run away                           | The army attacked at dawn.                           |
| conclusion       | the end / summary                                   | —                                    | In conclusion, we must act now.                      |
| humble           | modest; not arrogant                                | ≠ loud / afraid                      | Despite his fame, he remains humble.                 |
| talent           | innate gifted ability                               | ≠ skill (learned) / fear             | She has a talent for music.                          |
| volunteer        | unpaid person doing community work                  | ≠ intern (company-based)             | Volunteers cleaned the beach.                        |

三、易混淆词对流程图  
```mermaid
graph TD
    A[易混淆词] --> B[suspect vs doubt]
    A --> C[accuse vs blame vs charge]
    A --> D[fresh vs original]
    A --> E[skill vs talent]
    A --> F[volunteer vs intern]

    B --> B1[suspect: 怀疑某人有罪]
    B --> B2[doubt: 对真实性存疑]

    C --> C1[accuse: 口头指责]
    C --> C2[blame: 归咎]
    C --> C3[charge: 正式起诉]

    D --> D1[fresh: 新鲜(食物/空气)]
    D --> D2[original: 原创(思想)]

    E --> E1[skill: 后天习得]
    E --> E2[talent: 先天天赋]

    F --> F1[volunteer: 社区志愿者]
    F --> F2[intern: 公司实习生]
```

四、高频考点提醒  
1. 形容词→副词规律  
   day → daily, week → weekly, year → yearly / annually  
2. 形近词  
   minor ≠ minority; older (odor) ≠ elder (年纪大)  
3. 词义轻重  
   negative “不太好” < bad “糟糕” < terrible “极糟”  
4. 搭配差异  
   • refer to + 资料 / refer sb to + 人  
   • satisfy sb’s needs / be satisfied with sth  
   • in conclusion / at the conclusion of…

五、学习建议  
1. 课后流程  
   ① 用老师发的 PDF 再做一遍 Quizlet；  
   ② 把易混淆词写入 Anki，正面写英文，背面写中文+例句；  
   ③ 每天 5 min 快速复习，遵循遗忘曲线（1d-3d-7d-15d）。  
2. 语境巩固  
   • 用“Townsend in-context”句子做听写：遮住关键词，听录音写空。  
   • 把今天 10 个最陌生单词放进自己的口语/写作任务：  
     例：写一篇 80 词日记，必须用到 original, inspire, volunteer, conclusion。  
3. 输出检验  
   • 每周录 1 分钟音频：用 5 个新词讲一个小故事。  
   • 与同学互改作文，重点检查 accuse/suspect、skill/talent 等易混词。