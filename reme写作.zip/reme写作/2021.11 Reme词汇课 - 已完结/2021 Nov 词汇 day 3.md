以下内容基于 2021 Nov 词汇 day 3 的课堂录音文字稿，对出现的全部高频词汇、易混淆词、词组搭配及老师特别提示进行**系统化梳理**，并给出**学习建议**。  
（按 A-Z 排序，方便查阅；已剔除口语噪音、闲聊及重复内容）

---

## 一、核心词汇速查表
| 词汇                                      | 词性&音标            | 中文释义                   | 英文释义/同义替换   | 高频搭配/例句                            | 易混淆点&课堂提示                                   |
| ----------------------------------------- | -------------------- | -------------------------- | ------------------- | ---------------------------------------- | --------------------------------------------------- |
| **adjust** /əˈdʒʌst/                      | v. 调整              | 调整、微调                 | modify, tweak       | adjust one’s seat / adjust strategy      | 与 adapt（适应）区分：adjust 更强调“微调”。         |
| **anxious** /ˈæŋkʃəs/                     | adj. 焦虑的          | nervous, worried           | tense, stressed     | I’m anxious about the exam.              | 人才能 anxious；event 用 stressful。                |
| **assume** /əˈsuːm/                       | v. 假设              | take for granted           | presume, suppose    | I assumed he was honest.                 | 先入为主、未经证实；负面色彩。                      |
| **convince** /kənˈvɪns/                   | v. 说服              | persuade, cause to believe | talk sb into        | Convince him to join us.                 | ≠ refuse to accept；强调“使相信”。                  |
| **disregard** /ˌdɪs.rɪˈɡɑːrd/             | v. 不理会            | ignore, overlook           | pay no attention to | Please disregard the rumor.              | 语气比 ignore 正式。                                |
| **exhaust** /ɪɡˈzɔːst/                    | v. 耗尽              | use up, deplete            | drain               | exhaust one’s energy                     | 物作主语；人作主语时用 exhausted（adj.）。          |
| **objective** /əbˈdʒek.tɪv/               | n. 目标；adj. 客观的 | goal, target; impartial    | aim                 | achieve the objective                    | 作名词=goal；作形容词=objective view。              |
| **possess** /pəˈzes/                      | v. 拥有              | own, have                  | hold, retain        | possess a talent / be possessed by ghost | 名词 possession；鬼魂“附身”用被动。                 |
| **procedure** /prəˈsiː.dʒər/              | n. 步骤              | steps to accomplish sth    | protocol, process   | the procedure for passport renewal       | procedure=步骤；method=方法；methodology=方法体系。 |
| **protest** /prəˈtest/ v. /ˈproʊ.test/ n. | v.&n. 抗议           | demonstrate against        | opposition          | stage a protest march                    | protest against sth.                                |
| **refill** /ˌriːˈfɪl/                     | v.&n. 续杯           | fill again                 | top up              | Can I get a coffee refill?               | 餐饮场景高频；replenish 多用于营养、库存。          |
| **renew** /rɪˈnuː/                        | v. 更新              | make new again             | extend, resume      | renew a license / lease                  | re-前缀表示“重新”。                                 |
| **resource** /ˈriː.sɔːrs/                 | n. 资源              | useful material/asset      | asset, supply       | natural resources / financial resources  | resource ≠ source；前者“可用之物”，后者“来源”。     |
| **source** /sɔːrs/                        | n. 来源              | origin, root               | beginning           | the source of the river                  | 强调“出处”，不强调“有用”。                          |
| **sufficient** /səˈfɪʃ.ənt/               | adj. 足够的          | enough, adequate           | ample               | sufficient evidence                      | 完全替换 enough；动词 suffice=“足够”。              |
| **variety** /vəˈraɪ.ə.ti/                 | n. 多样性            | diversity, range           | assortment          | a variety of choices                     | variety=多种类；mixture=混合体。                    |
| **wholesome** /ˈhoʊl.səm/                 | adj. 有益健康的      | healthy, beneficial        | nutritious          | wholesome food / feel wholesome          | 结尾-some 不都是负面（tiresome, burdensome）。      |

---

## 二、易混淆词对 1v1 对比

| A             | B             | 关键差异                                                                  | 例句                                                              |
| ------------- | ------------- | ------------------------------------------------------------------------- | ----------------------------------------------------------------- |
| **assume**    | **presume**   | assume=先入为主、未经证实的负面假设；presume=在意识到可能错误前提下的假设 | He assumed I was guilty. / I presumed he left—sorry if I’m wrong. |
| **resource**  | **source**    | resource=对你有用的资源；source=来源、出处                                | Coal is a resource; the source of coal is ancient plants.         |
| **procedure** | **method**    | procedure=完成某事的步骤；method=做事的“方式”                             | The procedure for CPR vs. the method of teaching CPR.             |
| **anxious**   | **stressful** | anxious 用于“人”；stressful 用于“事件”                                    | She’s anxious. / The job is stressful.                            |
| **refill**    | **replenish** | refill=再装满（杯子）；replenish=补充库存/营养                            | Refill my drink. / Replenish the warehouse stock.                 |

---

## 三、课堂金句 & 记忆技巧
1. **“If it ain’t broke, don’t fix it.”** → leave unchanged 的同义口语。  
2. **“碰 8 次→认识词；碰 13 次→会用词。”** → 老师强调“大量输入 + 场景复现”才是王道。  
3. **“词根词缀只对医、生、物、理有用，日常英语别死磕。”**  
4. **“音标救不了口音，大量听读才救得了。”**

---

## 四、学习流程图
```mermaid
flowchart TD
    A[输入新单词] --> B[场景/文本中首次遇到]
    B --> C{是否再次遇到？}
    C -->|是| D[第2-7次复现]
    C -->|否| Z[遗忘]
    D --> E[第8次复现<br>认识词]
    E --> F[第9-12次复现]
    F --> G[第13次复现<br>会用词]
    G --> H[主动输出写作/口语]
```

---

## 五、课后行动清单
| 任务           | 工具/资源             | 周期             | 备注                             |
| -------------- | --------------------- | ---------------- | -------------------------------- |
| ① 复习当日词汇 | Quizlet/Anki          | 当天睡前 & 24h后 | 卡片正面英文+例句，背面中文+搭配 |
| ② 场景复现     | 美剧/播客/新闻        | 每日 ≥30 min     | 记录生词出现次数，够 8 次打钩    |
| ③ 输出练习     | 英语角/日记           | 每周 3 次        | 强制使用当日新词                 |
| ④ 混淆词测试   | 自制选择题            | 每周 1 次        | 例：procedure vs. method 10 题   |
| ⑤ 发音校准     | YouGlish/YouTube 字幕 | 每日 10 min      | 跟读并录音对比原文               |

---

## 六、互动答疑（摘录）
Q：如何短期内把词汇从 3k 拉到 7k？  
A：别死背！遵循 **VVAI VCC 模型**：  
- **Volume** 大量输入（听读）  
- **Variety** 多元场景（影视/新闻/播客）  
- **Attention** 注意复现次数 ≥8  
- **Iteration** 循环复习  
- **Vocalization** 主动说  
- **Contextualization** 语境化造句  

---

**结语**  
把今天表格里的词全部放进 Anki，按“8-13 次”原则复现，一周后自测。下次课前，先完成「混淆词 10 题」+「用 5 个新词各造 1 句」。词汇量不是背的，是“碰见”的。