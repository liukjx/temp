# Lesson 3: Positive/Negative Questions - 外国人的思维框架

## 核心概念：什么对外国人来说是"好"的

### 三大黄金标准

在雅思写作中，任何现象或动作的"好"与"坏"都可以通过以下三个核心维度来衡量：

#### 1. Efficiency (效率)
**定义**：完成目标的速度和质量
- **核心**：Get things done faster / Achieve the goal faster / Fulfill the purpose faster
- **关键**：在相同时间内完成更多任务，且保持同等高质量

**医学例子**（药效对比）：
| 药物 | 有效性 | 起效时间 | 效率评估 |
|------|--------|----------|----------|
| 药物A | 80% | 2小时 | 较低 |
| 药物B | 80% | 10分钟 | **较高** |

**工作场景例子**：
- 员工A：20分钟内只做汉堡
- 员工B：20分钟内能做汉堡+披萨+杨枝甘露，且质量相同
- **结论**：员工B效率更高

#### 2. Effectiveness (有效性)
**定义**：是否达到预期目的及其程度
- **核心**：能否achieve the goal / fulfill the purpose
- **范围**：0-100%的连续光谱，而非简单的0或1

**医学例子**（药效对比）：
- 药物A：治头痛，疼痛消除80%
- 药物B：治头痛，疼痛消除30%
- **结论**：药物A更有效

**关键区别**：
- Effectiveness = 达到目标的程度
- Efficiency = 达到目标的速度

#### 3. Economy (经济性)
**定义**：成本效益比，即性价比
- **核心**：Cost efficiency / Save resources (time, energy, money, raw materials)
- **前提**：必须在可行性(feasibility)基础上讨论经济性

**医学例子**（成本对比）：
| 药物 | 有效性 | 起效时间 | 单价 | 经济性 |
|------|--------|----------|------|--------|
| 药物A | 80% | 10分钟 | $0.3/克 | **较好** |
| 药物B | 80% | 10分钟 | $0.7/克 | 较差 |

### 第四维度：Prevention & Reversal

#### 正面角度
任何能够：
- **Prevent**负面事件发生
- **Slow down**负面事件进程
- **Stop**负面事件发展
- **Reverse**负面事件后果

的事物都是"好"的

**实例分析**：
1. **疫苗**：Prevent disease from happening（预防疾病）
2. **减排措施**：Slow down glacier melting（减缓冰川融化）
3. **植树造林**：Reverse global warming（逆转全球变暖）

#### 负面角度
任何能够：
- **Prevent**正面事件发生
- **Slow down**正面事件进程
- **Stop**正面事件发展
- **Reverse**正面事件后果

的事物都是"坏"的

## 应用实例：无人驾驶汽车

### 题目分析
"Scientists believe in the near future cars will be driven by computers, not people. Do you think this is a positive or negative development?"

### 正面论证框架

#### 效率提升 (Efficiency)
```mermaid
graph LR
    A[无人驾驶] --> B[路线优化]
    A --> C[精准操控]
    B --> D[节省时间]
    C --> E[减少油耗]
    D & E --> F[整体效率提升]
```

**具体论证**：
- **路线优化**：AI能实时计算最优路线，避免拥堵
- **精准操控**：减少人为失误导致的绕路
- **时间节省**：相同路程耗时更短
- **资源节省**：减少燃油/电力消耗

#### 安全性提升 (Effectiveness)
**数据对比**：
| 事故类型 | 人类驾驶 | 无人驾驶 |
|----------|----------|----------|
| 年事故总数 | 10,000+ | 2 |
| 致死率 | 较低 | 较高但总数极少 |
| 总体安全性 | **提升** |

**论证要点**：
- 虽然AI事故可能造成严重后果，但事故总数大幅下降
- 人类驾驶小事故频发，AI驾驶事故极少

#### 经济性提升 (Economy)
- **长期成本**：减少事故损失、维修费用
- **社会资源**：减少交通拥堵带来的经济损失
- **能源效率**：优化驾驶模式，降低能源消耗

### 负面论证框架

#### 安全风险
**技术局限**：
- 程序漏洞可能导致无法识别行人
- 极端天气下的识别能力下降
- 系统故障可能引发致命事故

#### 就业影响
**过渡期问题**：
```mermaid
graph TD
    A[无人驾驶普及] --> B[司机失业潮]
    B --> C[短期经济动荡]
    C --> D[社会不稳定风险]
    D --> E[需要政策缓冲]
    E --> F[新就业机会创造]
```

**论证角度**：
- **短期冲击**：大量司机失业，特别是低技能劳动力
- **长期调整**：新兴技术岗位的产生，但需要技能转换期

### 高级论证技巧

#### 1. 修辞精准化
**避免**："Driverless cars are safer"
**推荐**："Driverless cars effectively reduce the number of traffic accidents"

#### 2. 数据对比法
**人类驾驶**：10,000起事故/年，多为轻微事故
**无人驾驶**：2起事故/年，但后果严重
**结论**：从概率角度，无人驾驶更安全

#### 3. 时间维度分析
- **短期**：技术不完善，存在风险
- **中期**：过渡期就业冲击
- **长期**：整体社会效益提升

## 写作框架模板

### 开头段
引入话题 + 明确立场
> "While the prospect of computer-driven vehicles raises legitimate concerns, I contend that this development represents a net positive advancement for society."

### 主体段1：效率提升
主题句 + 具体论证 + 例子
> "Primarily, autonomous vehicles significantly enhance transportation efficiency through optimized route calculation and precise vehicle control..."

### 主体段2：安全性提升
主题句 + 数据对比 + 反驳潜在质疑
> "Furthermore, despite occasional high-profile accidents, the aggregate safety data strongly favors autonomous systems..."

### 主体段3：经济影响
主题句 + 短期vs长期分析
> "Admittedly, the transition period may witness temporary unemployment among drivers, yet this disruption pales in comparison to the long-term economic benefits..."

### 结尾段
总结观点 + 展望未来
> "In conclusion, while acknowledging transitional challenges, the evidence overwhelmingly supports autonomous vehicles as a positive development..."

## 常见误区提醒

1. **避免情绪化论证**：用数据代替主观感受
2. **避免绝对化表述**：使用"tend to", "generally", "in most cases"
3. **考虑反方观点**：承认合理性后再反驳
4. **区分短期长期**：避免忽视时间维度的影响

## 实用表达储备

### 效率相关
- "optimize resource allocation"
- "minimize time expenditure"
- "maximize output per unit input"
- "streamline operational processes"

### 安全相关
- "statistically significant reduction"
- "fatality rate per mile driven"
- "accident prevention capabilities"
- "response time in milliseconds"

### 经济相关
- "cost-benefit analysis reveals"
- "long-term economic viability"
- "return on investment"
- "resource optimization"

## 总结

掌握外国人的思维框架关键在于：
1. **量化分析**：用数据支撑观点
2. **多维度评估**：从效率、效果、经济三个角度分析
3. **时间维度**：区分短期影响和长期效益
4. **逻辑严密**：承认反方观点的合理性，再提出更有力的反驳

这套框架适用于所有雅思写作中的positive/negative题型，通过系统化的分析，能够写出逻辑清晰、论证有力的高分作文。