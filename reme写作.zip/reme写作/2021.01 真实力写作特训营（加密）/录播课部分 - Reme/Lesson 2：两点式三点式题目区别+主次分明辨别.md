# Lesson 2：两点式三点式题目区别+主次分明辨别

## 课程概述
本课程深入解析雅思写作中两种核心题型结构（两点式vs三点式），以及如何识别文章重心并避免偏离主题。通过大量实例分析，帮助学生理解考官真正考察的逻辑思维能力。

## 核心概念

### 1. 两点式题目 vs 三点式题目

#### 📊 对比表格

| 特征 | 两点式题目 | 三点式题目 |
|---|---|---|
| **结构** | X → Y | X → Y1 vs Y2 → Z |
| **逻辑关系** | 单一因果关系 | 对比关系+综合 |
| **典型问法** | Advantage/Disadvantage, Cause/Effect | Discuss both views, To what extent |
| **写作重点** | 分析好坏/原因结果 | 建立两个观点间的桥梁 |
| **难度** | 相对简单 | 更复杂，需要综合能力 |

#### 🎯 识别方法

**两点式题目的特征：**
- 题目中只有一个动作/现象
- 问的是这个动作的好坏或原因结果
- 例："Why do people prefer to live in cities? What are the problems?"

**三点式题目的特征：**
- 题目中有两个对立的观点或做法
- 需要讨论两者并给出综合观点
- 例："Some people think A, others believe B. Discuss both views."

### 2. 文章重心识别

#### 🔍 重心判断标准

**真正的重心是动词（动作/现象）而非名词：**

| 误区 | 正确理解 |
|---|---|
| 政府责任 | 谁应该负责（responsibility） |
| 健康饮食 | 是否有必要（necessity） |
| 道路安全 | 有效性（effectiveness） |
| 广告作用 | 如何影响（how it influences） |

#### 💡 实例分析

**案例1：**
- 题目："Who should be responsible for children's health - government or parents?"
- 重心：responsibility（谁应该负责）
- 不是：government, children, health

**案例2：**
- 题目："Advertising encourages people to buy in quantity rather than quality"
- 重心：how advertising influences buying behavior
- 不是：advertising, quantity, quality

### 3. 主次分明原则

#### 📋 主次信息区分表

| 主要信息 | 次要信息 |
|---|---|
| 独立从句（Independent clause） | 从属从句（Dependent clause） |
| 核心论点 | 支持细节 |
| 直接相关 | 背景信息 |
| 必须明确表达 | 可以隐含或通过从句表达 |

#### ✍️ 应用示例

**错误写法：**
> "Supermarkets want to sell leftover products, so they use advertising."

**正确写法：**
> "Advertising campaigns that emphasize 'buy one get one free' and 'limited time offers' encourage consumers to purchase in quantity, while often neglecting to highlight product quality."

### 4. 常见错误类型

#### ❌ 重心偏移的三种类型

```mermaid
graph TD
    A[文章重心偏移] --> B[类型1: 控制观点错误]
    A --> C[类型2: 论述脱节]
    A --> D[类型3: 主次颠倒]
    
    B --> B1[第一句观点就偏了]
    C --> C1[后文与首句无关]
    D --> D1[次要信息变主要]
```

#### 🎓 真实案例分析

**错误案例：**
> 题目："Living abroad causes social and practical problems"
> 错误重心：描述孤独感（这只是结果，不是因果关系）

**正确重心：**
> 具体说明语言障碍如何导致社交和实际问题

### 5. 写作策略

#### 📝 两点式题目写作框架

**结构：**
1. **引言**：改写题目 + 提出观点
2. **主体段1**：分析X如何导致Y
3. **主体段2**：深入阐述Y的影响
4. **结论**：总结并重申观点

**示例：**
- 题目："Why do people prefer fast food? What are the problems?"
- 框架：
  - X = 快节奏生活方式
  - Y = 快餐消费增加
  - 问题 = 健康问题、环境问题

#### 📝 三点式题目写作框架

**结构：**
1. **引言**：改写题目 + 提出综合观点
2. **主体段1**：讨论观点A（Y1）
3. **主体段2**：讨论观点B（Y2）
4. **主体段3**：建立桥梁（Z）- 综合观点
5. **结论**：总结综合立场

**示例：**
- 题目："Some think government should control diet, others believe it's personal responsibility"
- 框架：
  - Y1 = 政府责任论
  - Y2 = 个人责任论
  - Z = 两者都需要承担责任

### 6. 实战技巧

#### 🔧 快速识别技巧

**步骤1：找动词**
- 划出题目中的动词和动作短语
- 例："encourage", "solve", "prevent", "improve"

**步骤2：判断结构**
- 单一动作 → 两点式
- 对立观点 → 三点式

**步骤3：确定重心**
- 问自己：题目真正想问的是什么？
- 不是表面名词，而是背后的逻辑关系

#### 🎯 检查清单

写作前检查：
- [ ] 我是否识别了真正的重心（动词而非名词）
- [ ] 我区分了两点式还是三点式
- [ ] 我的每个段落都围绕重心展开
- [ ] 主次信息是否正确安排
- [ ] 避免了三种类型的重心偏移

### 7. 总结

掌握两点式与三点式题目的区别，关键在于理解考官考察的逻辑思维而非表面内容。通过识别真正的重心（动词和动作），建立清晰的逻辑结构，并合理分配主次信息，可以有效避免文章重心偏移，从而提高写作分数。

**记住：** 考官关注的是你如何思考和论证，而非你知道多少事实信息。