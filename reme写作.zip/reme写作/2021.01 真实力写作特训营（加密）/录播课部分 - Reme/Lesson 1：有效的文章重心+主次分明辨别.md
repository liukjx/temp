# Lesson 1：有效的文章重心+主次分明辨别

## 课程概述
本课程聚焦于英语学术写作中"文章重心"与"主次分明"的核心原则，通过实例分析帮助学生掌握如何构建逻辑清晰、重点突出的段落结构。

## 核心知识点

### 1. 文章重心 (Article Focus)

#### 1.1 定义
文章重心是指段落或文章中最核心的论点或主张，是作者希望读者重点关注的信息。

#### 1.2 识别方法
- **主题句测试**：段落中的哪句话最能概括整个段落的主旨
- **删除测试**：如果删除某句话，段落的核心意思是否仍然完整
- **问答测试**：这句话是否直接回答了题目提出的问题

#### 1.3 实例分析

**原始段落：**
> "promoting all employees to have position... is a good way for the development of a firm to some extent though there are..."

**问题分析：**
- ❌ 重心不明确：没有直接回答"为什么晋升老员工对公司发展有益"
- ❌ 逻辑跳跃：从"对公司有益"直接跳到"员工忠诚"，缺乏中间论证

**改进版本：**
> "Promoting senior employees to higher positions directly benefits company development by leveraging their accumulated institutional knowledge and proven leadership capabilities."

### 2. 主次分明 (Primary vs. Secondary Information)

#### 2.1 核心原则
| 信息类型 | 特征 | 表达方式 | 例子 |
|---------|------|----------|------|
| **主要信息** | 核心论点、结论 | 独立分句、主句 | "Boarding schools enhance students' independence" |
| **次要信息** | 支持细节、条件 | 从句、状语、修饰语 | "by providing structured living environments" |

#### 2.2 语法实现方式

##### 2.2.1 使用连接词
```
❌ 错误：Students can participate in activities. This can enhance teamwork.

✅ 正确：By participating in structured activities, students develop essential teamwork skills.
```

##### 2.2.2 使用从句结构
```
❌ 错误：Traditional schools have large classes. Teachers must slow down. Students learn less.

✅ 正确：Whereas traditional schools, where classes often exceed thirty students, force teachers to reduce pace, homeschooling allows personalized instruction that accelerates learning.
```

### 3. 逻辑连贯性 (Logical Coherence)

#### 3.1 逻辑链条构建

##### Mermaid流程图：论证结构
```mermaid
graph TD
    A[主要论点] --> B[原因1]
    A --> C[原因2]
    B --> D[具体例子]
    C --> E[数据支持]
    D --> F[结论]
    E --> F
```

#### 3.2 常见逻辑错误
| 错误类型 | 示例 | 改进方法 |
|----------|------|----------|
| **跳跃论证** | "老员工忠诚度高，所以应该晋升" | 补充：忠诚如何转化为公司效益 |
| **循环论证** | "晋升老员工因为他们值得晋升" | 提供客观标准：经验、业绩等 |
| **无关信息** | 讨论员工个人生活 | 聚焦工作相关特质 |

## 实战应用

### 4. 段落重构技巧

#### 4.1 步骤流程
```mermaid
graph LR
    A[识别论点] --> B[区分主次]
    B --> C[重组句子]
    C --> D[添加连接词]
    D --> E[检查重心]
```

#### 4.2 案例分析：寄宿学校优势

**原始版本：**
> "Students can participate in collective activities. This can enhance teamwork skills. This contributes to mental health."

**重构版本：**
> "Boarding schools cultivate teamwork skills through mandatory collective activities, which simultaneously promote students' mental well-being by fostering social connections."

### 5. 评分标准对应

#### 5.1 IELTS Writing Band Descriptors
| 分数段 | 重心要求 | 主次分明要求 |
|--------|----------|--------------|
| **Band 5** | 论点基本清晰 | 信息组织混乱 |
| **Band 6** | 论点明确 | 部分主次区分 |
| **Band 7** | 论点突出且贯穿 | 清晰的主次结构 |
| **Band 8+** | 论点深刻且一致 | 精妙的主次安排 |

#### 5.2 常见误区
- ❌ 认为复杂词汇=高分
- ❌ 忽略句子间的逻辑关系
- ❌ 将次要信息当作主要论点
- ❌ 缺乏连接词导致跳跃

## 练习与提升

### 6. 自我检查清单

#### 6.1 段落检查表
- [ ] 是否有明确的主题句？
- [ ] 每个支持细节是否直接支持主题？
- [ ] 是否使用了适当的连接词？
- [ ] 次要信息是否被正确处理为修饰成分？

#### 6.2 句子优化练习

**练习1：识别重心**
```
原句："Although traditional schools provide socialization opportunities, homeschooling offers personalized attention that benefits fast learners."
重心：____________________
次要信息：____________________
```

**答案：**
- 重心：homeschooling benefits fast learners
- 次要信息：traditional schools provide socialization

### 7. 高级技巧

#### 7.1 多层次主次结构
```
[主要论点]
├── [一级支持：原因]
│   ├── [二级支持：例子]
│   └── [二级支持：数据]
└── [一级支持：结果]
    ├── [二级支持：短期效果]
    └── [二级支持：长期影响]
```

#### 7.2 复杂句型应用
```
复合结构：
"While critics argue that [次要观点], evidence demonstrates that [主要论点], particularly when [条件] and [补充条件]."
```

## 总结

掌握文章重心和主次分明的原则，关键在于：
1. **明确核心**：每段必须有一个清晰的主题
2. **合理分层**：将支持信息按重要性分层
3. **语法实现**：使用从句、连接词等语法手段体现层次
4. **逻辑检验**：确保每个信息都直接服务于核心论点

通过系统性训练，学生可以显著提升写作的逻辑性和说服力，从而在学术英语考试中取得更好成绩。