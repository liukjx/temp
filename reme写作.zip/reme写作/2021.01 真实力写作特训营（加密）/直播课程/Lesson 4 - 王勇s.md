# Lesson 4 - 双边讨论题型精讲

## 课程概述

本节课系统讲解了雅思大作文中的双边讨论题型（Discussion Essay/DG题型），这是与利弊分析题并列的高频题型。重点分析了题干观点关系、文章结构、论证方法和具体写作技巧。

## 核心知识点总结

### 1. 双边讨论题型特征与结构

#### 1.1 题型识别
| 特征要素 | 具体内容 | 示例 |
|----------|----------|------|
| **发问方式** | Discuss both views and give your own opinion | "Discuss both these views and give your own opinion" |
| **观点数量** | 题干呈现两个对立或互补观点 | 两个不同立场/主张 |
| **写作要求** | 分别讨论两个观点并给出个人观点 | 四段式结构 |

#### 1.2 观点关系分析
**Mermaid图表：观点关系分类**

```mermaid
graph TD
    A[题干观点关系] --> B{关系类型}
    B --> C[对立关系]
    B --> D[互补关系]
    C --> E[直接冲突]
    D --> F[各有道理/不同角度]
    
    style C fill:#ffcccc
    style D fill:#ccffcc
```

#### 1.3 核心写作原则
- **二合一写法**（推荐）：分别承认两个观点的合理性
- **二选一写法**（不推荐）：支持一个否定另一个，易导致内容重复

### 2. 文章结构模板

#### 2.1 标准四段式结构
**Mermaid流程图：双边题型结构**

```mermaid
graph LR
    A[开头段] --> B[Body 1: 讨论观点1]
    A --> C[Body 2: 讨论观点2]
    B --> D[结尾段: 个人观点]
    C --> D
    
    style A fill:#e6f3ff
    style B fill:#fff2e6
    style C fill:#f0f8e6
    style D fill:#ffe6f0
```

#### 2.2 各段落写作要点
| 段落 | 内容重点 | 写作技巧 |
|------|----------|----------|
| **开头段** | 呈现争议话题而非具体观点 | 使用"how/what"引导的争议呈现 |
| **Body 1** | 讨论第一个观点的合理性 | "Some people believe...and to a certain extent this is true" |
| **Body 2** | 讨论第二个观点的合理性 | "Others argue...and they do have their points" |
| **结尾段** | 给出个人观点（可倾向性） | 简洁明了，可提出解决方案 |

### 3. 极端观点处理技巧

#### 3.1 识别与处理策略
**知识点：极端观点弱化法**
- **识别标志**：only, must, always, never等绝对词汇
- **处理原则**：承认观点背后的合理出发点，弱化极端表述
- **例子**：
  - 原观点："Sending students to university ONLY leads to unemployment"
  - 处理方式："While sending many students to university may contribute to graduate unemployment to some extent..."

#### 3.2 应用场景表
| 极端表述 | 弱化表达方式 | 保留合理内核 |
|----------|--------------|--------------|
| "should be banned completely" | "should be strictly controlled" | 需要管控的合理性 |
| "always beneficial" | "generally beneficial" | 益处的存在 |
| "makes no sense" | "may not be the best approach" | 质疑的合理性 |

## 精讲题目详解

### 题目1：大学教育 vs 工作经验

#### 题干分析
**题目**：Some people believe that studying in college is the best way to prepare for future career, while others think students should leave school early to develop career through work experience.

#### 论证结构
**职业目标分类法**

```mermaid
graph TD
    A[职业目标分类] --> B[知识密集型工作]
    A --> C[技能实践型工作]
    B --> D[需要系统理论学习]
    B --> E[大学教育最佳]
    C --> F[需要实际操作经验]
    C --> G[工作实践最佳]
```

#### 论证要点
**Body 1: 支持大学教育**
- **抽象概括**：intellectual work, professional knowledge, sustained thinking
- **具体例子**：医生、律师、工程师、会计师、教师
- **论证逻辑**：
  - 涉及持续的专业脑力活动
  - 需要系统积累专业理论知识
  - 大学是最佳知识积累场所

**Body 2: 支持工作经验**
- **抽象概括**：practical skills, hands-on experience, craftsmanship
- **具体例子**：plumber, electrician, chef, carpenter, driver
- **论证逻辑**：
  - 强调一线实际操作技能
  - 工作现场学习更有效
  - 学徒制积累实践经验

#### 关键表达
```markdown
- 知识积累：accumulate professional knowledge and theories
- 脑力工作：involve sustained thinking and intellectual activity
- 实践技能：highlight practical skills and on-site techniques
- 工艺技能：hands-on practices and craftsmanship experience
```

### 题目2：广告的经济效应 vs 社会效应

#### 题干分析
**题目**：Discuss the views that advertising has positive economic effects vs negative social effects because it makes people dissatisfied with themselves.

#### 论证结构对比表
| 维度 | 经济效应（Body 1） | 社会效应（Body 2） |
|------|---------------------|---------------------|
| **核心论点** | 刺激消费，促进经济 | 制造不满，社会影响 |
| **具体机制** | 增加销量→就业→税收 | 营造"标配"观念 |
| **关键词汇** | consumption, innovation, competition | dissatisfaction, inferiority, social pressure |
| **例子** | 更高效的产品，市场竞争 | 钻石广告，身材标准，奢侈品"必备" |

#### 社会效应论证深度分析
**制造不满的心理机制**

```mermaid
graph LR
    A[广告策略] --> B[营造标准]
    B --> C[设定"必备"商品]
    C --> D[普通人无法达到]
    D --> E[产生自我怀疑]
    E --> F[dissatisfied with self]
    
    A1[奢侈品广告] --> B1[成功标配]
    A2[美容广告] --> B2[完美身材]
    A3[珠宝广告] --> B3[爱情证明]
```

#### 关键表达
```markdown
- 经济效应：stimulate consumption, intensify market competition, boost economy
- 社会效应：portray luxury goods as must-haves, create social pressure, cause self-doubt
- 心理影响：feel inferior, suffer from low self-esteem, experience self-doubt
```

### 题目3：政府 vs 个人健康饮食责任

#### 题干分析
**题目**：Some people think government should do more to make citizens eat healthy diets, while others believe individuals must take responsibility for their own diet and health.

#### 论证框架
**政府责任论证**
- **责任基础**：
  - 公众健康意识不足
  - 政府医疗支出压力
  - 预防胜于治疗原则

- **具体措施**：
  - **宣传教育**：public campaigns, celebrity endorsements
  - **立法管控**：soda tax, food labeling requirements
  - **政策引导**：subsidies for healthy foods

**个人责任论证**
- **责任基础**：
  - 最终选择权在个人
  - 政府措施不能强制个人选择
  - 个人承担健康后果

- **责任体现**：
  - 健康饮食意识觉醒
  - 理性消费选择
  - 为家人健康负责

#### 论证逻辑链
**Mermaid图表：责任分配逻辑**

```mermaid
graph TD
    A[健康饮食问题] --> B{责任主体}
    B --> C[政府责任]
    B --> D[个人责任]
    C --> E[宣传教育]
    C --> F[政策引导]
    C --> G[法律规范]
    D --> H[自主选择]
    D --> I[健康意识]
    D --> J[后果承担]
```

#### 关键表达
```markdown
- 政府角度：reduce government spending on public health care, devise ways to encourage healthy eating
- 个人角度：ultimately comes down to personal choice, make rational and responsible choices
- 措施词汇：launch advertisement campaigns, raise awareness, impose special tax, adopt tougher approach
```

## 近期考题思路整理

### 考题1：团队运动 vs 个人运动
**题目**（2020年8月9日）：Team sports vs individual sports benefits

**核心论证角度**
| 运动类型 | 核心益处 | 具体体现 |
|----------|----------|----------|
| **团队运动** | 合作精神培养 | teamwork, mutual understanding, tolerance |
| **个人运动** | 竞争意识强化 | self-discipline, personal achievement, competition skills |

### 考题2：专业选择自主权
**题目**（2020年11月28日）：Parents choosing majors vs students' freedom to choose

**论证要点**
- **学生自主选择**：
  - 个人权利与自由
  - 基于兴趣选择更投入
  - 学习动机更强

- **家长参与选择**：
  - 经验与前瞻性考虑
  - 现实因素评估（就业前景、个人天赋）
  - 避免学生选择的局限性

## 词汇与表达库

### 双边题型连接词
| 功能 | 表达方式 | 例句 |
|------|----------|------|
| **引入观点1** | Some people believe/argue that... | Some people believe that... |
| **承认合理性** | And to a certain extent this is true... | ...and they do have their points |
| **引入观点2** | Others however think that... | Others however maintain that... |
| **个人观点** | In my opinion/view... | Personally, I believe that... |

### 抽象词具象化模板
```markdown
- 职业目标：career goals, career aspirations, professional objectives
- 健康饮食：healthy diet, balanced nutrition, nutritious food choices
- 社会责任：social responsibility, public duty, civic obligation
- 个人选择：personal choice, individual decision, autonomous selection
```

### 论证强化表达
```markdown
- 强调重要性：it is imperative/essential/crucial that...
- 因果关系：contribute to, lead to, result in, give rise to
- 程度表达：to a large extent, to some degree, in many cases
- 对比关系：on the contrary, in contrast, whereas, while
```

## 学习建议与作业

### 写作技巧总结
1. **结构清晰**：严格按照"争议呈现→观点1讨论→观点2讨论→个人观点"四段式
2. **论证均衡**：两个body段落字数相当，避免明显偏重
3. **避免重复**：不要用二选一写法导致内容重叠
4. **观点承认**：用"是的，有道理"的口吻分别承认两个观点

### 今日作业
1. **写作练习**：从3个精讲题目中选择1个完成作文
   - 推荐：广告经济效应vs社会效应（话题重要性高）
   - 备选：大学教育vs工作经验
   - 要求：四段式结构，每段论证充分

2. **范文学习**：
   - 重点阅读真实力教材202、304、505、605题
   - 学习二合一写法标准结构
   - 积累连接词和论证表达

3. **预习准备**：
   - 观看Raymi第四节录播课（利弊分析题）
   - 为下节课Lesson 5做准备

### 常见误区提醒
- ❌ 将双边题型写成利弊分析题
- ❌ 开头段具体呈现两个观点（应在body段呈现）
- ❌ 使用二选一写法导致内容重复
- ❌ 忽略极端观点的弱化处理
- ❌ body段落字数严重不平衡

---

*双边讨论题型是雅思写作中最稳定、最容易掌握的题型之一，关键在于遵循"二合一"结构，分别承认两个观点的合理性。*