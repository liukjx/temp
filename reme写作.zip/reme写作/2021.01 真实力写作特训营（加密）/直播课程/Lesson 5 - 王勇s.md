# Lesson 5 - 利弊分析题精讲
## 王勇雅思写作课程总结

## 1. 利弊分析题概述

### 题型定义
利弊分析题（Advantages and Disadvantages Essay）要求考生分析某一现象、政策或发展趋势的积极和消极影响，并给出个人观点。

### 题型特点
- **强制双边结构**：必须同时分析利与弊
- **与双边题相似**：结构为四段式，但内容从观点讨论转为利弊分析
- **发问方式多变**：但核心都是分析利弊

## 2. 发问方式分类

### 表格：利弊分析题发问类型

| 发问类型 | 示例 | 写作要求 | 概率 |
|---------|------|----------|------|
| **直接分析利弊** | "Analyze the advantages and disadvantages" | 需分析利与弊，可比较可不比较 | 低 |
| **评价性质** | "Is this trend positive or negative?" | 需分析利与弊，然后给出整体评价 | 中 |
| **比较大小** | "Do the advantages outweigh the disadvantages?" | 需分析利与弊，必须明确比较大小 | **高** |
| **同意特定影响** | "Do you agree that this has positive effects?" | 只需分析同意的影响，无需分析反面 | 极低 |

## 3. 写作结构与要点

### 四段式结构
```mermaid
graph TD
    A[开头段 - 引入话题] --> B[第二段 - 详细阐述利]
    B --> C[第三段 - 详细阐述弊]
    C --> D[结尾段 - 个人观点总结]
```

### 写作要点

#### 1. 暴力段要求
- **内容充分**：利与弊都要详细论述，避免故意弱化某一方
- **长度平衡**：两段长度差异不宜过大，避免给考官论证不充分的印象
- **论据质量**：一条强有力的论据胜过多条薄弱论据

#### 2. 个人观点
三种可选观点：
- 利大于弊
- 弊大于利  
- 利弊无法比较（需复杂论证，不推荐初学者使用）

#### 3. 注意事项
- 前三段结构固定，仅结尾段体现个人观点差异
- 论据条数不需对等，但段落长度需平衡
- 避免过度纠结结论选择，重点在于论证过程

## 4. 特殊题型：双主题利弊分析

### 题型特征
- 比较两个事物的利弊，而非单一事物的利弊
- 例："Does renting bring more advantages than buying?"

### 写作策略
- **结构**：两段分别分析两个主题的利（而非利弊各写一遍）
- **避免重复**：租的利就是买的弊，反之亦然，避免重复论述
- **互补论证**：通过"避免对方问题"的方式呈现利益

### 示例框架
```
第二段：Renting advantages
- 灵活性高，无长期承诺
- 避免买房的资金压力
- 避免房产贬值风险

第三段：Buying advantages  
- 资产增值潜力
- 避免租金上涨风险
- 避免被房东驱赶的不稳定
```

## 5. 精讲题目分析

### 题目一：远程教育

**题目**：Many universities offer qualifications through distance learning rather than face-to-face teaching.

#### 利（Advantages）
| 利益点 | 具体论证 | 关键词汇 |
|--------|----------|----------|
| **成本节约** | 省去通勤/异地租房费用，学费更低 | save the trouble of commuting, lower tuition fees |
| **灵活性高** | 直播+录播，适合全职工作者和全职主妇 | flexible schedules, pre-recorded videos, live streaming |
| **扩大教育机会** | 突破校园设施限制，招收更多学生 | recruit more students, campus facilities constraints |

#### 弊（Disadvantages）
| 弊端点 | 具体论证 | 关键词汇 |
|--------|----------|----------|
| **教学质量** | 缺乏及时反馈，师生互动有限 | identify problems in a timely manner, inefficient communication |
| **缺乏大学体验** | 缺少社团活动、同伴压力 | lack of peer pressure, rich campus activities |
| **辍学率高** | 自控力差的学生容易放弃 | lack of motivation, higher dropout rate |

### 题目二：国际旅游

**题目**：International tourism has become a huge industry. Do you think the advantages outweigh the disadvantages?

#### 利（Advantages）
| 利益点 | 具体论证 | 关键词汇 |
|--------|----------|----------|
| **经济促进** | 带动航空、酒店、零售等相关产业 | facilitate international business, attract foreign investment |
| **文化交流** | 增进国际理解，促进世界和平 | encourage cultural exchange, strengthen international cooperation |

#### 弊（Disadvantages）
| 弊端点 | 具体论证 | 关键词汇 |
|--------|----------|----------|
| **文化偏见** | 游客产生优越感，形成刻板印象 | develop prejudice, primitive and backward stereotypes |
| **环境压力** | 碳排放增加，自然资源破坏 | carbon emission, greenhouse gas emission, natural environment destruction |

### 题目三：食品进口

**题目**：Countries can buy various foods from abroad. Do the advantages outweigh the disadvantages?

#### 利（Advantages）
| 利益点 | 具体论证 | 关键词汇 |
|--------|----------|----------|
| **食品多样性** | 突破气候地理限制，丰富饮食选择 | climate and land conditions, diverse range of foods |
| **经济效益** | 带动物流、仓储、运输等产业发展 | aviation, shipping, road logistics, storage facilities |

#### 弊（Disadvantages）
| 弊端点 | 具体论证 | 关键词汇 |
|--------|----------|----------|
| **农业冲击** | 本地农民失去生计，食品加工行业萎缩 | lose traditional livelihoods, domestic food industry shrinks |
| **战略风险** | 过度依赖进口，威胁粮食安全 | overly rely on foreign supply, long-term food security |
| **环境影响** | 长途运输增加碳足迹 | long-haul transportation, offset global environmental efforts |

## 6. 近期考题预测

### 高频话题整理
| 考题日期 | 题目主题 | 写作要点 |
|----------|----------|----------|
| 2023年1月4日 | 电视转播刑事审判 | 透明度 vs 隐私权，公众教育 vs 恐慌情绪 |
| 2023年12月26日 | 西式服装普及 | 全球化便利 vs 传统文化流失 |

## 7. 写作技巧总结

### 论证策略
1. **具象化原则**：避免抽象论述，用具体例子支撑观点
2. **主体关联**：确保论据与主题高度相关
3. **推导逻辑**：每个观点都要有充分推导过程

### 语言表达
- **连接词**：First and foremost, Moreover, Furthermore, In addition
- **对比词**：However, On the other hand, Conversely, Nevertheless
- **结论词**：In conclusion, To sum up, Overall, Ultimately

### 词汇升级
| 基础词汇 | 高级替换 |
|----------|----------|
| good/bad | beneficial/detrimental |
| help | facilitate, promote, enhance |
| problem | issue, concern, drawback |
| cause | lead to, result in, contribute to |

## 8. 课后练习建议

### 推荐练习题目
1. **远程教育** - 真实力第801题
2. **国际旅游** - 真实力第501题  
3. **食品进口** - 真实力第502题
4. **租房vs买房** - 真实力第305题

### 练习步骤
1. **审题训练**：识别题目类型和发问方式
2. **头脑风暴**：针对每个题目列出2-3个利与弊
3. **结构搭建**：按照四段式结构组织文章
4. **语言优化**：使用高级词汇和复杂句式
5. **计时练习**：40分钟内完成完整文章

### 学习资源
- **录播课程**：第5节录播 - 正三角倒三角论述方式
- **参考范文**：真实力写作教材中的考官范文
- **词汇积累**：建立利弊分析专用词汇表