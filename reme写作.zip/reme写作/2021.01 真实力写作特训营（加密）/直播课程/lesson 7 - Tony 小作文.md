# 雅思小作文写作课程 - Lesson 7 知识点总结
*讲师：Tony | 目标分数：6-6.5分*  
*录屏时间：2021年10月 | 地点：泰国曼谷*

## 课程概览

### 讲师背景
- **Tony老师雅思成绩**：总分8分，写作8分，口语7.5分（瓶颈）
- **考试经历**：首次裸考写作7分，近年多次8分以上
- **教学定位**：专注6-6.5分写作技巧，7分需额外自主学习
- **课程安排**：3小时，分3次课（静态图→动态图→地图+流程图）

### 考试策略
| 项目 | 建议时间 | 字数要求 | 策略要点 |
|------|----------|----------|----------|
| 小作文 | 20-25分钟 | 最低150字（建议250+） | 先写小作文，无难题 |
| 大作文 | 35-40分钟 | 250字 | 可能有知识盲点 |

---

## 小作文类型体系

### 三大类题型
```mermaid
graph TD
    A[小作文类型] --> B[数据图 60-70%]
    A --> C[地图 20-30%]
    A --> D[流程图 <10%]
    
    B --> B1[线图 line chart/graph]
    B --> B2[柱状图 bar chart]
    B --> B3[饼图 pie chart]
    B --> B4[表格 table]
    
    B --> B5[动态图]
    B --> B6[静态图]
    
    C --> C1[房型图 floor plan]
    C --> C2[地理变迁图]
    
    D --> D1[生产流程]
    D --> D2[生命周期]
```

### 题型特点对比
| 类型 | 难度 | 技术要求 | 套路适用性 |
|------|------|----------|------------|
| **动态图** | ⭐ | 低 | 高（可套模板） |
| **静态图** | ⭐⭐⭐ | 高 | 低（需个性化） |
| **地图题** | ⭐⭐ | 中等 | 中等 |
| **流程图** | ⭐⭐ | 低-中等 | 取决于动词是否给出 |

---

## 数据表达核心技巧

### 1. 占比表达法（高频考点）

#### 基础表达
| 表达方式 | 例句 | 使用场景 |
|----------|------|----------|
| **account for** | A accounts for 20% of B | 最常用，A是分子，B是分母 |
| **constitute** | A constitutes 20% of B | 正式表达 |
| **make up** | A makes up 20% of B | 口语化 |
| **represent** | A represents 20% of B | 书面语 |

#### 高级变体
```
⚠️ 避免重复：同一篇文章至少使用3种不同表达
✅ 百分比前置：20% of B is A
✅ 被动语态：20% of B is made up of A
✅ 分词结构：A, accounting for 20% of B, ...
```

#### 典型错误警示
- ❌ **错误**：使用rate表示占比（缺乏明确定义）
- ❌ **错误**：the number of A account for...（主谓不一致）
- ✅ **正确**：A accounts for 20% of the total

### 2. 排名表达法

#### 基础词汇
| 排名 | 动词表达 | 介词短语 |
|------|----------|----------|
| 第1名 | rank first/top the chart | in terms of... |
| 第2名 | rank second/come in second | followed by... |
| 第3名 | rank third | with... |

#### 高级表达模板
```
Top the chart: The US topped the Olympic medal chart, earning 46 golds.
Come in second: Coming in second was the USSR, which secured 30 golds.
Margin expression: The US outperformed the USSR by 16 golds.
```

### 3. 比例与倍数关系

#### 比例表达
- **Ratio**: the male to female ratio was 28:72
- **倍数**: Urban candidates outnumbered their rural counterparts by 3:1
- **每...中有**: For every 100 residents, 28 were men and 72 were women

#### 比较结构
```
A outnumbers B by X to Y
A exceeds B by a factor of 3
A is three times as many as B
```

---

## 写作结构与段落安排

### 标准4段式结构
| 段落 | 功能 | 内容要点 | 字数建议 |
|------|------|----------|----------|
| **Introduction** | 改写题目 | 同义替换+概述图表 | 2-3行 |
| **Overview** | 总体特征 | 最显著趋势/特征 | 2-3行 |
| **Body 1** | 细节描述 | 主要数据+比较 | 4-5行 |
| **Body 2** | 补充细节 | 次要数据+比较 | 4-5行 |

### Overview段写作技巧

#### 核心原则
- **不写具体数字**：只描述总体趋势
- **抓大放小**：突出最显著特征
- **分类描述**：可按性别、年龄段、地区等分类

#### 模板句式
```
静态图：A had the largest proportion, while B was the smallest.
动态图：Overall, there was an upward trend in A, whereas B declined steadily.
地图题：Significant changes had taken place in..., with...being the most noticeable.
```

### 数据选择与合并策略

#### 选择原则
- **突出极值**：最大值、最小值必须提及
- **合并同类**：相似数据可归为一类描述
- **忽略细节**：不重要的数据可简略处理

#### 实际应用示例
**案例：12国金牌榜**
- 必写：美国（第1）、苏联（第2）、日本（最后）
- 选写：中国（倒数第2）、英国（第3）
- 忽略：其他7个国家

---

## 题型专项突破

### 静态图解题步骤
1. **审题**：确认无时间变化，识别比较对象
2. **分类**：按数据特征分组（如年龄段、地区）
3. **选点**：突出极值和显著差异
4. **表达**：使用多样化词汇避免重复

### 地图题关键要素
- **时态判断**：过去vs现在的变化
- **方位描述**：in the north/south of...
- **变化类型**：新增、消失、替换、扩建
- **动词储备**：was built/replaced/converted into...

### 流程图注意事项
- **动词时态**：一般现在时被动语态
- **连接词**：firstly, then, after that, finally
- **工具词汇**：equipment, materials, ingredients
- **简化策略**：合并相似步骤，突出关键变化

---

## 高分表达替换表

### 避免重复的词汇替换
| 基础词 | 替换词1 | 替换词2 | 替换词3 |
|--------|---------|---------|---------|
| people | residents | citizens | individuals |
| show | illustrate | depict | demonstrate |
| increase | rise | grow | climb |
| decrease | fall | drop | decline |
| money | revenue | income | earnings |

### 句式多样化技巧
```
基础句：The US won 46 gold medals.
高级句1：The US topped the chart with 46 golds.
高级句2：Earning 46 golds, the US outperformed all other countries.
高级句3：With 46 golds to its credit, the US led the medal standings.
```

---

## 实战模板与示例

### 静态图模板
```
The chart compares A and B in terms of C.

Overall, A had the largest proportion, while B was the smallest. Additionally,...

In detail, A accounted for X% of the total, followed by B at Y%. Meanwhile,... 
```

### 动态图模板
```
The line graph illustrates the changes in... between... and...

Overall, while A increased significantly, B experienced a downward trend.

In 1990, A stood at... By 2000, this figure had risen to..., whereas B... 
```

### 地图题模板
```
The maps show the development of... between... and...

Overall, the area underwent significant changes, with new facilities being added.

In 1990, there was a... in the north. By 2010, this had been converted into... 
```

---

## 评分标准深度解析

### 核心评分维度
| 维度 | 权重 | 6分要求 | 7分要求 |
|------|------|---------|---------|
| **Task Achievement** | 25% | 覆盖主要特征 | 全面覆盖+深入分析 |
| **Coherence & Cohesion** | 25% | 清晰分段 | 逻辑流畅+衔接自然 |
| **Lexical Resource** | 25% | 词汇准确 | 多样+精准 |
| **Grammatical Range** | 25% | 句式正确 | 复杂句式+无错误 |

### 常见误区警示
- **审题错误**：将百分比误解为时间比例
- **数据堆砌**：不分主次描述所有数据
- **模板痕迹**：过度依赖套路导致不自然
- **时态混乱**：地图题时态使用错误

---

## 课后练习建议

### 每日训练计划
1. **词汇积累**：每天记忆5个数据表达高级词汇
2. **句式练习**：用不同句式表达同一数据
3. **真题演练**：每周完成2篇完整小作文
4. **错误分析**：建立个人错误清单，避免重复犯错

### 推荐练习题目
- **静态图**：印度vs法国人口结构对比
- **动态图**：1990-2010年某国失业率变化
- **地图题**：某旅游景点1995-2015年变化
- **流程图**：咖啡制作过程

---

*下一课预告：动态图写作技巧+真题演练*  
*课程资料：课后群内发放数据表达法总结表*