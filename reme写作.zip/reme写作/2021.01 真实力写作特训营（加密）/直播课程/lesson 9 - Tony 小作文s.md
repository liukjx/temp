# 第九课 - Tony小作文知识总结

## 课程概述
本节课重点讲解了雅思写作Task 1中的地图题和流程图题，包括方位表达、建筑变化描述、以及地图写作的整体框架和技巧。

## 1. 方位表达法

### 1.1 基本方位介词

| 介词 | 用法 | 示例 |
|------|------|------|
| **in** | 表示在内部 | in the north of the stadium |
| **to** | 表示在外部（无论是否接壤） | to the north of Hong Kong |
| **on** | 极少使用（建议避免） | 罕见用法 |

### 1.2 45度方位表达
- **northeast** (东北)
- **northwest** (西北)
- **southeast** (东南)
- **southwest** (西南)

### 1.3 距离表达
- **three miles north of New York** (纽约以北三英里)
- **20 kilometers south of the city** (城市以南20公里)

### 1.4 方位副词用法
- **south of...** (作为副词，无需介词)
- **living in the house just south of market street**

## 2. 建筑与设施描述

### 2.1 建造表达
| 动词 | 被动语态 | 示例 |
|------|----------|------|
| build | is built | A new teaching building is built south of the sports field |
| construct | is constructed | The library is constructed in the center |
| put/place | is put/placed | The statue is placed in the garden |

### 2.2 位置表达
- **be located/situated/lie/stand**
  - The town is located in the north
  - The building stands in the center
  - A river lies between the two cities

### 2.3 常见错误提醒
- ❌ **there was a river situated** (双动词错误)
- ✅ **there is a river situated** 或 **a river is situated**
- ❌ **situated the river** (缺少be动词)
- ✅ **the river is situated**

## 3. 建筑变化描述

### 3.1 转换与改建

```mermaid
graph TD
    A[原有建筑] --> B[转换方式]
    B --> C[be converted into]
    B --> D[be changed into]
    B --> E[be turned into]
    B --> F[be transformed into]
    C --> G[新用途]
```

### 3.2 拆除表达
| 动词 | 用法 | 示例 |
|------|------|------|
| demolish | is demolished | The old building is demolished |
| remove | is removed | The shops are removed |
| tear down | is torn down | The house is torn down |

### 3.3 扩建与缩小
- **扩建**: be expanded/extended
  - The gym is expanded to twice its original size
  - be expanded to twice its original area
- **缩小**: be reduced
  - ❌ **the area will reduce** (错误，reduce是及物动词)
  - ✅ **the area will be reduced**

### 3.4 迁移与取代
- **迁移**: be moved to/relocated to
- **取代**: 
  - is replaced by
  - in its place
  - instead of

### 3.5 腾地方表达
- **make way for** (为...让路)
- **make room for** (为...腾地方)
- **to make way for a new housing project**

## 4. 地图写作框架

### 4.1 段落结构
```
1. Introduction (引言段)
2. Overview (概述段)
3. Body Paragraph 1 (主体段1)
4. Body Paragraph 2 (主体段2)
```

### 4.2 引言段模板
- **This map illustrates how...**
- **The diagram shows the changes in...**
- **A comparison of the current layout with...**

### 4.3 概述段写法

#### 套路写法
> The town center will undergo a major transformation, **which includes**:
> - the conversion of a motorway into a pedestrian-only street
> - the construction of a ring road
> - the expansion of residential areas

#### 特点描述法
> The village will become **more commercialized** and **increasingly habitable** with **more facilities built** for local residents.

### 4.4 分段方法

| 分段方式 | 适用场景 | 示例 |
|----------|----------|------|
| **变化 vs 不变** | 有明显变化区域 | 变化的一段，不变的一段 |
| **过去 vs 现在** | 时间对比图 | 过去一段，现在一段 |
| **方位分段** | 有明显方位界限 | 路北一段，路南一段 |
| **功能分类** | 功能区域明显 | 建筑一段，道路一段 |

## 5. 具体位置描述技巧

### 5.1 从中心到四周
- **At the center of...** (在...中心)
- **Right in the middle of...** (就在...中间)
- **Surrounded by...** (被...环绕)

### 5.2 从入口开始
- **Upon entering...** (进入时)
- **One is greeted by...** (首先看到的是)
- **To the left/right of the entrance...** (入口左/右侧)

### 5.3 相邻关系
- **next to...** (紧挨着)
- **beside...** (在旁边)
- **opposite...** (在对面)
- **across from...** (在...对面)

### 5.4 角落表达
- **in the northeast corner** (在东北角)
- **against the north wall** (靠着北墙)
- **along the perimeter** (沿着周边)

## 6. 衔接与连贯

### 6.1 段落衔接
- **Looking at the current plan...**
- **Turning to the present layout...**
- **In the current plan...**

### 6.2 句子衔接
- **with...** (伴随状语)
- **where...** (定语从句)
- **while...** (同时发生)

### 6.3 空间转换
- **Moving to the east...**
- **Turning to the northeast corner...**
- **Opposite this...**

## 7. 时态使用

| 时间 | 时态 | 示例 |
|------|------|------|
| **过去** | 一般过去时 | The fountain was located at the center |
| **现在** | 一般现在时 | The rose garden is situated where... |
| **将来** | 将来时/将来被动 | The shops will be demolished to make way for... |
| **完成** | 现在完成时 | The area has been transformed into... |

## 8. 常见错误与提醒

### 8.1 方位介词错误
- ❌ **nearby the school** (nearby是副词/形容词)
- ✅ **near the school** 或 **a nearby school**

### 8.2 冠词使用
- 第一次提及用 **a/an**
- 再次提及用 **the**
- 复数名词前不用冠词

### 8.3 动词被动语态
- 地图题中大量使用被动语态
- 注意**be**动词的时态变化
- 避免双动词错误

### 8.4 高级表达使用原则
> **原则**: 只用100%确定的表达
> - 见过7-8次再使用
> - 不确定的表达宁可不用
> - 考官对7分作文容忍度为0

## 9. 词汇拓展

### 9.1 设施类
- **amenities** (便民设施)
- **facilities** (设施)
- **infrastructure** (基础设施，不可数)
- **commercial development** (商业开发区)

### 9.2 建筑类
- **apartment blocks** (公寓楼)
- **office blocks** (办公楼)
- **residential area** (住宅区)
- **pedestrian-only street** (步行街)

### 9.3 变化描述
- **transformation** (转变)
- **conversion** (转换)
- **demolition** (拆除)
- **construction** (建设)
- **expansion** (扩张)
- **gentrification** (社区翻新)

## 10. 写作检查清单

### 10.1 内容检查
- [ ] 所有重要变化都已提及
- [ ] 方位描述准确
- [ ] 时态使用正确
- [ ] 被动语态使用恰当

### 10.2 语言检查
- [ ] 句子结构正确
- [ ] 介词使用准确
- [ ] 冠词使用恰当
- [ ] 衔接自然流畅

### 10.3 读者视角检查
- [ ] 没有图表也能理解
- [ ] 描述比原图更清晰
- [ ] 重点突出，层次分明

---

**总结**: 地图题的关键在于准确的方位表达、恰当的变化描述和自然的语言衔接。遵循"准确性优于复杂性"的原则，使用熟悉的表达，确保每个句子都正确无误。